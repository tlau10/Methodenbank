
Die Onlinehilfe ist jetzt im Projekt integriert.
Siehe das Verzeichnis 'hlp' im Verzeichnis 'Source'

