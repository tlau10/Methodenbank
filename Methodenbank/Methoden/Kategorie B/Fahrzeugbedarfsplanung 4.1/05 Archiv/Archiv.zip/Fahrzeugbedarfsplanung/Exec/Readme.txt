Die Datei solver.dat ist die f�r den Solveraufruf
ben�tigte Pif-Datei. Sie wird als solver.pif in
das Arbeitsverzeichnis (i.d.R. c:\temp) kopiert.
