//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FaBePlan.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FABEPLAN_FORM               101
#define IDR_MAINFRAME                   128
#define IDR_FABEPLTYPE                  129
#define IDS_WEITERE_INFOS               129
#define IDD_DIALOG_TOUR_EINGEBEN        130
#define IDD_DIALOG_OPTIONEN             131
#define IDB_FAHRPLAN_IMAGES             132
#define IDB_AUTOR_IMAGE                 133
#define IDD_SOLVER_ERGEBNIS             140
#define IDB_OPEN_FOLDER                 143
#define IDC_FAHRPLAN                    1000
#define IDC_MIN_FAHRZEUGE               1000
#define IDC_ABFAHRT_ORT                 1001
#define IDC_ANKUNFT_ORT                 1002
#define IDC_ABFAHRT_ZEIT                1003
#define IDC_ANKUNFT_ZEIT                1004
#define IDC_PERSONEN                    1005
#define IDC_SOLVER_AUSWAHL              1006
#define IDC_XA_PFAD                     1009
#define IDC_LP_PFAD                     1010
#define IDC_MOPS_PFAD                   1011
#define IDC_XA_SUCHEN                   1012
#define IDC_LP_SUCHEN                   1013
#define IDC_MOPS_SUCHEN                 1014
#define IDC_WEITERE_INFOS               1019
#define IDC_FAHRZEUG_BEDARF             1030
#define ID_BEARBEITEN_TOUREINGEBEN      32771
#define ID_BEARBEITEN_TOURLOESCHEN      32772
#define ID_BEARBEITEN_OPTIMUMBERECHNEN  32773
#define ID_BEARBEITEN_BEDARFBERECHNEN   32775
#define ID_BEARBEITEN_TOURVERAENDERN    32777
#define ID_EINSTELLUNGEN_OPTIONEN       32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
