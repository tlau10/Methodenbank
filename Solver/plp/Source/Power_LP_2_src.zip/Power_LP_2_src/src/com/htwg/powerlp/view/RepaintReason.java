package com.htwg.powerlp.view;

/**
 * @author schobast
 *
 */
public enum RepaintReason {
	REPAINT_VAR_RED, REPAINT_VAR_INC, REPAINT_INIT, REPAINT_CONST_INC,REPAINT_CONST_RED; 
}
