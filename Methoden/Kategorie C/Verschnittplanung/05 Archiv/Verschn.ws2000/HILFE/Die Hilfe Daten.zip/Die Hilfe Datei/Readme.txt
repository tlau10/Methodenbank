Die Hilfe

Die Hilfe sit mit dem Tool Hilfeworkshop von Microsoft Visual STudio 6 erstellt. 
F�r die Ertellung ben�tigt man folgende dateien.

	Verscnhitt.RTF :- Ein WORD Dokument, welches die Inhalte (Beschreibungen ) der 	gesamten Hilfe beinhaltet.

	Verschn.cnt :- Diese datei beschreibt die Sturktur und Anordnung der Hilfesystems und wird mit Hilfe Workshop 	erstellt.

	Verscnitt.h :- Ein Header Datei zum definiton aller Stukturen (Inhaltsverzeichnis). Diese datei kann in alle C++ 	Programmen erstellt werden.
	
	Verscnitt.hpi :- beinhaltet aller der obengenannten dateien und ist das notwndigste datei zur Erstellung der Hilfe 	Datei. Es enth�lt ausserdem andere optionen (z.B. Hintergrund Einstellungen, Bilder dateien usw. ), welche in die 	Hilfedatei eingebunden werden k�nnen. Diese datei wird mit dem Hilfeworkshop erstellt

	Bilderdateien. Verschiedene Bilderdateien (Bitmap Dateien) k�nnen zus�tzlich erstellt werden und ensprechend 		eingef�gt werden. Dabei m�ssen diese Bilderdateien von Bitmap in WMF Format umgewandelt werden. (einfach das suffix 		in WMF umschreiben)

Nachdem Erstellung dieser dateien kann die .hpi datei in HilfeWorkshop ge�ffnet und compiliert werden. So hat man dann die Hilfe DAtei erstellt.

Viel Spass.

Degu Dagne 20.1.2001
