/*
 * Created on 14.06.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package AnwBESF;

import javax.swing.JInternalFrame;

/**
 * @author jensk
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ergebnisAnzeige extends JInternalFrame {
	public ergebnisAnzeige() 
	{
		super("Ergebnis",true,true,true,true);
		setLocation(600,0);
		setSize(400,700);
		setVisible(true);
	}
}
