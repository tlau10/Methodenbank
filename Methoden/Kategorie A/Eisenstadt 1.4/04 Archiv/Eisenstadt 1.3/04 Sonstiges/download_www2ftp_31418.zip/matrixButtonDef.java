package AnwBESF;
/*
 * Created on 13.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class matrixButtonDef extends JInternalFrame
{
        private JLabel lAuswahl;
        private static final String[] AUSWAHL =
        {
                        "passierbar", "pot. Haltestelle", "feste Haltestelle", "unpassierbar"
        };

        private JLabel lGewichtung;
        private JLabel lAbstandNord;
        private JLabel lAbstandOst;
        private JLabel lAbstandSued;
        private JLabel lAbstandWest;

        private JComboBox jCBAuswahl;
        private JTextField tFGewichtung;
        private JTextField tFAbstandNord;
        private JTextField tFAbstandOst;
        private JTextField tFAbstandSued;
        private JTextField tFAbstandWest;

        private matrixButton zugehoerigerButton;

        private JButton okButton;
        private static final String ActionEvent = null;

        public matrixButtonDef(matrixButton b)
        {
                super("Button " + b.holeID(),false,true,false,false);
                setSize(200,200);
                setLocation(0,151);

                zugehoerigerButton = b;

                lAuswahl = new JLabel("Auswahl");
                lGewichtung = new JLabel("Gewichtung");
                lAbstandNord = new JLabel("Abstand Nord");
                lAbstandOst = new JLabel("Abstand Ost");
                lAbstandSued = new JLabel("Abstand S�d");
                lAbstandWest = new JLabel("Abstand West");

                jCBAuswahl = new JComboBox(AUSWAHL);
                tFGewichtung = new JTextField();
                tFAbstandNord = new JTextField();
                tFAbstandOst = new JTextField();
                tFAbstandSued = new JTextField();
                tFAbstandWest = new JTextField();

                okButton = new JButton("Speichern");
                aLClose aLClose1 = new aLClose();
                okButton.addActionListener(aLClose1);

                getContentPane().setLayout(new GridLayout(7,2));

                getContentPane().add(lAuswahl);
                getContentPane().add(jCBAuswahl);
                getContentPane().add(lGewichtung);
                getContentPane().add(tFGewichtung);
                getContentPane().add(lAbstandNord);
                getContentPane().add(tFAbstandNord);
                getContentPane().add(lAbstandOst);
                getContentPane().add(tFAbstandOst);
                getContentPane().add(lAbstandSued);
                getContentPane().add(tFAbstandSued);
                getContentPane().add(lAbstandWest);
                getContentPane().add(tFAbstandWest);
                getContentPane().add(okButton);
        }

        public void setzeAuswahl(int a)
        {
                jCBAuswahl.setSelectedIndex(a);
        }

        public void setzeGewichtung(int wert)
        {
                tFGewichtung.setText(Integer.toString(wert));
        }

        public void setzeAbstandNord(int wert)
        {
                tFAbstandNord.setText(Integer.toString(wert));
        }

        public void setzeAbstandOst(int wert)
        {
                tFAbstandOst.setText(Integer.toString(wert));
        }

        public void setzeAbstandSued(int wert)
        {
                tFAbstandSued.setText(Integer.toString(wert));
        }

        public void setzeAbstandWest(int wert)
        {
                tFAbstandWest.setText(Integer.toString(wert));
        }

        class aLClose implements ActionListener
        {
                public void actionPerformed(ActionEvent arg0)
                {
                        zugehoerigerButton.setzeAbstandNord(Integer.parseInt(tFAbstandNord.getText()));
                        zugehoerigerButton.setzeAbstandSued(Integer.parseInt(tFAbstandSued.getText()));
                        zugehoerigerButton.setzeAbstandOst(Integer.parseInt(tFAbstandOst.getText()));
                        zugehoerigerButton.setzeAbstandWest(Integer.parseInt(tFAbstandWest.getText()));
                        zugehoerigerButton.setzeGewichtung(Integer.parseInt(tFGewichtung.getText()));
                        zugehoerigerButton.setzeAuswahl(jCBAuswahl.getSelectedIndex());
                        System.out.println(zugehoerigerButton.holeID());
                        dispose();
                }
        }
}
