package AnwBESF;

/*
 * Created on 13.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import javax.swing.*;

public class matrixViewAnzeige extends JInternalFrame
{
       public matrixViewAnzeige(int x, int y)
        {
                super("Gewichtungsmatrix",true,true,true,true);
                setLocation(201,0);
                setSize(400,400);
                setVisible(true);
        }
}
