package AnwBESF;

/*
 * Created on 13.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.awt.Event;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class matrixView extends JFrame implements ActionListener
{
        private JDesktopPane desk;

        public matrixView()
        {
                setSize(1024,568);
                setLocation(0,0);
                setExtendedState(JFrame.MAXIMIZED_BOTH);

                addWindowListener(new WindowClosingAdapter(true));

                JMenuBar menubar = new JMenuBar();
                menubar.add(erstelleDateiMenu());
                setJMenuBar(menubar);

                desk = new JDesktopPane();
                setContentPane(desk);
        }

        private JMenu erstelleDateiMenu()
          {
            JMenu ret = new JMenu("Datei");
            ret.setMnemonic('D');
            JMenuItem mi;

            mi = new JMenuItem("�ffnen", 'f');
            setCtrlAccelerator(mi, 'O');
            mi.addActionListener(this);
            mi.setActionCommand("O");
            ret.add(mi);

            mi = new JMenuItem("Speichern", 'p');
            setCtrlAccelerator(mi, 'S');
            mi.addActionListener(this);
            mi.setActionCommand("S");
            ret.add(mi);

            ret.addSeparator();

            mi = new JMenuItem("Beenden", 'e');
            mi.addActionListener(this);
            mi.setActionCommand("B");
            ret.add(mi);
            return ret;
          }

          private void setCtrlAccelerator(JMenuItem mi, char acc)
          {
            KeyStroke ks = KeyStroke.getKeyStroke(
              acc, Event.CTRL_MASK
            );
            mi.setAccelerator(ks);
          }



        public void actionPerformed(ActionEvent arg0)
        {
                String s = (String)arg0.getActionCommand();

                if (s == "O")
                {
                        //Datei �ffnen
                }

                if (s == "S")
                {
                        //Datei speichern
                }

                if (s == "B")
                {
                        dispose();
                        //Beenden
                }
        }
}
