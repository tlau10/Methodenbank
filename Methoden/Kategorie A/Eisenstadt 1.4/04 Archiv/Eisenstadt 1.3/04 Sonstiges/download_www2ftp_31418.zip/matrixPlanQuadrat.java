package AnwBESF;
/*
 * Created on 15.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class matrixPlanQuadrat
{
        final private int ID;

        final private int xKoordinate;
        final private int yKoordinate;

        private boolean passierbar;
        private boolean potentHalteStelle;
        private boolean festeHalteStelle;
        private int gewichtung;
        private int abstandNord;
        private int abstandOst;
        private int abstandWest;
        private int abstandSued;

        public matrixPlanQuadrat(int x, int y,int id)
        {
                ID = id;
                gewichtung = id;
                xKoordinate = x;
                yKoordinate = y;

                passierbar = true;
                potentHalteStelle = false;
                festeHalteStelle = false;
                abstandNord = 1;
                abstandOst = 1;
                abstandWest = 1;
                abstandSued = 1;
                gewichtung = 1;
        }

        public int holeID()
        {
                return ID;
        }

        public int holeX()
        {
                return xKoordinate;
        }

        public int holeY()
        {
                return yKoordinate;
        }

        public boolean holePassierbar()
        {
                return passierbar;
        }

        public void setzePassierbar(boolean wert)
        {
                passierbar = wert;
                potentHalteStelle = false;
                festeHalteStelle = false;
        }

        public boolean holePotentHalteStelle()
        {
                return potentHalteStelle;
        }

        public void setzePotentHalteStelle(boolean wert)
        {
                if (!wert)
                {
                        passierbar = true;
                }

                potentHalteStelle = wert;

                festeHalteStelle = false;
        }

        public boolean holeFesteHalteStelle()
        {
                return festeHalteStelle;
        }

        public void setzeFesteHalteStelle(boolean wert)
        {
                if (!wert)
                {
                        passierbar = true;
                        potentHalteStelle = wert;
                }

                festeHalteStelle = wert;
        }

        public int holeGewichtung()
        {
                return gewichtung;
        }

        public void setzeGewichtung(int wert)
        {
                gewichtung = wert;
        }

        public int holeAbstandNord()
        {
                return abstandNord;
        }

        public void setzeAbstandNord(int wert)
        {
                abstandNord = wert;
        }

        public int holeAbstandOst()
        {
                return abstandOst;
        }

        public void setzeAbstandOst(int wert)
        {
                abstandOst = wert;
        }

        public int holeAbstandSued()
        {
                return abstandSued;
        }

        public void setzeAbstandSued(int wert)
        {
                abstandSued = wert;
        }

        public int holeAbstandWest()
        {
                return abstandWest;
        }

        public void setzeAbstandWest(int wert)
        {
                abstandWest = wert;
        }

}
