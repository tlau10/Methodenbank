package AnwBESF;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Organisation: </p>
 * @author Jens
 * @version 1.0
 */

public class AbstandsMatrix {
//_________________________________________________________________________________
  private float abstandsMatrix[][];
  private Koordinate markierungsArray[];
  private int breite;
  private int laenge;
//_________________________________________________________________________________

  public AbstandsMatrix(int breite_, int laenge_)
  {
   breite = breite_;
   laenge = laenge_;
   int g=0;

   abstandsMatrix = new float[breite*laenge][laenge*breite];
   markierungsArray = new Koordinate[laenge*breite];

   for(int a=0; a < laenge; a++)
   {
     for(int b=0; b < breite; b++)
     {
       markierungsArray[g++] = new Koordinate(a+1,b+1);
     }
   }

   for(int x=0; x < (laenge*breite); x++)
   {
     for(int y=0; y < (laenge*breite); y++)
     {
       abstandsMatrix[x][y] = this.ermittleAbstaende(x,y);
     }
   }

   /*for(int x=0; x < (laenge*breite); x++) //Testausgabe der AbstandsMatrix
   {
     System.out.println();
     for(int y=0; y < (laenge*breite); y++)
     {
       System.out.print(abstandsMatrix[x][y]+"|");
     }
    }*/

 }
//_________________________________________________________________________________

    public void setElement(float wert, int x, int y)
    {
      abstandsMatrix[x][y] = wert;
    }
  //_________________________________________________________________________________

    public float[][] getAbstandsMatrix()
    {
     return abstandsMatrix;
    }
  //_________________________________________________________________________________


  public float ermittleAbstaende(int x, int y)
  {
    Koordinate von = markierungsArray[x];
    Koordinate nach = markierungsArray[y];
    float abstandX=0;
    float abstandY=0;
    float vonX=0, nachX=0, vonY=0, nachY=0;
    vonX = von.getX(); nachX = nach.getX();
    vonY = von.getY(); nachY = nach.getY();



    if((vonX == nachX) && (vonY == nachY))
    {
      return 0;
    }
    else if((vonX == nachX) && (vonY != nachY))
    {
      abstandY = (vonY - nach.getY());
      if(abstandY > 0) return abstandY;
      else return (abstandY * -1);
    }
    else if((vonX != nachX) && (vonY == nachY))
    {
      abstandX = (vonX - nachX);
      if(abstandX > 0) return abstandX;
      else return (abstandX * -1);
    }
    else if((vonX != nachX) && (vonY != nachY))
    {
      abstandY = (vonY - nachY);
      abstandX = (vonX - nachX);

      if(abstandX < 0) { abstandX *= -1; }
      if(abstandY < 0) { abstandY *= -1; }

      if(abstandX > abstandY) { abstandX -= abstandY; abstandY *= 1.5;  }
      else { abstandY -= abstandX; abstandX *= 1.5; }

      return (abstandX+abstandY);
    }
    else return 999;
  }
//_________________________________________________________________________________



}