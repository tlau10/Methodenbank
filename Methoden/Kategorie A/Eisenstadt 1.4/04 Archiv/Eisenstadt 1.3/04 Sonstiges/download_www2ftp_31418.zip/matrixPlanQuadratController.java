package AnwBESF;

import java.util.ArrayList;

/*
 * Created on 15.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class matrixPlanQuadratController
{
        private ArrayList planQuadratList;
        final private int xDim;
        final private int yDim;
        private matrixPlanQuadrat temp;

        public matrixPlanQuadratController(int x,int y)
        {
                planQuadratList = new ArrayList();
                xDim = x;
                yDim = y;
                temp = new matrixPlanQuadrat(0,0,0);
        }

        public matrixPlanQuadrat erstellePQ(int x,int y,int id)
        {  
        	matrixPlanQuadrat pQ = new matrixPlanQuadrat(x,y,id);
            setzePlanQuadrat(pQ);
            return(pQ);
        }

        private void setzePlanQuadrat(matrixPlanQuadrat pQ)
        {
                planQuadratList.add(pQ);
        }

        public ArrayList getGewichtungsMatrix()
        {
          return planQuadratList;
        }

        public matrixPlanQuadrat holePlanQuadrat(int id)
        {
                matrixPlanQuadrat pQ = (matrixPlanQuadrat)planQuadratList.get(id-1);

                return pQ;

                /*Iterator it = planQuadrateList.iterator();
                while (it.hasNext())
                {
                        matrixButton mButton = (matrixButton) it.next();
                        System.out.println(mButton.holeNameButton());
                }

                matrixButton mButton2 = (matrixButton)buttonList.get(2);
                System.out.println(mButton2.holeNameButton());
                mButton2 = (matrixButton)buttonList.get(0);
                System.out.println(mButton2.holeNameButton());

                listeAnzeige.setVisible(true);*/
        }

        public matrixPlanQuadrat holeNachbarnNord(int id)
        {
          if((id-xDim-1) > 0 && (id-xDim-1) < (xDim*yDim))
          {
            return (matrixPlanQuadrat)planQuadratList.get(id-xDim-1);
          }
          else
          {
            return temp;
          }
        }

        public matrixPlanQuadrat holeNachbarnOst(int id)
        {
          if((id) > 0 && id < (xDim*yDim) && (id%xDim != 0))
          {
          return(matrixPlanQuadrat)planQuadratList.get(id);
          }
          else
          {
            return temp;
          }
        }

        public matrixPlanQuadrat holeNachbarnSued(int id)
        {
         if((id+xDim-1) > 0 && (id+xDim-1) < (xDim*yDim))
         {
          return (matrixPlanQuadrat)planQuadratList.get(id+xDim-1);
         }
         else
          {
             return temp;
          }
        }

        public matrixPlanQuadrat holeNachbarnWest(int id)
        {
        if((id-2) > -1 && (id-2) < (xDim*yDim) && (id%xDim != 1) )
         {
           return (matrixPlanQuadrat) planQuadratList.get(id - 2);
         }
         else
         {
           return temp;
        }

        }
}
