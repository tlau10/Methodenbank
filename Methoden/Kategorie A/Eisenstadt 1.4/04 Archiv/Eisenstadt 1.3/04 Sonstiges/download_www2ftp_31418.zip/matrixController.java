package AnwBESF;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


/*
 * Created on 15.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class matrixController
{
        private matrixView mV;
        private matrixViewDef defFenster;
        private matrixViewAnzeige mVA;
        private matrixPlanQuadratController mPQC;
        private AbstandsMatrixView myABMV;
        private Solve mySolve;
        private AbstandsMatrix myABM;
        private int gebauteHaltestellen=1;

        public matrixController()
        {
                mV = new matrixView();
                mV.setVisible(true);

                aL aLDefFenster = new aL();
                berechnenListener berechnenListener = new berechnenListener();
                defFenster = new matrixViewDef(aLDefFenster,berechnenListener);
                mV.getContentPane().add(defFenster);

                defFenster.setVisible(true);
        }

        private void erstelleMatrixViewAnzeige()
        {
                //PlanQuadratController erstellen
                mPQC = new matrixPlanQuadratController(defFenster.holeX(),defFenster.holeY());

                //Anzeige erstellen
                mVA = new matrixViewAnzeige(defFenster.holeX(),defFenster.holeY());
                mVA.getContentPane().add(erstelleMatrixButtons(defFenster.holeX(),defFenster.holeY()));
                mV.getContentPane().add(mVA);
        }
        
        private void erstelleAbstandsMatrixViewAnzeige()
        {
        	if(defFenster.holeX() > 0 && defFenster.holeY() > 0)
    		{
        		myABMV = new AbstandsMatrixView(defFenster.holeX(),defFenster.holeY());
        		myABMV.getContentPane().add(erstelleAbstandsMatrixButtons(defFenster.holeX(),defFenster.holeY()));
    			myABMV.setVisible(true);
    			mV.getContentPane().add(myABMV);
    			System.out.println("KUCK MAL");
    			
    			mySolve = new Solve(myABM.getAbstandsMatrix(),mPQC.getGewichtungsMatrix(),defFenster.holeX(),defFenster.holeY(), mPQC);
    			mySolve.LPAnsatzGenerieren();
    		}  
        }

       private JScrollPane erstelleAbstandsMatrixButtons(int x, int y)
       {
        
         myABM = new AbstandsMatrix(x,y);

         AbstandsMatrixButton mB;
         aLButton aLB = new aLButton();

         JPanel jP = new JPanel();
         jP.setLayout(new GridLayout((x*y)+1,(x*y)+1));
         
         mB = new AbstandsMatrixButton("");
         jP.add(mB);

         //erste Zeile
         for (int i=0;i < (x*y) ; i++)
         {
             mB = new AbstandsMatrixButton(Integer.toString(i+1));
             jP.add(mB);
         }

         //ab der zweiten Zeile
         for(int i=0; i < (y*x); i++)
         {
           mB = new AbstandsMatrixButton(Integer.toString(i+1));
           jP.add(mB);

              for(int j=0; j < (x*y); j++)
              {
                 mB = new AbstandsMatrixButton((myABM.getAbstandsMatrix()[i][j]+""),i,j,myABM.getAbstandsMatrix()[i][j]);
                 mB.setActionCommand(Integer.toString(i) + "/" + Integer.toString(j));
                 jP.add(mB);
              }
          }

          jP.setVisible(true);
          JScrollPane jSP = new JScrollPane(jP);
          jSP.setVisible(true);
          return(jSP);
       }


        private JScrollPane erstelleMatrixButtons(int x,int y)
        {
                matrixButton mB;
                aLButton aLB = new aLButton();
                int id = 0;

                JPanel jP = new JPanel();
                jP.setLayout(new GridLayout(y+1,x+1));

                mB = new matrixButton("");
                jP.add(mB);


                //erste Zeile
                for (int i=1;i <= x;i++)
                {
                        mB = new matrixButton("x" + Integer.toString(i));
                        jP.add(mB);
                }

                //ab der zweiten Zeile
                for (int i=1;i <= y;i++)
                {
                        mB = new matrixButton("y" + Integer.toString(i));
                        jP.add(mB);

                        for (int xi=1;xi <= x;xi++)
                        {
                                id = (xi + (i - 1) * x);
                                mB = new matrixButton(Integer.toString(i) + "/" +
                                                Integer.toString(xi),i,xi,id,erstellePlanQuadrat(i,xi,id));
                                mB.setActionCommand(Integer.toString(i) + "/" + Integer.toString(xi));
                                mB.addActionListener(aLB);
                                jP.add(mB);
                        }
                }

                jP.setVisible(true);
                JScrollPane jSP = new JScrollPane(jP);
                jSP.setVisible(true);
                return(jSP);
        }

        private void buttonDefAnzeigen(matrixButton b)
        {
                matrixPlanQuadrat mPQ = mPQC.holePlanQuadrat(b.holeID());
                matrixButtonDef mBD = new matrixButtonDef(b);

                //Werte setzen
                boolean auswahl0 = mPQ.holePassierbar();
                boolean auswahl1 = mPQ.holePotentHalteStelle();
                boolean auswahl2 = mPQ.holeFesteHalteStelle();

                if (auswahl2)
                {
                  mBD.setzeAuswahl(2);
                }
                else if (auswahl1)
                {
                   mBD.setzeAuswahl(1);
                }
                else if (auswahl0)
                {
                   mBD.setzeAuswahl(0);
                }
                else
                {
                    mBD.setzeAuswahl(3);
                }

                mBD.setzeGewichtung(mPQ.holeGewichtung());
                mBD.setzeAbstandNord(mPQ.holeAbstandNord());
                mBD.setzeAbstandOst(mPQ.holeAbstandOst());
                mBD.setzeAbstandSued(mPQ.holeAbstandSued());
                mBD.setzeAbstandWest(mPQ.holeAbstandWest());

                ausgebenNachbarn(b.holeID());

                mBD.setVisible(true);
                mV.getContentPane().add(mBD);
        }

        private void ausgebenNachbarn(int id)
        {
                System.out.println("Nord:"+mPQC.holeNachbarnNord(id).holeID());
                System.out.println("Ost:"+mPQC.holeNachbarnOst(id).holeID());
                System.out.println("Sued:"+mPQC.holeNachbarnSued(id).holeID());
                System.out.println("West:"+mPQC.holeNachbarnWest(id).holeID());
                System.out.println("________________________________");
        }

        private matrixPlanQuadrat holePlanQuadrat(int x, int y,int id)
        {
                return mPQC.holePlanQuadrat(id);
        }

        private matrixPlanQuadrat erstellePlanQuadrat(int x,int y,int id)
        {
                return(mPQC.erstellePQ(x,y,id));
        }

        class aL implements ActionListener
        {
                public void actionPerformed(ActionEvent arg0)
                {
                        erstelleMatrixViewAnzeige();
                }
        }

        class berechnenListener implements ActionListener
        {
        	public void actionPerformed(ActionEvent arg0)
        	{
        		erstelleAbstandsMatrixViewAnzeige();
        	}
        }

        class aLButton implements ActionListener
        {
                public void actionPerformed(ActionEvent arg0)
                {
                        matrixButton quellButton = (matrixButton)arg0.getSource();
                        buttonDefAnzeigen(quellButton);
                }
        }

}
