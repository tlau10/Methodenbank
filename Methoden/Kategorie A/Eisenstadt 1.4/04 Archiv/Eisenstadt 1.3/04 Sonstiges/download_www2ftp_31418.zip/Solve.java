package AnwBESF;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Organisation: </p>
 * @author Jens
 * @version 1.0
 */
import java.util.*;
import java.io.*;


public class Solve {

  private ArrayList gewichtungsMatrix;
  private int laenge;
  private int breite;
  private float[][] abstandsMatrix;
  private matrixPlanQuadratController mPQC;
  private StringBuffer lpSolveOutput;
  private Vector myStringVector;


  public Solve(float[][] abstandsMatrix_, ArrayList gewichtungsMatrix_, int breite_, int laenge_, matrixPlanQuadratController mPQC_)
  {
    mPQC = mPQC_;
  	abstandsMatrix = abstandsMatrix_;
    gewichtungsMatrix = gewichtungsMatrix_;
    breite = breite_;
    laenge = laenge_;
	myStringVector  = new Vector();
	lpSolveOutput   = new StringBuffer();

  }

  public void LPAnsatzGenerieren()
  {
    File eingabeDatei = new File("eingabe.lp");
    String zielFunktion = new String("min: ");
    String restriktionen = new String("");
    String x = new String("x");
    String[] schalterVariablen;
    int gesamtAnzahl = breite*laenge;
    int squareGesamtAnzahl = gesamtAnzahl*gesamtAnzahl;
    int anzahlMoeglicheHaltestellen=0;
    int gesamtGewichtung=0;
    Vector moeglicheHaltestellen = new Vector();
    matrixPlanQuadrat myPlanQuadrat;

    
   
    
//---------EIGENSCHAFTEN ------------------------------------------------------
    
    for(int a=0; a < gewichtungsMatrix.size(); a++) // Potentielle Haltestellen ermitteln und in Vector speichern
    {
    	myPlanQuadrat = (matrixPlanQuadrat)gewichtungsMatrix.get(a);
    	gesamtGewichtung += myPlanQuadrat.holeGewichtung();
    	
    	if(myPlanQuadrat.holePotentHalteStelle() || myPlanQuadrat.holeFesteHalteStelle())
    	{
    		moeglicheHaltestellen.add(myPlanQuadrat);
    	}
    }
    anzahlMoeglicheHaltestellen = moeglicheHaltestellen.size(); // "moeglicheHaltestellen" beinhaltet auch feste Haltestellen
    schalterVariablen = new String[anzahlMoeglicheHaltestellen];

//---------ZIELFUNKTION--------------------------------------------------------
    int counter=0;
    int zfLaenge = anzahlMoeglicheHaltestellen*gesamtAnzahl;
    int halteStelle=0;
    for(int b=0; b < gewichtungsMatrix.size(); b++)
    {
    	myPlanQuadrat = (matrixPlanQuadrat)gewichtungsMatrix.get(b);
    	
    	if(myPlanQuadrat.holePotentHalteStelle() || myPlanQuadrat.holeFesteHalteStelle())
    	{
    		halteStelle++;
    		if(myPlanQuadrat.holeFesteHalteStelle()) restriktionen += (x + (halteStelle+zfLaenge) + "=1;"); //Schaltervariable f�r feste Haltestelle auf 1 setzen.
    		for(int i=0; i < gesamtAnzahl; i++) 
    		{
    			counter++;
    			if(counter <= zfLaenge) // "Normal" immer hier rein
    			{	
    				if(abstandsMatrix[b][i] != 0.0) // 0.0 Werte nicht in ZF aufnehmen, sonst erschweren "Warnings" das Auslesen des Ergebnisses sp�ter
    				{
    					zielFunktion += (abstandsMatrix[b][i] + x + counter + "+");
    				}
    			}
    			
    		}
    	}
    }

    if(zielFunktion.endsWith("+"))
    {
    	zielFunktion = (zielFunktion.substring(0, (zielFunktion.length()-1)))+ ";"; 
    }
   
    
//---------GEWICHTUNGS-RESTRIKTIONEN-------------------------------------------
    int index=1;
    int gewichtungsIndex = 1;
    for(int c=0; c < gesamtAnzahl; c++)
    {
    	myPlanQuadrat = (matrixPlanQuadrat)gewichtungsMatrix.get(c);
    	gewichtungsIndex = index;
    	for(int b=1; b <= anzahlMoeglicheHaltestellen; b++)
    	{
    		if(b < anzahlMoeglicheHaltestellen) restriktionen += (x + gewichtungsIndex + "+");
    		else restriktionen += (x + gewichtungsIndex + "=" + myPlanQuadrat.holeGewichtung()+ ";");
    		
    		gewichtungsIndex += gesamtAnzahl;
    	}
    	index++;
    }

//---------HALTESTELLEN-RESTRIKTIONEN------------------------------------------
    index=1;
    counter = 0;
    int schalterVariableIndex = anzahlMoeglicheHaltestellen*gesamtAnzahl+1;

    for(int d=0; d < anzahlMoeglicheHaltestellen; d++)
    {
    	for(int f=1; f <= gesamtAnzahl; f++)
    	{
    		if(f < gesamtAnzahl) restriktionen += (x + index++ + "+");
    		else {
    			schalterVariablen[counter++] = (x + schalterVariableIndex);
    			restriktionen += (x + index++ + "+" + gesamtGewichtung + x + schalterVariableIndex + "<=" + gesamtGewichtung + ";");
    			schalterVariableIndex++;
    		}	
    	}
    }

//---------SCHALTER-RESTRIKTION------------------------------------------------
    String temp = new String();
    for(int g=0; g < anzahlMoeglicheHaltestellen; g++)
    {
    	if(g < (anzahlMoeglicheHaltestellen-1))
    	{
    		restriktionen += (schalterVariablen[g] + "+");
    		temp += (schalterVariablen[g] + "<=1;"); // Schaltervariablen <= 1
    	}
    	else 
    	{
    		restriktionen += (schalterVariablen[g] + "=" + anzahlMoeglicheHaltestellen + ";");
    		temp += (schalterVariablen[g] + "<=1;"); // Schaltervariablen <= 1
    	}
    }
    restriktionen += temp; 
    for(int h=0; h < anzahlMoeglicheHaltestellen; h++)
    {
    	if(h < (anzahlMoeglicheHaltestellen-1))
    	{
    		restriktionen += ("int " + schalterVariablen[h] + ";");
    	}
    	else restriktionen += ("int " + schalterVariablen[h] + ";");
    }
    
    try {
    	FileOutputStream fos = new FileOutputStream("c:/LP_ANSATZ.TXT");
    	zielFunktion += restriktionen;
    	fos.write(zielFunktion.getBytes());
    	fos.close();
    }
    catch(Exception e) { e.printStackTrace(); }
    //this.calculate(zielFunktion+restriktionen);
  }

  private boolean calculate(String dataSet)
	{
	String _ERROR_MSG 	= "ERROR: ";
	String _WARNING_MSG = "WARNING: ";
  	 // if there are not data --> return
	  	if(dataSet.equals(""))
	  		return false;
	  	
	  
	  BufferedReader p_inBuffer;
	  String proc_input_string = "";
		try
		{
			  //create the process
		  	Process proc = Runtime.getRuntime().exec("c:\\LP_SOLVE.EXE");

		  	//get the streams
			  InputStream  proc_in  = proc.getInputStream();
			  InputStream  prog_err = proc.getErrorStream();
		  	int exit              = 0;
		    boolean processEnded  = false;

	      //push the data to the lpsolve
	      OutputStream proc_out  = proc.getOutputStream();
	      DataOutputStream out_s = new DataOutputStream(proc_out);
	      out_s.writeBytes(dataSet);
	      out_s.close();
	      proc_out.close();

	      // fetch the output from the LPsolve
	      while(!processEnded)
	      {
	      	try {
	      		exit = proc.exitValue();
	      		processEnded = true;
	      	}
	      	catch(IllegalThreadStateException e) {
	      	} // still running

	      	int n = proc_in.available();
	        if(n > 0) {
	                byte[] pbytes = new byte[n];
	                proc_in.read(pbytes);
	                lpSolveOutput.append(new String(pbytes));
	        }
	        n = prog_err.available();
	        if(n > 0) {
	                byte[] pbytes = new byte[n];
	                prog_err.read(pbytes);
	                _ERROR_MSG += new String(pbytes);
	        }
	        try {
	        	Thread.sleep(10);
	        }
	        catch(InterruptedException e) {
	        }

		    } // ### END-while ###

		//close/destroy all handles
		prog_err.close();
	    	proc_in.close();
		proc.destroy();
		} catch (IOException e) {
	    	// System.err.println("exeption-error:" + e);
	    	_ERROR_MSG += "\nIO error: " + e;
	    	myStringVector.add(0,"error");
	    	myStringVector.add(1,_ERROR_MSG);
	    	return false;
		}

		System.out.println("-->"+lpSolveOutput.length()+"<--");
		for(int x=0; x < lpSolveOutput.length(); x++)
		{
			System.out.println(lpSolveOutput.charAt(x));
		}
		
		
		
		
		return true;
	} // ### END-calculateLPsolve


}