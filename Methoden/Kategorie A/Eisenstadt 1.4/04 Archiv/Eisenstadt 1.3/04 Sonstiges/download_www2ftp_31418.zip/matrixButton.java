package AnwBESF;
/*
 * Created on 13.05.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.awt.Color;
import javax.swing.JButton;

public class matrixButton extends JButton
{
        private int id;
        private int x;
        private int y;

        private int auswahl;
        private int gewichtung;
        private int abstandNord;
        private int abstandOst;
        private int abstandSued;
        private int abstandWest;
        private matrixPlanQuadrat mPQ;

        public matrixButton(String t)
        {
                super(t);
                setBackground(Color.BLUE);
                setForeground(Color.WHITE);
                setEnabled(false);
        }

        public matrixButton(String t,int pX,int pY,int sID,matrixPlanQuadrat pQ)
        {
                super(Integer.toString(sID));
                id = sID;

                mPQ = pQ;

                x = pX;
                y = pY;
                setBackground(Color.lightGray);
                setForeground(Color.BLACK);
        }

        public int holeID()
        {
                return id;
        }

        public int holeX()
        {
                return x;
        }

        public int holeY()
        {
                return y;
        }

        public void setzeAuswahl(int a)
        {
                switch (a)
                {
                case 0:
                {
                        mPQ.setzePassierbar(true);
                        setForeground(Color.BLACK);
                        setBackground(Color.YELLOW);
                        break;
                }
                case 1:
                {
                        mPQ.setzePotentHalteStelle(true);
                        setForeground(Color.WHITE);
                        setBackground(Color.GREEN);
                        break;
                }
                case 2:
                {
                        mPQ.setzeFesteHalteStelle(true);
                        setBackground(Color.RED);
                        setForeground(Color.WHITE);
                        break;
                }
                default:
                {
                        setForeground(Color.WHITE);
                        setBackground(Color.WHITE);
                };
                }

        }

        public int holeAuswahl()
        {
                return auswahl;
        }

        public int holeGewichtung()
        {
                return gewichtung;
        }

        public void setzeGewichtung(int wert)
        {
                mPQ.setzeGewichtung(wert);
        }

        public int holeAbstandNord()
        {
                return abstandNord;
        }

        public void setzeAbstandNord(int wert)
        {
                mPQ.setzeAbstandNord(wert);
        }

        public int holeAbstandOst()
        {
                return abstandOst;
        }

        public void setzeAbstandOst(int wert)
        {
                mPQ.setzeAbstandOst(wert);
        }

        public int holeAbstandSued()
        {
                return abstandSued;
        }

        public void setzeAbstandSued(int wert)
        {
                mPQ.setzeAbstandSued(wert);
        }

        public int holeAbstandWest()
        {
                return abstandWest;
        }

        public void setzeAbstandWest(int wert)
        {
                mPQ.setzeAbstandWest(wert);
        }
}
