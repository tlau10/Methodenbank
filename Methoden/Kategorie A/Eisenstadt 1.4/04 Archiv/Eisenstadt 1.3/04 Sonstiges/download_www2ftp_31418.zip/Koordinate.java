package AnwBESF;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Organisation: </p>
 * @author Jens
 * @version 1.0
 */

public class Koordinate {

  private int x;
  private int y;

  public Koordinate(int xDim, int yDim) {
    x = xDim;
    y = yDim;
  }

  public int getX()
  {
    return x;
  }

  public int getY()
  {
    return y;
  }
}