package logic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.*;

import com.csvreader.CsvReader;

public class SpeichernOeffnen {
	// Methode um Pfad auszuw�hlen
	public static String fileChooserDialog(String String) {
		// Variable dekl./init.
		String pfadAuswahl = null;

		// JFileChooser-Objekt erstellen
		JFileChooser chooser = new JFileChooser();

		if (String == "speichern_unter") {
			// Dialog zum speichern_unter von Dateien anzeigen

			// ONA Try-Catch Funktion eingef�gt um Cancel Button zu �berpr�fen

			try {

				if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
					// gew�hlten Pfadnamen in Variable speichern
					pfadAuswahl = chooser.getSelectedFile().getAbsolutePath();
					System.out.println("der gew�hlte Pfad ist:" + pfadAuswahl);
				} else {
					pfadAuswahl = null;
					System.out.println("File-Save as -Funktion wurde abgebrochen (Cancel): " + pfadAuswahl);
				}
			} catch (Exception e) {
				System.out.println("File-Save as -Funktion wurde abgebrochen: " + pfadAuswahl);
			}

		} else {
			// Dialog zum Oeffnen von Dateien anzeigen
			chooser.setFileFilter(new SpeichernOeffnen().new MyFilter(".wwa"));

			// "Alle Dateien" Filter deaktivieren
			chooser.setAcceptAllFileFilterUsed(false);

			// ONA Try-Catch Funktion eingef�gt um Cancel Button zu �berpr�fen

			try {

				if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					pfadAuswahl = chooser.getSelectedFile().getAbsolutePath();
					System.out.println("der gew�hlte Pfad ist:" + pfadAuswahl);
				} else {
					pfadAuswahl = null;
					System.out.println("File-Open-Funktion wurde abgebrochen (Cancel): " + pfadAuswahl);
				}

			} catch (Exception e) {
				System.out.println("File-Open-Funktion wurde abgebrochen: " + pfadAuswahl);
			}
		}
		return pfadAuswahl;
	}

	// ONA hier wird das �ffnen der nicht .WWA Dateien verhindert

	public class MyFilter extends FileFilter {
		private String endung = ".wwa";

		public MyFilter(String endung) {
			this.endung = endung;
		}

		@Override
		public boolean accept(File chooser) {
			if (chooser == null) {
				return false;
			} else
			// Ordner anzeigen
			if (chooser.isDirectory()) {
				return true;
			}
			// true, wenn File gewuenschte Endung besitzt
			else {
				return chooser.getName().toLowerCase().endsWith(endung);
			}
		}

		@Override
		public String getDescription() {
			return endung;
		}
	}

	/**
	 * 
	 * @param tabellenWerte
	 * @param bestellKostenSatz
	 * @param periodenZahl
	 * @param Pfad
	 * 
	 *            Diese Methode speichert aktuelle Daten aus der
	 *            Benutzeroberf�che in eine WWA-Datei
	 */

	public static void save(Object[][] tabellenWerte, String bestellKostenSatz, String periodenZahl, String Pfad) {// �bergibt
																													// den
																													// Tabelleninhalt,
																													// den
																													// R�st-/Bestellkostensatz,
																													// die
																													// Anzahl
																													// der
																													// Perioden
																													// und
																													// den
																													// Speicherpfad
		try {

			BufferedWriter writer = new BufferedWriter(new FileWriter(Pfad + ".wwa")); // Pfad
																						// variabel
																						// +
																						// Dateiendung
			writer.write(bestellKostenSatz);
			writer.newLine();
			writer.write(periodenZahl); // AnzahlPerioden in Datei schreiben
			writer.newLine();
			// ab hier werden die Daten aus der Tabelle eingelesen
			for (int i = 0; i < tabellenWerte.length; i++) {
				for (int j = 0; j < tabellenWerte[i].length; j++) {
					writer.write(tabellenWerte[i][j] + ";"); // mit Semikolon
																// getrennte
																// Werte
																// (Spaltentrennung)
				}
				writer.newLine(); // Zeilentrennung
				System.out.println(i);
			}
			writer.close();
		} catch (IOException e) {
			System.out.println("Fehler beim ueberschreiben");
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param file
	 * @return
	 * 
	 * 		Diese Methode ladet eine bestehende .wwa Datei
	 */

	public static String[][] read(String file) {
		List<String[]> list = new ArrayList<String[]>();
		int zeile;
		zeile = 0;// Initialisierung der Perioden
		try {
			BufferedReader read = new BufferedReader(new FileReader(file));
			String in = read.readLine();

			while (in != null) {
				// sonderbehandlung erste Zeile da hier der Bestellkostensatz
				// stehen wird
				if (zeile == 0) {
					try {
						logic.WagWhit.setRuestkosten(Double.parseDouble(in)); // R�stkosten-/Bestellkostensatz
																				// wird
																				// eingelesen
						in = read.readLine();
						logic.WagWhit.setAnzahlPerioden(Integer.parseInt(in));// entspricht
																				// PeriodenAnzahl
																				// die
																				// eingelesen
																				// und
																				// f�r
																				// die
																				// Berechnung
																				// ben�tigt
																				// wird
						in = read.readLine();
					} catch (Exception e) {
						JOptionPane.showMessageDialog(new JFrame(),
								"Fehler beim Einlesen, Bestellkosten-Wert ist keine Zahl (Double) ",
								"Fehlerhafte Datei", JOptionPane.ERROR_MESSAGE);
					}
				} else {
					String[] line = in.split(";");
					list.add(line);
					in = read.readLine();
				}

				zeile += 1;
			}
			read.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		String[][] tmp = new String[list.size()][];

		return list.toArray(tmp);
	}

}
