package gui;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.xml.stream.util.StreamReaderDelegate;

import java.awt.Label;
import java.awt.Scrollbar;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Kurzinfo extends JFrame {

	private JPanel contentPane;

	/**
	 * �ffnet ein neues Fenster
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Kurzinfo frame = new Kurzinfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Erstellt den Rahmen und setzt den Inhalt
	 */
	public Kurzinfo() {
		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		// Gr��e des Fensters
		setBounds(100, 100, 700, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel help_text = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(0, 0, 0, 0);

		// Inhalt der Hilfeseite

		JLabel text1 = new JLabel("<html><p>" + "<strong><u>1. Hilfe zum Tool</u></strong></p>"
				+ "<p>Hier eine kurze Erkl�rung/Hilfe zum Tool (f�r ausf�hrliche Informationen bitte das Benutzerhandbuch aufrufen)</p><br/><br/>"
				+ "<p><strong>1.1. </strong><strong><u>Neues Modell erstellen</u></strong></p>"
				+ "<p>  - Eingabe von Bestellkostensatz, Anzahl der Perioden und dem Lagerkostensatz</p>"
				+ "<p>  - Fixe oder variable Lagerkosten festlegen durch aktivieren des Hakens</p>"
				+ "<p>  - Auf �Weiter!� klicken</p>"
				+ "<p>  - Bedarfe eintragen (und bei Bedarf var. Lagerkosten)</p><br/><br/>"
				+ "<p><strong>1.2. </strong><strong><u>Datei speichern</u></strong></p>"
				+ "<p>  - Men� --&gt; �Datei� --&gt; �speichern�</p>"
				+ "<p>  - Pfad und Dateiname ausw�hlen</p><br/><br/>"
				+ "<p><strong>1.3. </strong><strong><u>Datei Laden</u></strong></p>"
				+ "<p>  - Men� --&gt; �Datei� --&gt; �Laden�</p>" + "<p>  - Pfad und Datei ausw�hlen<br/><br/></p><br/>"
				+ "<p><strong>1.4. </strong><strong><u>Benutzerhandbuch</u></strong></p>"
				+ "<p>  - Im Men� �Info� ist das Benutzerhandbuch zu finden.</p>");

		JLabel link = new JLabel(
				"<html>" + "- <a href=\"\">Hier</a> sind ausf�hrliche Information zur Methode hinterlegt </html>");
		link.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		link.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {

				if (e.getClickCount() > 0) {
					try {

						InputStream inputStream;
						inputStream = this.getClass().getResourceAsStream("/Benutzerhandbuch Wagner-Whitin 1.2.pdf");
						File tempFile = File.createTempFile("Benutzerhandbuch Wagner-Whitin 1.2", ".pdf");
						FileOutputStream outPutStream = new FileOutputStream(tempFile);

						byte buffer[] = new byte[1024];
						int len;
						while ((len = inputStream.read(buffer)) > 0) {
							outPutStream.write(buffer, 0, len);
						} // while

						outPutStream.close();
						inputStream.close();

						// copy(inputStream, outPutStream);
						Desktop.getDesktop().open(tempFile);
					} catch (IOException ex) {
						ex.printStackTrace();
					}

				}
			}
		});

		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 10;
		help_text.add(text1, c);

		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;

		help_text.add(link, c);

		// Gr��e und Ausrichtung des Textfeldes (hier mittig)
		help_text.setBounds(100, 100, 300, 300);

		contentPane.add(help_text);
		contentPane.add(help_text, BorderLayout.CENTER);

	}

}
