//*******************************************************************
//*																	*
//*		Teil des P.L.O. Systems (c) 2001/2002						*
//* 	von Francis Goeltner, Helmut Lindinger, Bernd Saile			*
//*																	*
//*		Synopsis: Enth�lt die Klasse f�r den Datentyp, welcher	    *
//*		die Nachfrqagen eines Modells verwaltet		  				*
//*																	*
//*		Version: 1.0												*
//*																	*
//*     Version 1.2 												*
//*     von Marco Wei� und Jenne Justin								*
//*																	*
//*******************************************************************

package plo_System;

//public class plo_ModellSpeichernDialog extends FileChooserDialog
//{
//	public void plo_ModellSpeichernDialog()
//	{
//
//	}
//
//}