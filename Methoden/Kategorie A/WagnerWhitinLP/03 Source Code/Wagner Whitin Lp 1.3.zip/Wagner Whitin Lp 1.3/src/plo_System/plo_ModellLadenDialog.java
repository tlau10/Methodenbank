//*******************************************************************
//*																	*
//*		Teil des P.L.O. Systems (c) 2001/2002						*
//* 	von Francis Goeltner, Helmut Lindinger, Bernd Saile			*
//*																	*
//*		Synopsis: Enth�lt die Klasse f�r den Datentyp, welcher	    *
//*		die Nachfrqagen eines Modells verwaltet		  				*
//*																	*
//*		Version: 1.0												*
//*																	*
//*     Version 1.2 												*
//*     von Marco Wei� und Jenne Justin								*
//*																	*
//*******************************************************************

package plo_System;
import java.awt.*;

public class plo_ModellLadenDialog extends FileDialog
{

	public plo_ModellLadenDialog(Frame parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = -4532168788537231054L;
		
}