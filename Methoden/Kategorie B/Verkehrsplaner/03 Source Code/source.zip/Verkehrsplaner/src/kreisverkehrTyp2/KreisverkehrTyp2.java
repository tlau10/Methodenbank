/*
 * Created on 26.09.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package kreisverkehrTyp2;

import java.util.LinkedList;
import verkehrsplaner.Ereignis;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Fahrzeug;
import verkehrsplaner.FahrzeugListe;
import verkehrsplaner.Kreuzung;
import verkehrsplaner.NormaleStrasse;
import verkehrsplaner.Physik;
import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Simulationslogik;
import verkehrsplaner.Status;
import verkehrsplaner.Warteschlange;
import verkehrsplaner.Zufallszahlen;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class KreisverkehrTyp2  implements Kreuzung {
	
	private KreisverkehrTyp2Einstellungen daten;
	private Simulationslogik logik;
	private Physik physik;
	private FahrzeugListe angekuendigteFahrzeuge;
	private Simulationsabschnitt[] anbindung;
	private double zeit;
	
	private double segmentlaenge;
	private int anzahlSegmente, segmentMultiplikator;
	
	private int[] einfahrt;
	private int[] ausfahrt;
	
	private double[][] abbiegenWahl; //Wahrkeit fuer Abbiegen je nach Einfahrt
	private Warteschlange[] ws = new Warteschlange[4];
	
	private KreisverkehrTyp2Segment[] segment;
	
	//Variablen f�r das blockierSystem
	private KreisverkehrTyp2Container[] blockierteFahrzeug = new KreisverkehrTyp2Container[4];
	
	
	public KreisverkehrTyp2(KreisverkehrTyp2Einstellungen daten){
		this.daten = daten;
		
		angekuendigteFahrzeuge = new FahrzeugListe();
		anbindung = new Simulationsabschnitt[4];
		physik = new Physik();
	
	}
	
	private KreisverkehrTyp2Segment nachfolgerSegment(KreisverkehrTyp2Segment akt){
		int i = akt.getNummer();
		i--;
		if(i<0){
			i+=anzahlSegmente;
		}
		return segment[i];
	}
	
	private KreisverkehrTyp2Segment vorgaengerSegment(KreisverkehrTyp2Segment akt){
		int i = akt.getNummer();
		i++;
		if(i>=anzahlSegmente){
			i-=anzahlSegmente;
		}
		return segment[i];
	}

	public Ergebnis getErgebnis() {
		Ergebnis e = new Ergebnis(daten.getId());
		
		for(int i=0;i<4;i++){
			e.addWS(ws[i].getErgebnis());
		}
		
		int[] anzahlFahrzeuge = {0,0,0,0};
		double[] durchsWSlaenge = {0.0,0.0,0.0,0.0};
		double[] durchsWartezeit = {0.0,0.0,0.0,0.0};
		double[] prozAuslastung = {0.0,0.0,0.0,0.0};
		double[] prozStau = {0.0,0.0,0.0,0.0};
		int[] maxLaenge = {0,0,0,0};
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				
//			 	aktuelle WS l�nge
				anzahlFahrzeuge[i] = e.getWS(i).getAnzahlFahrzeuge();

//				 durchs. WS l�nge
				durchsWSlaenge[i] = e.getWS(i).getDurchsWartendeFahrzeuge();

//				 durchs. Wartezeit
				durchsWartezeit[i] = e.getWS(i).getDurchsVerweilzeitWS();

//				 proz. Stra�enauslastung
				prozAuslastung[i] = e.getWS(i).getProzentualeStrassenauslastung();
					
//				 proz. Stau
				prozStau[i] = e.getWS(i).getProzentualBlockiert();

//				Max WS L�nge
				maxLaenge[i] = e.getWS(i).getMaxAnzahlFahrzeuge();
			}
		}
		
		e.setAnzahlFahrzeuge(anzahlFahrzeuge);
		e.setDurchsWSlaenge(durchsWSlaenge);
		e.setDurchsWartezeit(durchsWartezeit);
		e.setProzAuslastung(prozAuslastung);
		e.setProzStau(prozStau);
		e.setMaxLaenge(maxLaenge);
		
		return e;
	}

	public void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung) {
		if(himmelsrichtung >= 0 && himmelsrichtung < 4){
			this.anbindung[himmelsrichtung] = anbindung;
		}
		else{
			System.err.println("Fehlerhafte Zuweisung - Stra�e "+daten.getId()+" Richtung:"+himmelsrichtung);
		}
	}

	public void ereignisHandler(Ereignis e) {
		zeit=e.getZeitpunkt();
		double zeitKontrolle = e.getZeitpunkt();
		
		//System.out.println(e.getFahrzeug().getID()+"V: "+e.getFahrzeug().getGeschwindigkeit());
		
		if(e.getTyp().equals("ankunft")){
			ankunft(e.getFahrzeug());
		}
		else if (e.getTyp().equals("bedienEnde")){
			bedienEnde(((KreisverkehrTyp2Container) e.getFahrzeug()));
		}
		else if (e.getTyp().equals("kontrolle")){
			// neue Fahrzeuge einfahren lassen, falls alles leer
			//kontrollEreignis();//TODO
		}
		else{
			System.err.println("Unbekanntes Ereignis" + e.getTyp());
		}
		
		if(zeit < zeitKontrolle){
			System.err.println("Zeit wurde ver�ndert");
		}
		
//		if(zeit > 100 && zeit < 120){
//			for(int i=0;i<anzahlSegmente;i++){
//				System.err.print("Segment "+i+" Status:"+segment[i].getStatus());
//				if(segment[i].getAktFahrzeug() != null){
//					System.err.print(" Aktuelles Fahrzeug "+segment[i].getAktFahrzeug().getID());
//				}
//				if(segment[i].getBlockiertesFahrzeug() != null){
//					System.err.print(" Blockiertes Fahrzeug "+segment[i].getBlockiertesFahrzeug().getID());
//				}
//				System.err.println("");
//			}
//			System.err.println("---------------------------------------");
//		}
		
	}
	
	private void kontrollEreignis(){
		//Ereignis(double zeitpunkt, Fahrzeug fahrzeug, String typ, Simulationsabschnitt standort){
		Ereignis f = new Ereignis(zeit+3.2, null, "kontrolle", this);
		logik.pushEreignis(f);
		int tmp = anzahlSegmente/2;
		
		//	 neue Fahrzeuge einfahren lassen, falls min 50% leer
		for(int i=0;i<anzahlSegmente;i++){
			if (!segment[i].getStatus().equals("frei")){
				tmp--;
				if(tmp <= 0)
					return;
			}
		}
		
		for(int i=0;i<4;i++){
			if(ws[i].getLaenge(zeit) > 0){
//				neuesBedienEndeEreignis((KreisverkehrTyp2Container)ws[i].pop(zeit));
//				return;
				erstesFahrzeugAusWSeinfahrenlassen(i);
			}
		}
	}

	private boolean vonLinksKommtNichts(KreisverkehrTyp2Segment aktuellesSegment, KreisverkehrTyp2Container f){
		int fahrzeugLaenge = f.getLaengeInSegmenten()+1; //TODO Versuch Totalblockade zu verhindern
		
		KreisverkehrTyp2Segment tmp = aktuellesSegment;
		for(int i=0;i<fahrzeugLaenge;i++){
			tmp = vorgaengerSegment(tmp);
			
			if(!(tmp.getStatus().equals("frei") || tmp.getStatus().equals("ausfahrend"))){
				return false;
			}
		}
		return true;
	}
	
	private void bedienEnde(KreisverkehrTyp2Container f){
		
		KreisverkehrTyp2Segment head = f.getHead();
		KreisverkehrTyp2Segment tail = f.getTail();
		
		//Verl�sst das Auto den Kreisel?
		if(head == f.getAusfahrtSegment()){
			if (head==tail){//Das Auto-Heck verl�sst den Kreisel
				Ereignis e = new Ereignis(logik.getZeit(), f, "ankunft", head.getAusfahrt());
				logik.pushEreignis(e);
				segmentWirdFrei(head); //eventl. Blockade beheben und aus WS einfahren lassen
				
				//Eventl. andere Autos einfahren lassen
				KreisverkehrTyp2Segment nachfolger = nachfolgerSegment(head);
				for(int i=0;i<anzahlSegmente;i++){
					if(nachfolger.getWs() != null){
						if(nachfolger.getWs().getLaenge(zeit) > 0)
							erstesFahrzeugAusWSeinfahrenlassen(nachfolger.getWs());
					}
					nachfolger = nachfolgerSegment(nachfolger);
				}
				
//				KreisverkehrTyp2Segment nachfolger = nachfolgerSegment(head);
//				if(nachfolger.getStatus().equals("frei")){		//Eventl. Fahrzeug im Nachfolgesegment einfahren lassen
//					segmentWirdFrei(nachfolger);			//Dies ist notwendig -> da manche Fahrzeuge warten bis da� Fahrzeug draussen ist
//				}			//TODO					//Ansonstens kann es zu Einfahrtblockade trotz freiem Kreisel f�hren
//
//				for(int i=0;i<4;i++){	//TODO Kontrollieren ob es so funktioniert
//					if(ws[i].getLaenge(zeit) > 0){
//						erstesFahrzeugAusWSeinfahrenlassen(i);
//					}
//				}
			}
			else{
				//Auto f�hrt weiter aus dem Kreisel aus
				neuesBedienEndeEreignis(f);
			}
		}
		else{
			//Auto f�hrt weiter im Kreisel
			if(f.getNextHead().getStatus().equals("frei")){ //Auto f�hrt normal weiter
				neuesBedienEndeEreignis(f);
			}
			else{
				head.setStatus("blockiert");
				f.getNextHead().setBlockiertesFahrzeug(f);
			}
		}
	}
	
	private void segmentWirdFrei(KreisverkehrTyp2Segment s){
		s.setAktFahrzeug(null);
		s.setStatus("frei");
		
		//Blockade aufheben
		if(s.getBlockiertesFahrzeug() != null){
			KreisverkehrTyp2Container f = s.getBlockiertesFahrzeug();
			s.setBlockiertesFahrzeug(null);
			f.getHead().setStatus("belegt");
			
			//Geschwindigkeitsverlust durch die Blockade erfassen-!!!!
			f.setGeschwindigkeit(Physik.getGeschwindigkeitsverlustDurchBlockade(f, zeit, segmentlaenge));
			
			bedienEnde(f);
		}
		else if(s.getWs() != null){	//Eventl. Auto aus WS einfahren lassen!!!
			if(s.getWs().getLaenge(zeit) > 0){
				
				//�berpr�fen ob eine Blockade der AusfahrtStrase vorliegt
				KreisverkehrTyp2Container nextF = (KreisverkehrTyp2Container) s.getWs().nextFahrzeug();
				boolean ausfahrtStrasseBlockiert = false;
				
				if(anbindung[nextF.getAusfahrt()].isBlockiert(this)){
					ausfahrtStrasseBlockiert = true;
					blockierteFahrzeug[nextF.getEinfahrt()] = nextF;
				}
				
				
//				String status = vorgaengerSegment(s).getStatus();	
				if(!ausfahrtStrasseBlockiert && vonLinksKommtNichts(s,nextF)){
					KreisverkehrTyp2Container f = (KreisverkehrTyp2Container) s.getWs().pop(zeit);
					
					
					
					//Eventl. anfahren in der Gruppe erm�glichen (Geschw. vorteil)
					KreisverkehrTyp2Container letztesF = s.getLetztesFahrzeug();
					
					//Falls das letzte Fahrzeug auch in diesem Segment gestartet ist -> Anfahren in der Gruppe
					if(letztesF != null && letztesF.getEinfahrtSegment() == s){

						f.setGeschwindigkeit(Physik.getGeschwindigkeitBeimAnfahrenInDerGruppe(f, letztesF));
					}
					
					
					//Neues BeidenEndeEreignis f�r das Fahrzeug planen
					neuesBedienEndeEreignis(f);
				}
			}
		}
	}


	public void ankunft(Fahrzeug f) {
		//FahrzeugContainer suchen
		KreisverkehrTyp2Container a = (KreisverkehrTyp2Container)angekuendigteFahrzeuge.holeFahrzeugAusListeNachID(f.getID());
		a.fahrzeugErreichtWS(zeit);
		a.setStandort(this);
		
		//Fahrzeug bereits beim n�chsten Segment anmelden
		double maxNaechstes=a.getAusfahrtSegment().getAusfahrt().getMaxGeschwindigkeit(this,f);
		a.setMaxVfuerNaechstesSegment(maxNaechstes);
		
		//�berpr�fen ob das Segment, in welches das Fahrzeug abbiegen will, nicht blockiert ist
		boolean ausfahrtStrasseBlockiert = a.getAusfahrtSegment().getAusfahrt().isBlockiert(this);
		
		//Einfahrendes Segment ermitteln
		KreisverkehrTyp2Segment einfahrt = a.getNextHead();
		
		//Kontrollieren ob das Segment frei, ob von links was kommt und ob eine WS exisitiert 
		if(einfahrt.getStatus().equals("frei") && 	
				vonLinksKommtNichts(einfahrt,a)
				&& ws[a.getEinfahrt()].getLaenge(zeit) == 0 && (!ausfahrtStrasseBlockiert)){
			//Fahrzeug kann einfahren
			neuesBedienEndeEreignis(a);
		}
		else{
			//Fahrzeug muss in die Warteschlange
			a.setGeschwindigkeit(0.0);//Auto verliert die Geschwindigkeit in der WS
			ws[a.getEinfahrt()].push(a,zeit);
			if(ws[a.getEinfahrt()].getLaenge(zeit) > 0){ //TODO Eventl. Fahrzeug einfahren lassen
				erstesFahrzeugAusWSeinfahrenlassen(a.getEinfahrt());
			}
		}
	}
	
	private void erstesFahrzeugAusWSeinfahrenlassen(Warteschlange ws){
		if(ws == this.ws[0])
			erstesFahrzeugAusWSeinfahrenlassen(0);
		else if(ws == this.ws[1])
			erstesFahrzeugAusWSeinfahrenlassen(1);
		else if(ws == this.ws[2])
			erstesFahrzeugAusWSeinfahrenlassen(2);
		else if(ws == this.ws[3])
			erstesFahrzeugAusWSeinfahrenlassen(3);
	}
	
	private void erstesFahrzeugAusWSeinfahrenlassen(int wsNummer){
		KreisverkehrTyp2Container a = (KreisverkehrTyp2Container) ws[wsNummer].nextFahrzeug();
		
		//�berpr�fen ob das Segment, in welches das Fahrzeug abbiegen will, nicht blockiert ist
		boolean ausfahrtStrasseBlockiert = a.getAusfahrtSegment().getAusfahrt().isBlockiert(this);
		
		//Einfahrendes Segment und Vorg�ndersegment ermitteln
		KreisverkehrTyp2Segment einfahrt = a.getNextHead();
		
		//Kontrollieren ob das Segment frei, ob von links was kommt
		if(einfahrt.getStatus().equals("frei") && 	
				vonLinksKommtNichts(einfahrt,a) && (!ausfahrtStrasseBlockiert)){
			//Fahrzeug kann einfahren
			neuesBedienEndeEreignis((KreisverkehrTyp2Container) ws[wsNummer].pop(zeit));
		}
	}
	
	private void neuesBedienEndeEreignis(KreisverkehrTyp2Container aktuellesAuto){
		
		aktuellesAuto.setZeitLetztesBedienEnde(zeit);
		
		double zeitpunkt=0.0;
		//double maxV = Physik.getMaxGeschwindigkeitInDerKurve(daten.getRadius(),aktuellesAuto.getHorizontaleBeschleunigung());
		double maxV = aktuellesAuto.getMaxV();
		double maxNaechstes;
		
		aktuellesAuto.schritt();	//Head und Tail um 1 Segment weiter bewegen
		KreisverkehrTyp2Segment head = aktuellesAuto.getHead();
		KreisverkehrTyp2Segment tail = aktuellesAuto.getTail();
		KreisverkehrTyp2Segment ausfahrt = aktuellesAuto.getAusfahrtSegment();
		
		
		if(head == ausfahrt){	//Fahrzeug f�hrt aus dem Kreisel aus
			head.setStatus("ausfahrend");
			maxNaechstes=aktuellesAuto.getMaxVfuerNaechstesSegment(); //Rausbeschleunigen
		}
		else{	//Fahrzeug f�hrt im Kreisel
			head.setStatus("belegt");
			maxNaechstes=maxV;
		}
		head.setAktFahrzeug(aktuellesAuto);
		
		if(tail != null && tail != aktuellesAuto.getEinfahrtSegment()){
				// Freigeben des Vorgaengersegments
			KreisverkehrTyp2Segment frei =vorgaengerSegment(tail);
			segmentWirdFrei(frei);  //eventl. Blockade beheben und aus WS einfahren lassen
		}

		//Geschwindikeiten und Endzeitpunkte berechnen
		zeitpunkt =physik.zeitBerechnen(segmentlaenge, maxV, maxNaechstes, aktuellesAuto.getFahrzeug());
		
		//System.out.println("Zeit:"+zeitpunkt);
		zeitpunkt += zeit;
		
		//Ereignis(double zeitpunkt, Fahrzeug fahrzeug, String typ, Simulationsabschnitt standort){
		Ereignis e = new Ereignis(zeitpunkt,aktuellesAuto,"bedienEnde",this);
		logik.pushEreignis(e);
	}

	public double getMaxGeschwindigkeit(Simulationsabschnitt herkunft, Fahrzeug f) {
		//Einfahrt ermitteln
		int einfahrt;
		if(herkunft == anbindung[0]){
			einfahrt = 0;
		}
		else if(herkunft == anbindung[1]){
			einfahrt = 1;
		}
		else if(herkunft == anbindung[2]){
			einfahrt = 2;
		}
		else if(herkunft == anbindung[3]){
			einfahrt = 3;
		}
		else{
			System.err.println("herkunft: " + f.getStandort());
			System.err.println("anbindung0: " + anbindung[0]);
			System.err.println("anbindung1: " + anbindung[1]);
			System.err.println("anbindung2: " + anbindung[2]);
			System.err.println("anbindung3: " + anbindung[3]);
			System.err.println("Fehlerhafte Herkunft - "+getTyp()+" "+daten.getId()+" Fahrzeug:"+f.getID());
			return Physik.getMaxGeschwindigkeitInDerKurve(daten.getRadius(),f.getHorizontaleBeschleunigung());
		}

		//Abbiegen und Ausfahrt ermitteln
		double sum=0.0;
		for(int i=0;i<3;i++){
			sum += abbiegenWahl[einfahrt][i];
		}
		double tmp=0.0;
		int abbiegen=0;
		double zufallsZahl=Zufallszahlen.drand();
		for(int i=0;i<3;i++){			//Abbiegen ermitteln
			tmp += abbiegenWahl[einfahrt][i]/sum;
			if (zufallsZahl < tmp){
				abbiegen = i;
				break;
			}
		}
		
		int ausfahrt = einfahrt;

		if (abbiegen == 0){	//Rechts abbiegen
			ausfahrt += 3;	
		}
		else if (abbiegen == 1){ //Geradeaus fahren
			ausfahrt += 2;
		}
		else{ 			//Links abbiegen
			ausfahrt += 1;
		}

		if (ausfahrt >= 4){
			ausfahrt -= 4;
		}
		
		//ermitteln der Route
		int kreiselEinfahrt = einfahrt*segmentMultiplikator-1;	//Anpassung fuer Kreisel
		int kreiselAusfahrt = ausfahrt*segmentMultiplikator;  //Anpassung fuer Kreisel  */
		if(kreiselEinfahrt < 0){
			kreiselEinfahrt += anzahlSegmente;
		}
		
		//Route initialisieren
		LinkedList route= new LinkedList();
		boolean weiter=true;
		int i = kreiselEinfahrt;
		while(weiter){
			route.addLast(segment[i]);
			
			if(i==kreiselAusfahrt){
				weiter=false;
			}
			i--;
			if(i<0){
				i += anzahlSegmente;
			}
		}
		
		//FahrzeugContainer erstellen und in die Ank�ndigungsliste stellen
		KreisverkehrTyp2Container c = 
			new KreisverkehrTyp2Container(f,einfahrt,abbiegen,ausfahrt,route,segmentlaenge);
		c.setVorherigenStandort(herkunft);
		angekuendigteFahrzeuge.push(c);
		
		//MaxV berechnen
		double maxV = Physik.getMaxGeschwindigkeitInDerKurve(daten.getRadius(),f.getHorizontaleBeschleunigung());
		c.setMaxV(maxV);
		
//		System.out.println("MaxV "+Physik.getMaxGeschwindigkeitInDerKurve(daten.getRadius(),f.getHorizontaleBeschleunigung()));
		return maxV;
	}

	public boolean pruefeInitalisierung() {
		if(logik == null){
			return false;
		}
		
		abbiegenWahl = daten.getAbbiegenWahl();
		
		//�berpr�fen der Strassenanzahl von Einfahrten und Ausfahrten
		int anzahlStrassen=4;
		for(int i=0;i<4;i++){
			if(anbindung[i] == null){
				
				if(anzahlStrassen < 3){	//Falls es schon nur 2 Strassen hat
					System.err.println("Fehler: " +daten.getName()+" hat zuwenig Strassen / "+anzahlStrassen+"/"+i);
					return false;	//TODO Kontrollieren
				}
				anzahlStrassen--;


				 //Abbiegen in die nicht existierende Strasse verhindern
				for(int j=0;j<3;j++){
					int strasse=i + (j+1);
					
					if(strasse > 3){
						strasse -=4;
					}
					
					abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
				}
			}
			else{
				//F�r jede Strasse, welche in die Kreuzung m�ndet muss min. 1 andere wieder weg f�hren
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenZurKreuzung(daten.getId()) > 0){
					
					boolean ausfahrtVorhanden=false;
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						if(anbindung[strasse] != null){
							if(((NormaleStrasse)anbindung[strasse]).getAnzahlSpurenVonKreuzungWeg(daten.getId()) > 0){
								ausfahrtVorhanden=true;
								break;
							}
						}
					}
					
					if(!ausfahrtVorhanden){
						System.err.println("Fehler: " +daten.getName()+" hat zuwenig Ausfahrt");
						return false;	//TODO Kontrollieren
					}
				}
				
				//Falls es eine Einbahnstrasse ist
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenVonKreuzungWeg(daten.getId())<1){
					 //Falsches Abbiegen in die Einbahnstrasse verhindern
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
					}
				}
			}
		}
		daten.setAbbiegenWahl(abbiegenWahl);
		
		//Initialisierungszeug-------------------------->
//		System.err.println("Initialisierung -- Kreisel "+daten.getId());
		for(int i=0;i<4;i++){
			double laenge=1.0;
			if(anbindung[i] != null){
				laenge = anbindung[i].getLaengeFuerWS(this);
			}
			ws[i] = new Warteschlange((NormaleStrasse)anbindung[i],this,laenge);
		}
		
		ws[0].setBeschreibung("Nord");
		ws[1].setBeschreibung("Ost");
		ws[2].setBeschreibung("S�d");
		ws[3].setBeschreibung("West");
		
		
//		Segmentanzahl berechnen
		double kreisUmfang = 2.0*daten.getRadius()*Math.PI;
		
		if(kreisUmfang<9.0){
			System.err.println("Fehler Kreisverkehr"+daten.getId()+" :Zu kleiner Kreisumfang (min 9m)");
			kreisUmfang=9.0;
		}
		else if(kreisUmfang>250.0){
			System.err.println("Fehler Kreisverkehr"+daten.getId()+" :Zu grosser Kreisumfang (max 250m)");
			kreisUmfang=250.0;
		}
		
		int i;
		for(i=1;i<20;i++){
			double s = kreisUmfang/(i*4.0);
			if(s<=4.0 && s>=2.0){
				break;
			}
		}
		segmentMultiplikator=i;
		anzahlSegmente = 4*i;
		segmentlaenge=kreisUmfang/anzahlSegmente;
		
		//Berechnungen der Ausfahrt
		ausfahrt = new int[4];
		ausfahrt[0] = 0;
		ausfahrt[1] = anzahlSegmente/4;
		ausfahrt[2] = anzahlSegmente/2;
		ausfahrt[3] = anzahlSegmente-ausfahrt[1];
		
		//Einfahrten berechnen
		einfahrt = new int[4];
		for(int j=0;j<4;j++){
			einfahrt[j] = ausfahrt[j]-1;
			if(einfahrt[j]<0){
				einfahrt[j] += anzahlSegmente;
			}
		}
		
		segment = new KreisverkehrTyp2Segment[anzahlSegmente];
		for(int j=0;j<anzahlSegmente;j++){
			segment[j] = new KreisverkehrTyp2Segment(j);
			
			//Ausfahrten bestimmen
			if(j==ausfahrt[0]){
				segment[j].setAusfahrt(anbindung[0]);
			}
			else if(j==ausfahrt[1]){
				segment[j].setAusfahrt(anbindung[1]);
			}
			else if(j==ausfahrt[2]){
				segment[j].setAusfahrt(anbindung[2]);
			}
			else if(j==ausfahrt[3]){
				segment[j].setAusfahrt(anbindung[3]);
			}
			
			//Einfahrten bestimmen
			if(j==einfahrt[0]){
				segment[j].setWs(ws[0]);
			}
			else if(j==einfahrt[1]){
				segment[j].setWs(ws[1]);
			}
			else if(j==einfahrt[2]){
				segment[j].setWs(ws[2]);
			}
			else if(j==einfahrt[3]){
				segment[j].setWs(ws[3]);
			}
		}
		
		//Kontroll-Events anstarten
		Ereignis f = new Ereignis(5.0, null, "kontrolle", this);
		logik.pushEreignis(f);
		
		return true;
	}

	public String getTyp() {
		return "KreisverkehrTyp2";
	}

	public int getID() {
		return daten.getId();
	}

	public int getMaxAnbindungen() {
		return 4;
	}

	public void setSimulationslogik(Simulationslogik logik) {
		this.logik = logik;
	}

	public boolean isBlockiert(Simulationsabschnitt aufrufer) {
		return false; //Kreuzung ist (momentan) nicht blockierbar
	}

	public void setBlockiert(Simulationsabschnitt aufrufer, double zeit) {
//		Kreuzung ist (momentan) nicht blockierbar
	}

	public void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit) {
		this.zeit = zeit; //aktuelle Zeit setzen
//		System.err.println("Blockade aufheben "+aufrufer.getID());
		for(int i=0;i<4;i++){
			if(blockierteFahrzeug[i] != null && 
					!blockierteFahrzeug[i].getAusfahrtSegment().getAusfahrt().isBlockiert(this)){
				fahrzeugBlockadeAufheben((KreisverkehrTyp2Container) ws[i].nextFahrzeug(),ws[i]);
//				System.err.println("--->Blockade Aufheben "+this.getID()+" WS:"+i);
				blockierteFahrzeug[i] = null;
			}
			else if(ws[i].getLaenge(zeit) >0 && 
					!((KreisverkehrTyp2Container)ws[i].nextFahrzeug()).getAusfahrtSegment().getAusfahrt().isBlockiert(this)){
				fahrzeugBlockadeAufheben((KreisverkehrTyp2Container) ws[i].nextFahrzeug(),ws[i]);
			}
		}
		
		if(aufrufer.isBlockiert(this)){
			System.err.println("Diese Blockade d�rfte es nicht geben");
		}
	}
	
	private void fahrzeugBlockadeAufheben(KreisverkehrTyp2Container f, Warteschlange ws){
		if(f == null){
			return;
		}
		
		//Einfahrendes Segment und Vorg�ndersegment ermitteln
		KreisverkehrTyp2Segment einfahrt = f.getNextHead();
		
		//Kontrollieren ob das Segment frei, ob von links was kommt 
		if(einfahrt.getStatus().equals("frei") && 	
				vonLinksKommtNichts(einfahrt,f)){
			//Fahrzeug kann einfahren
//			System.err.println("Blockade aufheben");
			neuesBedienEndeEreignis((KreisverkehrTyp2Container)ws.pop(zeit));
		}
	}

	public double getLaengeFuerWS(Simulationsabschnitt aufrufer) {
		return 3.0; //Kreuzung bietet kaum Platz f�r eine WS
	}


	public Status getStatus() {
		Status s = new Status(daten.getId());
		s.setAnzahlWS(4);
		int[] wsId = new int[4]; 
		int[] wsLaenge = new int[4]; 
		
//		System.err.println("getStatus -- Kreisel "+daten.getId());
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				wsId[i] = anbindung[i].getID();
			}
			else{
				wsId[i] = -1;
			}
			wsLaenge[i] = ws[i].getLaenge(zeit);
		}
		s.setWsId(wsId);
		s.setWsLaenge(wsLaenge);

		
		String info="";
		for(int i=0;i<anzahlSegmente;i++){
			info += "Segment "+Integer.toString(i)+" Status "+segment[i].getStatus();
			if(segment[i].getAktFahrzeug() != null){
				info += "  Fahrzeug:"+Integer.toString(segment[i].getAktFahrzeug().getID());
			}
			info += "\n";
		}
		
		
		
//		info += "\t"+getSegmentStatus(7)+getSegmentStatus(0)+"\n";//Geht nur bei 8 Segmentkreisverkehren
//		info += getSegmentStatus(6)+"\t\t"+getSegmentStatus(1)+"\n";
//		info += getSegmentStatus(5)+"\t\t"+getSegmentStatus(2)+"\n";
//		info += "\t"+getSegmentStatus(4)+getSegmentStatus(3)+"\n";
		
		
		s.setInfoText(info);
		return s;
	}
	
	private String getSegmentStatus(int segmentnr){
		if(segment[segmentnr].getAktFahrzeug() != null){
			return Integer.toString(segment[segmentnr].getAktFahrzeug().getID())+"\t";
		}
		else{
			return "__\t";
		}
	}
	
}
