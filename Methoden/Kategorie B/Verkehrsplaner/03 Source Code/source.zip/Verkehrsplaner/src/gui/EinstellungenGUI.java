/*
 * Created on 16.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import verkehrsplaner.AllgemeineEinstellungen;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EinstellungenGUI extends JDialog{
	private static final long serialVersionUID = 8045049657736162721L;
	private AllgemeineEinstellungen daten;
	private JPanel panel1 = new JPanel();

	private JPanel jPanel1 = new JPanel();
	private FlowLayout flowLayout1 = new FlowLayout();
	private JButton btOK = new JButton();
	private JButton btAbbrechen = new JButton();
	private JPanel jPanel2 = new JPanel();
	private JPanel jPanel3 = new JPanel();
	private JPanel jPanel4 = new JPanel();
	private GridLayout gridLayout21 = new GridLayout(1,2);
	private GridLayout gridLayout32 = new GridLayout(15,1);
	private GridLayout gridLayout43 = new GridLayout(15,2);
	private JLabel jLabel1 = new JLabel();
	private JLabel jLabel2 = new JLabel();
	private JLabel jLabel3 = new JLabel();
	
	private JLabel label11 = new JLabel();
	private JTextField tfPkwLaengeErwartungswert = new JTextField();
	private JTextField tfLkwLaengeErwartungswert = new JTextField();
	
	private JLabel label12 = new JLabel();
	private JTextField tfPkwLaengeStandardabweichung = new JTextField();
	private JTextField tfLkwLaengeStandardabweichung = new JTextField();
	
	private JLabel label13 = new JLabel();
	private JTextField tfPkwBeschleunigungsErwartungswert = new JTextField();
	private JTextField tfLkwBeschleunigungsErwartungswert = new JTextField();

	private JLabel label14 = new JLabel();
	private JTextField tfPkwBeschleunigungsStandardabweichung = new JTextField();
	private JTextField tfLkwBeschleunigungsStandardabweichung = new JTextField();
	
	private JLabel label15 = new JLabel();
	private JTextField tfPkwBeschleunigungMin = new JTextField();
	private JTextField tfLkwBeschleunigungMin = new JTextField();
	
	private JLabel label22 = new JLabel();
	private JTextField tfPkwBeschleunigungMax = new JTextField();
	private JTextField tfLkwBeschleunigungMax = new JTextField();
	
	private JLabel label16 = new JLabel();
	private JTextField tfPkwBremsenErwartungswert = new JTextField();
	private JTextField tfLkwBremsenErwartungswert = new JTextField();
	
	private JLabel label17 = new JLabel();
	private JTextField tfPkwBremsenStandardabweichung = new JTextField();
	private JTextField tfLkwBremsenStandardabweichung = new JTextField();
	
	private JLabel label18 = new JLabel();
	private JTextField tfPkwBremsenMin = new JTextField();
	private JTextField tfLkwBremsenMin = new JTextField();
	
	private JLabel label23 = new JLabel();
	private JTextField tfPkwBremsenMax = new JTextField();
	private JTextField tfLkwBremsenMax = new JTextField();
	
	private JLabel label19 = new JLabel();
	private JTextField tfPkwHorizontaleBeschlErwartungswert = new JTextField();
	private JTextField tfLkwHorizontaleBeschlErwartungswert = new JTextField();
	
	private JLabel label20 = new JLabel();
	private JTextField tfPkwHorizontaleBeschlStandardabweichung = new JTextField();
	private JTextField tfLkwHorizontaleBeschlStandardabweichung = new JTextField();
	
	private JLabel label21 = new JLabel();
	private JTextField tfPkwHorizontaleBeschlMin = new JTextField();
	private JTextField tfLkwHorizontaleBeschlMin = new JTextField();
	
	private JLabel label24 = new JLabel();
	private JTextField tfPkwHorizontaleBeschlMax = new JTextField();
	private JTextField tfLkwHorizontaleBeschlMax = new JTextField();

	
	public EinstellungenGUI(Frame frame, String title, boolean modal) {
		super(frame, title, modal);
	    try {
	      jbInit();
	      pack();
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	}

	public EinstellungenGUI() {
	    this(null, "", false);
	}

	public EinstellungenGUI(AllgemeineEinstellungen daten, GuiController controller) {
	  this(null, "", false);
	  this.daten = daten;
	}
	
	private void jbInit() throws Exception {
	    panel1.setLayout(null);
	    jPanel1.setBounds(new Rectangle(1, 395, 600, 38));//UntereButtons
	    jPanel1.setLayout(flowLayout1);
	    btOK.setText("OK");
	    btOK.addActionListener(new ActionListener()  {
	        public void actionPerformed(ActionEvent e) {
	        	btOK_actionPerformed(e);
	          }
	        });
	    btAbbrechen.setText("Abbrechen");
	    btAbbrechen.addActionListener(new ActionListener()  {
	        public void actionPerformed(ActionEvent e) {
	        	btAbbrechen_actionPerformed(e);
	          }
	        });
	    jPanel2.setBounds(new Rectangle(5, 10, 500, 375));
	    jPanel2.setLayout(gridLayout21);
	    jPanel3.setLayout(gridLayout32);
	    jPanel4.setLayout(gridLayout43);
	    jLabel1.setText("Zufallszahl in m bzw m/s^2:");
	    jLabel2.setText("PKW:");
	    jLabel3.setText("LKW:");
	    
	    label11.setText("Fahrzeugl�nge Erwartungswert");
	    label12.setText("Fahrzeugl�nge Standardabweichung");
	    label13.setText("Beschleunigung Erwartungswert");
	    label14.setText("Beschleunigung Standardabweichung");
	    label15.setText("Beschleunigung Minimum");
	    label22.setText("Beschleunigung Maximum");
	    label16.setText("Bremsenbeschleunigung Erwartungswert");
	    label17.setText("Bremsenbeschleunigung Standardabweichung");
	    label18.setText("Bremsenbeschleunigung Minimum");
	    label23.setText("Bremsenbeschleunigung Maximum");
	    label19.setText("Horizontale Beschl. Erwartungswert");
	    label20.setText("Horizontale Beschl. Standardabweichung");
	    label21.setText("Horizontale Beschl. Minimum");
	    label24.setText("Horizontale Beschl. Maximum");
	    
	    jPanel2.add(jPanel3, null);
	    jPanel2.add(jPanel4, null);
	    
	    jPanel3.add(jLabel1, null);
	    jPanel4.add(jLabel2, null);
	    jPanel4.add(jLabel3, null);
	    
	    jPanel3.add(label11,null);
	    jPanel4.add(tfPkwLaengeErwartungswert,null);
	    jPanel4.add(tfLkwLaengeErwartungswert,null);
		
	    jPanel3.add(label12,null);
	    jPanel4.add(tfPkwLaengeStandardabweichung,null);
	    jPanel4.add(tfLkwLaengeStandardabweichung,null);
		
	    jPanel3.add(label13,null);
	    jPanel4.add(tfPkwBeschleunigungsErwartungswert,null);
	    jPanel4.add(tfLkwBeschleunigungsErwartungswert,null);

	    jPanel3.add(label14,null);
	    jPanel4.add(tfPkwBeschleunigungsStandardabweichung,null);
	    jPanel4.add(tfLkwBeschleunigungsStandardabweichung,null);
		
	    jPanel3.add(label15,null);
	    jPanel4.add(tfPkwBeschleunigungMin,null);
	    jPanel4.add(tfLkwBeschleunigungMin,null);
	    
	    jPanel3.add(label22,null);
	    jPanel4.add(tfPkwBeschleunigungMax,null);
	    jPanel4.add(tfLkwBeschleunigungMax,null);
		
	    jPanel3.add(label16,null);
	    jPanel4.add(tfPkwBremsenErwartungswert,null);
	    jPanel4.add(tfLkwBremsenErwartungswert,null);
		
	    jPanel3.add(label17,null);
	    jPanel4.add(tfPkwBremsenStandardabweichung,null);
	    jPanel4.add(tfLkwBremsenStandardabweichung,null);
		
	    jPanel3.add(label18,null);
	    jPanel4.add(tfPkwBremsenMin,null);
	    jPanel4.add(tfLkwBremsenMin,null);
	    
	    jPanel3.add(label23,null);
	    jPanel4.add(tfPkwBremsenMax,null);
	    jPanel4.add(tfLkwBremsenMax,null);
		
	    jPanel3.add(label19,null);
	    jPanel4.add(tfPkwHorizontaleBeschlErwartungswert,null);
	    jPanel4.add(tfLkwHorizontaleBeschlErwartungswert,null);
		
	    jPanel3.add(label20,null);
	    jPanel4.add(tfPkwHorizontaleBeschlStandardabweichung,null);
	    jPanel4.add(tfLkwHorizontaleBeschlStandardabweichung,null);
		
	    jPanel3.add(label21,null);
	    jPanel4.add(tfPkwHorizontaleBeschlMin,null);
	    jPanel4.add(tfLkwHorizontaleBeschlMin,null);
	    
	    jPanel3.add(label24,null);
	    jPanel4.add(tfPkwHorizontaleBeschlMax,null);
	    jPanel4.add(tfLkwHorizontaleBeschlMax,null);
	    
	    getContentPane().add(panel1);
	    panel1.add(jPanel1, null);
	    jPanel1.add(btOK, null);
	    jPanel1.add(btAbbrechen, null);
	    panel1.add(jPanel2, null);


	}
	
	  public void initialisieren(AllgemeineEinstellungen daten){
	  	this.daten  = daten;
	  	
	  	tfPkwLaengeErwartungswert.setText(Double.toString(daten.getPkwLaengeErwartungswert()));
	  	tfLkwLaengeErwartungswert.setText(Double.toString(daten.getLkwLaengeErwartungswert()));
	  	
	  	tfPkwLaengeStandardabweichung.setText(Double.toString(daten.getPkwLaengeStandardabweichung()));
	  	tfLkwLaengeStandardabweichung.setText(Double.toString(daten.getLkwLaengeStandardabweichung()));
	  	
	  	tfPkwBeschleunigungsErwartungswert.setText(Double.toString(daten.getPkwBeschleunigungsErwartungswert()));
	  	tfLkwBeschleunigungsErwartungswert.setText(Double.toString(daten.getLkwBeschleunigungsErwartungswert()));

	  	tfPkwBeschleunigungsStandardabweichung.setText(Double.toString(daten.getPkwBeschleunigungsStandardabweichung()));
	  	tfLkwBeschleunigungsStandardabweichung.setText(Double.toString(daten.getLkwBeschleunigungsStandardabweichung()));
	  	
	  	tfPkwBeschleunigungMin.setText(Double.toString(daten.getPkwBeschleunigungMin()));
	  	tfLkwBeschleunigungMin.setText(Double.toString(daten.getLkwBeschleunigungMin()));
	  	
	  	tfPkwBeschleunigungMax.setText(Double.toString(daten.getPkwBeschleunigungMax()));
	  	tfLkwBeschleunigungMax.setText(Double.toString(daten.getLkwBeschleunigungMax()));
	  	
	  	tfPkwBremsenErwartungswert.setText(Double.toString(daten.getPkwBremsenErwartungswert()));
	  	tfLkwBremsenErwartungswert.setText(Double.toString(daten.getLkwBremsenErwartungswert()));
	  	
	  	tfPkwBremsenStandardabweichung.setText(Double.toString(daten.getPkwBremsenStandardabweichung()));
	  	tfLkwBremsenStandardabweichung.setText(Double.toString(daten.getLkwBremsenStandardabweichung()));
	  	
	  	tfPkwBremsenMin.setText(Double.toString(daten.getPkwBremsenMin()));
	  	tfLkwBremsenMin.setText(Double.toString(daten.getLkwBremsenMin()));
	  	
	  	tfPkwBremsenMax.setText(Double.toString(daten.getPkwBremsenMax()));
	  	tfLkwBremsenMax.setText(Double.toString(daten.getLkwBremsenMax()));
	  	
	  	tfPkwHorizontaleBeschlErwartungswert.setText(Double.toString(daten.getPkwHorizontaleBeschlErwartungswert()));
	  	tfLkwHorizontaleBeschlErwartungswert.setText(Double.toString(daten.getLkwHorizontaleBeschlErwartungswert()));
	  	
	  	tfPkwHorizontaleBeschlStandardabweichung.setText(Double.toString(daten.getPkwHorizontaleBeschlStandardabweichung()));
	  	tfLkwHorizontaleBeschlStandardabweichung.setText(Double.toString(daten.getLkwHorizontaleBeschlStandardabweichung()));
	  	
	  	tfPkwHorizontaleBeschlMin.setText(Double.toString(daten.getPkwHorizontaleBeschlMin()));
	  	tfLkwHorizontaleBeschlMin.setText(Double.toString(daten.getLkwHorizontaleBeschlMin()));
	  	
	  	tfPkwHorizontaleBeschlMax.setText(Double.toString(daten.getPkwHorizontaleBeschlMax()));
	  	tfLkwHorizontaleBeschlMax.setText(Double.toString(daten.getLkwHorizontaleBeschlMax()));
	  }

	  void btOK_actionPerformed(ActionEvent e) {

	  	daten.setPkwLaengeErwartungswert(Double.parseDouble(tfPkwLaengeErwartungswert.getText()));
	  	daten.setLkwLaengeErwartungswert(Double.parseDouble(tfLkwLaengeErwartungswert.getText()));
	  	
	  	daten.setPkwLaengeStandardabweichung(Double.parseDouble(tfPkwLaengeStandardabweichung.getText()));
	  	daten.setLkwLaengeStandardabweichung(Double.parseDouble(tfLkwLaengeStandardabweichung.getText()));
	  	
	  	daten.setPkwBeschleunigungsErwartungswert(Double.parseDouble(tfPkwBeschleunigungsErwartungswert.getText()));
	  	daten.setLkwBeschleunigungsErwartungswert(Double.parseDouble(tfLkwBeschleunigungsErwartungswert.getText()));
	  	
	  	daten.setPkwBeschleunigungsStandardabweichung(Double.parseDouble(tfPkwBeschleunigungsStandardabweichung.getText()));
	  	daten.setLkwBeschleunigungsStandardabweichung(Double.parseDouble(tfLkwBeschleunigungsStandardabweichung.getText()));
	  	
	  	daten.setPkwBeschleunigungMin(Double.parseDouble(tfPkwBeschleunigungMin.getText()));
	  	daten.setLkwBeschleunigungMin(Double.parseDouble(tfLkwBeschleunigungMin.getText()));
	  	
	  	daten.setPkwBeschleunigungMax(Double.parseDouble(tfPkwBeschleunigungMax.getText()));
	  	daten.setLkwBeschleunigungMax(Double.parseDouble(tfLkwBeschleunigungMax.getText()));
	  	
	  	daten.setPkwBremsenErwartungswert(Double.parseDouble(tfPkwBremsenErwartungswert.getText()));
	  	daten.setLkwBremsenErwartungswert(Double.parseDouble(tfLkwBremsenErwartungswert.getText()));
	  	
	  	daten.setPkwBremsenStandardabweichung(Double.parseDouble(tfPkwBremsenStandardabweichung.getText()));
	  	daten.setLkwBremsenStandardabweichung(Double.parseDouble(tfLkwBremsenStandardabweichung.getText()));
	  	
	  	daten.setPkwBremsenMin(Double.parseDouble(tfPkwBremsenMin.getText()));
	  	daten.setLkwBremsenMin(Double.parseDouble(tfLkwBremsenMin.getText()));
	  	
	  	daten.setPkwBremsenMax(Double.parseDouble(tfPkwBremsenMax.getText()));
	  	daten.setLkwBremsenMax(Double.parseDouble(tfLkwBremsenMax.getText()));
	  	
	  	daten.setPkwHorizontaleBeschlErwartungswert(Double.parseDouble(tfPkwHorizontaleBeschlErwartungswert.getText()));
	  	daten.setLkwHorizontaleBeschlErwartungswert(Double.parseDouble(tfLkwHorizontaleBeschlErwartungswert.getText()));
	  	
	  	daten.setPkwHorizontaleBeschlStandardabweichung(Double.parseDouble(tfPkwHorizontaleBeschlStandardabweichung.getText()));
	  	daten.setLkwHorizontaleBeschlStandardabweichung(Double.parseDouble(tfLkwHorizontaleBeschlStandardabweichung.getText()));
	  	
	  	daten.setPkwHorizontaleBeschlMin(Double.parseDouble(tfPkwHorizontaleBeschlMin.getText()));
	  	daten.setLkwHorizontaleBeschlMin(Double.parseDouble(tfLkwHorizontaleBeschlMin.getText()));
	  	
	  	daten.setPkwHorizontaleBeschlMax(Double.parseDouble(tfPkwHorizontaleBeschlMax.getText()));
	  	daten.setLkwHorizontaleBeschlMax(Double.parseDouble(tfLkwHorizontaleBeschlMax.getText()));
	  	
	    this.setVisible(false);
	  }

	  void btAbbrechen_actionPerformed(ActionEvent e) {
	    this.setVisible(false);
	  }
}
