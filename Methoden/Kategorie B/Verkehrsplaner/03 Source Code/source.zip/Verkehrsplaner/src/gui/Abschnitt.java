package gui;

import java.awt.*;

import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Status;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public interface Abschnitt {

public int getId();
public void paintMe(Graphics g);
public boolean istInPosition(int x, int y);
public String getType();
public void zeigeEinstellungen();
public void zeigeAnimationsDetails();
public EinstellungsDaten getEinstellungen();
public void addAbschnitt(Abschnitt a, int himmelsrichtung);
public int getMaxAnbindungen();
public void zeigeNamen(boolean b);
public void setErgebnis(Ergebnis e);
public void setErgebnisModus(int modus);
public void setStatus(Status s);
public void setPos(int x, int y);
public int getX();
public int getY();
public void zeigeErgebnis();
public String getNamen();
}
