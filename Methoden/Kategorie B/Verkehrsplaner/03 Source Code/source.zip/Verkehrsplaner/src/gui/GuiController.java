package gui;

import java.awt.*;
//import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JPanel;


import java.util.*;
//import java.awt.*;
import java.awt.event.*;


/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class GuiController extends JPanel {
  private static final long serialVersionUID = 8053669289645284335L;
  private Vector liste = new Vector();
  private StrassenAbschnitt tempStrasse;
  private int idCounter=0;
  private UndoController undoController;
  private String hintergrund = null;
  private boolean zeigeNamen=false;
  private int oldHeight=100;
  private int oldWidth=100;


  public GuiController() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
    
    undoController = new UndoController(this);
  }
  
  public void zeigeNamen(boolean zeigen){
  	for(int i=0;i<liste.size();i++){
  		((Abschnitt)liste.get(i)).zeigeNamen(zeigen);
  	}
  	this.repaint();
  	zeigeNamen = zeigen;
  }
  
  public void undo(){
  	undoController.undo();
  }
  
  public void redo(){
  	undoController.redo();
  }
  
  public void add(Abschnitt a){
  	undoController.add(a);
  }

  public void addOhneUndo(Abschnitt a) {
  	if(a.getType().equals("strasse")){
  		KreuzungGUI ak = ((StrassenAbschnitt) a).getA();
  		KreuzungGUI bk = ((StrassenAbschnitt) a).getB();
  		StrassenAbschnitt as = (StrassenAbschnitt) a;
  		
  		
  		if(ak != null){
  	  		ak.addStrasse(as,as.getKonnektorA());
  		}
  		if(bk != null){
  			bk.addStrasse(as,as.getKonnektorB());
  		}
  	}
  	liste.add(a);
    a.zeigeNamen(zeigeNamen);
    this.repaint();
  }

  public int getNewId() {
    return idCounter++;
  }
  
  public void setNewId(int counter) {
    idCounter = counter;
  }
  
  public void removeElement(Abschnitt aktuellerAbschnitt){
  	
    if(aktuellerAbschnitt.getType().equals("kreuzung")){ //Falls es eine Kreuzung ist 
        Vector v = ((KreuzungGUI)aktuellerAbschnitt).getAngebundeneStrassen();
        Vector tmp = new Vector();	//Kopie des Vectors damit es nicht zu komplikationen kommt
        for(int i=0;i<v.size();i++){
        	tmp.add(v.get(i));
        }
    
        for(int i=0;i<tmp.size();i++){
        	//Die Strassen auch bei anderen Kreuzungen entfernen -- Wird durch rekusiven Aufruf erledigt
        	removeElement((Abschnitt) tmp.get(i));
        }
    }
    else if(aktuellerAbschnitt.getType().equals("strasse")){
      //Hier stehen Stra�enspezifische l�schaktionen
      StrassenAbschnitt tmpAbschnitt = (StrassenAbschnitt)aktuellerAbschnitt;

      tmpAbschnitt.getA().removeStrasse(tmpAbschnitt,tmpAbschnitt.getKonnektorA());
      tmpAbschnitt.getB().removeStrasse(tmpAbschnitt,tmpAbschnitt.getKonnektorB());
    }
  	
    undoController.remove(aktuellerAbschnitt);
  }

  public void removeElementOhneUndo(Abschnitt abs){
  	if(abs != null){
  		if(abs.getType().equals("strasse")){
  			StrassenAbschnitt as = (StrassenAbschnitt)abs;
  			((StrassenAbschnitt)abs).getA().removeStrasse(as,as.getKonnektorA());
  			((StrassenAbschnitt)abs).getB().removeStrasse(as,as.getKonnektorB());
  		}
  		
  		liste.remove(abs);
  	  	this.repaint();
  	}
  }
  
  public void removeAlleAbschnitte(int idCounter){
  	liste = new Vector();
  	undoController.restart();
  	setNewId(idCounter);
  }

  public StrassenAbschnitt findKante(KreuzungGUI a, KreuzungGUI b) {
    StrassenAbschnitt ergebnis;
    for (int i=0;i<liste.size();i++) {
      if (((Abschnitt)liste.get(i)).getType().equals("strasse")) {
        ergebnis = (StrassenAbschnitt)liste.get(i);
        if (((ergebnis.getA() == a) && (ergebnis.getB() == b))
            || ((ergebnis.getA() == b) && (ergebnis.getB() == a))){
          return ergebnis;
        }
      }
    }
    return null;
  }

  public Abschnitt findByPos(int x, int y) {
    Abschnitt ergebnis;
    for (int i=0;i<liste.size();i++){
      ergebnis = (Abschnitt)liste.get(i);
      if(ergebnis.istInPosition(x,y) == true){
        return ergebnis;
      }
    }
    return null;
  }
  
  public Konnektor findKonnektorByPos(int x, int y) {
    for (int i=0;i<liste.size();i++){
    	if(((Abschnitt)liste.get(i)).getType().equals("kreuzung")){
    		KreuzungGUI k = (KreuzungGUI) liste.get(i);
    		Konnektor konn = k.getKonnektor(x,y);
    		if(konn != null){
    			return konn;
    		}
    	}
    }
    return null;
  }
  
  public Abschnitt findByID(int id){
  	for (int i=0;i<liste.size();i++){
  		if(((Abschnitt) liste.get(i)).getId() == id){
  			return (Abschnitt) liste.get(i);
  		}
  	}
  	return null;
  }

  public void removeElement(int x, int y) {

    Abschnitt aktuellerAbschnitt = findByPos(x,y);

    if (aktuellerAbschnitt != null) {
      // l�schen
      removeElement(aktuellerAbschnitt);
      this.repaint();
    }
  }

  public void paintKante(StrassenAbschnitt k) {
  	tempStrasse = k;
    this.repaint();
  }

  public void paintMe(Graphics g) {

    //Strassen
    for (int i=0;i<liste.size();i++) {
      if (((Abschnitt)liste.get(i)).getType().equals("strasse")){
      	((Abschnitt)liste.get(i)).paintMe(g);
      }
    }

    //Kreuzungen
    for (int i=0;i<liste.size();i++) {
      if (((Abschnitt)liste.get(i)).getType().equals("kreuzung")){
      	((Abschnitt)liste.get(i)).paintMe(g);
      }
    }

    // Dragged Strasse
    if (tempStrasse != null) tempStrasse.paintMe(g);
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);

    if(hintergrund == null){
    	try{
        	g.drawImage(new ImageIcon(getClass().getResource("/gui/bilder/Fallstudie1.png"))
			.getImage(),0,0,getWidth(),getHeight(),this);
    	}
    	catch(Exception ex){
    		System.err.println("Hintergrundbild konnte nicht geladen werden!");
    	}
    }
    else{
    	g.drawImage(new ImageIcon(hintergrund)
    			.getImage(),0,0,getWidth(),getHeight(),this);
    }
    

    paintMe(g);

  }
  
  public void setHintergrund(String hintergrund){
  	this.hintergrund = hintergrund;
  }
  
  public String getHintergrund(){
	  	return hintergrund;
	  }

  private void jbInit() throws Exception {
    this.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        this_mousePressed(e);
      }
    });
  }

  void this_mousePressed(MouseEvent e) {
  }
  
  public Vector getAlleEinstellungen(){	//Einstellungen aller Abschnitte sammeln
  	Vector ergebnis = new Vector();
  	
  	for(int i=0;i<liste.size();i++){
  		ergebnis.add(((Abschnitt)liste.get(i)).getEinstellungen());
  	}
  	return ergebnis;
  }
  
  public void setSize(int arg0, int arg1){
  	super.setSize(arg0,arg1);
  	
  	if(liste != null && liste.size()>0){
  		double multiX = ((double) arg0) / ((double) oldWidth);
  		double multiY = ((double) arg1) / ((double) oldHeight);
  		
  		for(int i=0;i<liste.size();i++){
  			Abschnitt a = (Abschnitt) liste.get(i);  			
  			a.setPos((int) Math.round(multiX*a.getX()),(int) Math.round(multiY*a.getY()));
  		}
  		
  		this.repaint();
  	}
  	oldWidth = arg0;
  	oldHeight = arg1;
  	
  }
  
  public void setErgebnisModus(int modus){
  	for(int i=0;i<liste.size();i++){
  		((Abschnitt) liste.get(i)).setErgebnisModus(modus);
  	}
  	repaint();
  }
  
  


}
