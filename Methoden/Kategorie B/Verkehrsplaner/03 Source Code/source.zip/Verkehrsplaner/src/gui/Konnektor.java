/*
 * Created on 20.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;

import java.awt.Color;
import java.awt.Graphics;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Konnektor {

	private KreuzungGUI k;
	private int x,y;
	private int nummer;
	
	public Konnektor(KreuzungGUI k, int x, int y, int nummer){
		this.k = k;
		this.x = x;
		this.y = y;
		this.nummer = nummer;
	}
	
	public KreuzungGUI getKreuzung(){
		return k;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public void paintMe(Graphics g)  {
		g.setColor(Color.lightGray);
		g.fillRect(x-3,y-3,6,6);
		g.setColor(Color.darkGray);
		g.drawRect(x-3,y-3,6,6);
		g.setColor(Color.WHITE);
		g.drawRect(x-1,y-1,2,2);
	}
	
	public boolean istInPosition(int x1, int y1) {
	  	if(x1>x-7 && x1<x+7 && y1>y-7 && y1<y+7){
	  		return true;
	  	}
	  	return false;
	}
	
	public void setPos(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public int getNummer() {
		return nummer;
	}
}
