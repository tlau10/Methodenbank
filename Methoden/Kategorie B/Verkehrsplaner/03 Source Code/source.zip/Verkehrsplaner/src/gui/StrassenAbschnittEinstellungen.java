package gui;

import java.awt.*;
import javax.swing.*;

import verkehrsplaner.NormaleStrasseEinstellungen;

import java.awt.event.*;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class StrassenAbschnittEinstellungen extends JDialog {
	private static final long serialVersionUID = -6439539750415111363L;
	private JPanel panel1 = new JPanel();
	private JPanel jPanel1 = new JPanel();
	private JPanel jPanel2 = new JPanel();
	private JLabel labelRichtung1 = new JLabel();
	private JTextField tfFahrspuren1 = new JTextField();
	private JButton btOK = new JButton();
	private JButton btAbbrechen = new JButton();
	private JLabel jLabel2 = new JLabel();
	private JTextField tfName = new JTextField();
	private JLabel labelRichtung2 = new JLabel();
	private JTextField tfFahrspuren2 = new JTextField();
	private JLabel jLabel4 = new JLabel();
	private JTextField tfLaenge = new JTextField();
	private JLabel jLabel5 = new JLabel();
	private JTextField tfGeschwindigkeit = new JTextField();
	private JLabel jLabel6 = new JLabel();
	private JTextField tfFahrzeugeProMinute = new JTextField();
	private GridLayout gridLayout1 = new GridLayout(12,1);
	
	private NormaleStrasseEinstellungen daten;
	private GuiController controller;

  public StrassenAbschnittEinstellungen(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public StrassenAbschnittEinstellungen() {
    this(null, "", false);
  }

  public StrassenAbschnittEinstellungen(NormaleStrasseEinstellungen daten, GuiController controller) {
  	  this(null, "", false);
  	  this.daten = daten;
  	  this.controller = controller;
}
  
  public void initialisieren(StrassenAbschnitt s){
  	tfName.setText(daten.getName());
  	tfFahrspuren1.setText(Integer.toString(daten.getFahrspuren()[0]));
  	tfFahrspuren2.setText(Integer.toString(daten.getFahrspuren()[1]));
  	tfLaenge.setText(Double.toString(daten.getLaenge()));
  	tfGeschwindigkeit.setText(Double.toString(daten.getMaxV()));
  	tfFahrzeugeProMinute.setText(Double.toString(daten.getFahrzeugeProMinute()));
  	
  	labelRichtung1.setText("Anzahl Fahrspuren von "+s.getA().getName()+" nach "+s.getB().getName());
  	labelRichtung2.setText("Anzahl Fahrspuren von "+s.getB().getName()+" nach "+s.getA().getName());
  }


  private void jbInit() throws Exception {
    this.setSize(400,300);
    panel1.setLayout(null);
    labelRichtung1.setText("Anzahl Fahrspuren Richtung 1:");
    tfFahrspuren1.setMinimumSize(new Dimension(60, 21));
    tfFahrspuren1.setText("1");
    btOK.setSelectedIcon(null);
    btOK.setText("OK");
    btOK.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btOK_actionPerformed(e);
          }
        });
    btAbbrechen.setText("Abbrechen");
    btAbbrechen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btAbbrechen_actionPerformed(e);
          }
        });
    jPanel2.setBounds(new Rectangle(0, 315, 400, 37));
    jPanel1.setBounds(new Rectangle(11, 2, 380, 300));
    jPanel1.setLayout(gridLayout1);
    jLabel2.setText("Stra�enname:");
    labelRichtung2.setText("Anzahl Fahrspuren Richtung 2:");
    tfFahrspuren2.setText("1");
    jLabel4.setText("Stra�enl�nge in m:");
    tfLaenge.setText("100");
    jLabel5.setText("Maximale Geschwindigkeit in km/h:");
    tfGeschwindigkeit.setText("50");
    jLabel6.setText("Fahrzeuge pro Minute: ");
    tfFahrzeugeProMinute.setText("10");
    jPanel1.add(jLabel2, null);
    jPanel1.add(tfName, null);
    jPanel1.add(jLabel5, null);
    jPanel1.add(tfGeschwindigkeit, null);
    jPanel1.add(jLabel4, null);
    jPanel1.add(tfLaenge, null);
    jPanel1.add(labelRichtung1, null);
    jPanel1.add(tfFahrspuren1, null);
    jPanel1.add(labelRichtung2, null);
    jPanel1.add(tfFahrspuren2, null);
    jPanel1.add(jLabel6, null);
    jPanel1.add(tfFahrzeugeProMinute, null);
    jPanel2.add(btOK, null);
    jPanel2.add(btAbbrechen, null);
    panel1.add(jPanel2, null);
    getContentPane().add(panel1);
    panel1.add(jPanel1, null);
  }

  void btAbbrechen_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  
  }

  void btOK_actionPerformed(ActionEvent e) {
  	
  	daten.setName(tfName.getText());
  	int[] tmp = new int[2];
  	tmp[0] = Integer.parseInt(tfFahrspuren1.getText());
  	tmp[1] = Integer.parseInt(tfFahrspuren2.getText());
  	daten.setFahrspuren(tmp);
  	daten.setLaenge(Double.parseDouble(tfLaenge.getText()));
  	daten.setMaxV(Double.parseDouble(tfGeschwindigkeit.getText()));
  	daten.setFahrzeugeProMinute(Double.parseDouble(tfFahrzeugeProMinute.getText()));
  	controller.repaint();
    this.setVisible(false);
  }
}
