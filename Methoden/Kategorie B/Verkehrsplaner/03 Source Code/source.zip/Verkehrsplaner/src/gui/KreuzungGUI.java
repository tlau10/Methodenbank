package gui;

import java.awt.*;
import java.util.*;

import verkehrsplaner.Status;


/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public abstract class KreuzungGUI implements Abschnitt{


   protected int x,y,id;
   protected int anzahlStrassen = 0;
   protected int maxStrassen=4;
   protected StrassenAbschnitt[] angebundeneStrassen;
   protected boolean isBlockiert=false;
   protected boolean zeigeNamen=false;
   protected Konnektor[] konn;

   public abstract void zeigeEinstellungen();
   public abstract String getName();
   public abstract Konnektor getKonnektor(int x, int y);

   public KreuzungGUI(){
   }
   
   
 public void setBlockiert(boolean m) {
   isBlockiert = m;
 }

 public void setPos(int x1, int y1) {
   x=x1;
   y=y1;
 }

 public String getType() {
   return "kreuzung";
 }

 public int getX() {
   return x;
 }

 public int getY() {
   return y;
 }

 public int getId() {
   return id;
 }


 public void paintMe(Graphics g)  {

   if (isBlockiert==true) {
     g.setColor(Color.red);
   }
   else {
     g.setColor(Color.blue);
   }

   g.fillOval(x-20,y-20,40,40);
   g.setColor(Color.black);
   g.drawString("Kreisel",x-8,y+3);
 }

   public boolean addStrasse(StrassenAbschnitt a, int richtung) {
   	//TODO
   	//System.err.println("ID"+id+"ADD: "+a.getId()+" Richtung:"+richtung);
   	if(richtung > -1 && richtung < maxStrassen && angebundeneStrassen[richtung] == null){
   		//System.err.println("ADD: "+a.getId()+" Richtung:"+richtung);
   		anzahlStrassen++;
   		angebundeneStrassen[richtung] = a;
   		return true;
   	}
     return false;
   }
   
   public void addAbschnitt(Abschnitt a, int richtung){
   	addStrasse((StrassenAbschnitt)a, richtung);
   }
   
   public int getMaxAnbindungen(){
   	return maxStrassen;
   }

   public boolean removeStrasse(StrassenAbschnitt a, int richtung) {
     if(richtung > -1 && richtung < maxStrassen && angebundeneStrassen[richtung] != null){
        anzahlStrassen--;
        //TODO
        angebundeneStrassen[richtung] = null;
        return true;
     }
     return false;
   }
   
//   public boolean richtungFrei(int richtung){
//   	if(richtung > -1 && richtung < maxStrassen && angebundeneStrassen[richtung] == null){
//   		return true;
//   	}
//   	return false;
//   }

   public Vector getAngebundeneStrassen() {
   	Vector ergebnis = new Vector();
   	for(int i=0;i<maxStrassen;i++){
   		if(angebundeneStrassen[i] != null){
   			ergebnis.add(angebundeneStrassen[i]);
   		}
   	}
     return ergebnis;
   }

   public boolean weiterAnbindungenMoeglich(int richtung){
   	if(richtung > -1 && richtung<maxStrassen){
   		if(angebundeneStrassen[richtung]==null)
   			return true;
   		else
   			return false;
   	}
   	return false;
   	
//     if(anzahlStrassen < maxStrassen){
//       return true;
//     }
//     return false;
   }
   
   protected StrassenAbschnitt getStrasseById(int id){
   	for(int i=0;i<maxStrassen;i++){
   		if(angebundeneStrassen[i] != null && angebundeneStrassen[i].getId() == id){
   			return angebundeneStrassen[i];
   		}
   	}
   	return null;
   }
   
   protected String getStrassenNameById(int id){
   	StrassenAbschnitt s = getStrasseById(id);
   	if(s != null){
   		return s.getName();
   	}
   	return "";
   }
   
   //Automatik f�r die AbbiegeWahr'keiten
   public double[][] getAutoAbbiegen(){
   	double[][] ergebnis = new double[4][3];
   	
   	int[] anbindung = sortiereAnbindungen();
   	//TODO
   	
   	for(int i=0;i<4;i++){
   		double[] r = new double[3];
   		double gesamt = 0.0;
   		for(int j=0;j<3;j++){
   			r[j] = getFahrzeugZahlVonStrasse(anbindung,i,j);
   			gesamt += r[j];
   		}
   		
   		for(int j=0;j<3;j++){
   			if(gesamt <= 0.0){
   				ergebnis[i][j] = 0.3333;
   			}
   			else{
   				ergebnis[i][j] = Math.round(r[j]*10000.0 / gesamt)/10000.0;
   			}
   		}
   	}
   	return ergebnis;
   }
   
   private double getFahrzeugZahlVonStrasse(int[] anbindung, int nummer, int abbiegeRichtung){
   	nummer -= (abbiegeRichtung+1);
   	if(nummer < 0)
   		nummer += 4;
   	
   	//Falls es eine Strasse gibt, und eine Fahrspur von dieser weg f�hrt
   	if(getStrasseById(anbindung[nummer]) != null 
   			&& getStrasseById(anbindung[nummer]).getAnzahlSpurenVonKreuzungWeg(this) > 0){
   		return getStrasseById(anbindung[nummer]).getFahrzeugeProMinute(this);
   	}

   	return 0.0;
   }
   
   protected int[] sortiereAnbindungen(){
  	
  	int[] anbindung = new int[maxStrassen];
  	for(int i=0;i<maxStrassen;i++){
  		if(angebundeneStrassen[i] != null){
  			anbindung[i] = angebundeneStrassen[i].getId();
  		}
  		else{
  			anbindung[i] = -1;
  		}
  	}
  	
  return anbindung;
  }
//   	int[] ergebnis = new int[maxStrassen];
//   	Vector l = angebundeneStrassen;
//   	angebundeneStrassen = new Vector();
//   	
//   	//sortieren der Liste
//   	for(int i=0;i<l.size();i++){
//   		angebundeneStrassen.add(suchePositioninListe((StrassenAbschnitt)l.get(i)),l.get(i));
//   	}
//   	
//   	//Umkopieren in ein Array
//   	for(int i=0;i<maxStrassen;i++){
//   		if(i < angebundeneStrassen.size()){
//   			ergebnis[i] = ((StrassenAbschnitt) angebundeneStrassen.get(i)).getId();
//   		}
//   		else{
//   			ergebnis[i] = -1;
//   		}
//   	}
//   	
//   	//TODO Hier muss bestimmt werden, in welcher Himmelsrichtung die Strasse fehlt
//   	
//   	if(angebundeneStrassen.size() == 3 && maxStrassen == 4){
//   		
//   		//Winkel zum jeweiligen nachfolger bestimmen
//   		double winkel[] = new double[3];
//   		for(int i=0;i<3;i++){
//   			if(i<2){
//   				winkel[i] = berechneWinkel((StrassenAbschnitt)angebundeneStrassen.get(i+1)) 
//							- berechneWinkel((StrassenAbschnitt)angebundeneStrassen.get(i));;
//   			}
//   			else{
//   				winkel[i] = (360.0 - berechneWinkel((StrassenAbschnitt)angebundeneStrassen.get(i)))
//							+ berechneWinkel((StrassenAbschnitt)angebundeneStrassen.get(0));
//   			}
//   		}
//   		
//   		//Gr��ten zwischenraum zwischen den Strassen ermitteln
//   		int groessterZwischenraum=0;
//   		for(int i=1;i<3;i++){
//   			if(winkel[i] > winkel[groessterZwischenraum]){
//   				groessterZwischenraum=i;
//   			}
//   		}
//   		
////   	ergebnis[] anpassen
//   		for(int i=2;i>=0;i--){
//   			if(i>groessterZwischenraum){
//   				ergebnis[i+1] = ergebnis[i];
//   			}
//   			else if(i==groessterZwischenraum){
//   				ergebnis[i+1] = -1;
//   			}
//   		}
//   		
//   	}
//   	// */
//   	
//   	return ergebnis;
//   }
   
//   //gibt die Position(Himmelsrichtung) des Strassenabschnitts in der Liste zur�ck
//	private int suchePositioninListe(StrassenAbschnitt s){
//		int i=0;
//		for(i=0;i<angebundeneStrassen.size();i++){
//			if(berechneWinkel((StrassenAbschnitt)angebundeneStrassen.get(i)) >= berechneWinkel(s)){
//				return i;
//			}
//		}
//		return i;
//	}

   
//   private double berechneWinkel(StrassenAbschnitt s){
//   	//Berechnen des Winkels von dieser Kreuzung zur n�chsten Kreuzung
//   	//Dies wird f�r das Sortieren zwecks Himmelsrichtungsbestimmung ben�tigt
//   	
//   	double ergebnis=0.0;
//   	double dX, dY;
//   	
//   	dX = (double) (s.getWinkelX(this) - this.x);
//   	dY = (double) (s.getWinkelY(this) - this.y);
//   	
//   	if(dX>=0.0 && dY<0.0){
//   		ergebnis = Math.toDegrees(Math.atan(dX/-dY));
//   	}
//   	else if(dX>=0.0 && dY>=0.0){
//   		ergebnis = Math.toDegrees(Math.atan(dY/dX));
//   		ergebnis += 90;
//   	}
//   	else if(dX<0.0 && dY>=0.0){
//   		ergebnis = Math.toDegrees(Math.atan(-dX/dY));
//   		ergebnis += 180;
//   	}
//   	else if(dX<0.0 && dY<0.0){
//   		ergebnis = Math.toDegrees(Math.atan(dY/dX));
//   		ergebnis += 270;
//   	}
//   	else{
//   		System.err.println("Fehler bei Winkelberechnung bei Kreuzung "+id+" Stra�e "+s.getId());
//   	}
//   	
//   	//System.out.println("Strasse " + s.id + " Winkel: "+ergebnis);
//   	return ergebnis;
//   }
   
   public void zeigeNamen(boolean b){
   	zeigeNamen = b;
   }

   
   public void setStatus(Status s){
   		//TODO Animation
   	for(int i=0;i<s.getAnzahlWS();i++){
   		StrassenAbschnitt abs = getStrasseById(s.getWsId()[i]);
   		
   		if(abs != null){
   			abs.setWSBeschriftung(this,s.getWsLaenge()[i]);
   		}
   	}
   }
   
	public Konnektor verbindeKonnektor(int nummer, StrassenAbschnitt s){
		//TODO Strassenabschnitt einbauen
		
		if(nummer > -1 && nummer < maxStrassen){
			return konn[nummer];
		}
			
		System.err.println("Unbekannter Konnektor: "+nummer);
		return null;
	}
	
   
//   public int getPosStrasseX(int kID){
//   	int[] array = {x,x+10,x,x-10};
//   	for(int i=0;i<maxStrassen;i++){
//   		if(sortierteStrassenID[i] == kID){
//   			return array[i];
//   		}
//   	}
//   	return 0;
//   }
//   
//   public int getPosStrasseY(int kID){
//   	int[] array = {y-10,y,y+10,y};
//   	for(int i=0;i<maxStrassen;i++){
//   		if(sortierteStrassenID[i] == kID){
//   			return array[i];
//   		}
//   	}
//   	return 0;
//   }

}
