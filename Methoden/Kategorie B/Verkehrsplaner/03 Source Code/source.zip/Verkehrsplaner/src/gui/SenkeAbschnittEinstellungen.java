package gui;

import java.awt.*;
import javax.swing.*;

import verkehrsplaner.SenkeEinstellungen;

import java.awt.event.*;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class SenkeAbschnittEinstellungen extends JDialog {
	private static final long serialVersionUID = -3498764387380477834L;
	private JPanel panel1 = new JPanel();
	private JPanel jPanel1 = new JPanel();
	private FlowLayout flowLayout1 = new FlowLayout();
	private JButton btOK = new JButton();
	private JButton btAbbrechen = new JButton();
	private JPanel jPanel2 = new JPanel();
	private GridLayout gridLayout1 = new GridLayout(4,1);
	private JLabel jLabel1 = new JLabel();
	private JTextField tfName = new JTextField();
	private JLabel jLabel2 = new JLabel();
	private JTextField tfGeschwindigkeit = new JTextField();

	private SenkeEinstellungen daten;
	private GuiController controller;
  
  public SenkeAbschnittEinstellungen(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public SenkeAbschnittEinstellungen() {
    this(null, "", false);
  }

  public SenkeAbschnittEinstellungen(SenkeEinstellungen daten, GuiController controller) {
  this(null, "", false);
  this.daten = daten;
  this.controller = controller;
}
  
  public void initialisieren(KreuzungGUI kreuzung){
  	tfName.setText(daten.getName());
  	tfGeschwindigkeit.setText(Double.toString(daten.getMaxGeschwindigkeit()));
  }


  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jPanel1.setBounds(new Rectangle(1, 242, 398, 38));
    jPanel1.setLayout(flowLayout1);
    btOK.setText("OK");
    btOK.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btOK_actionPerformed(e);
          }
        });
    btAbbrechen.setText("Abbrechen");
    btAbbrechen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btAbbrechen_actionPerformed(e);
          }
        });
    jPanel2.setBounds(new Rectangle(4, 74, 390, 100));
    jPanel2.setLayout(gridLayout1);
    jLabel1.setText("Senken Name:");
    tfName.setText("");
    jLabel2.setText("Maximale Geschwindigkeit:");
    tfGeschwindigkeit.setText("");
    jPanel2.add(jLabel1, null);
    jPanel2.add(tfName, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(tfGeschwindigkeit, null);
    getContentPane().add(panel1);
    panel1.add(jPanel1, null);
    jPanel1.add(btOK, null);
    jPanel1.add(btAbbrechen, null);
    panel1.add(jPanel2, null);


  }

  void btOK_actionPerformed(ActionEvent e) {
  	daten.setName(tfName.getText());
  	daten.setMaxGeschwindigkeit(Double.parseDouble(tfGeschwindigkeit.getText()));
  	controller.repaint();
    this.setVisible(false);
  }

  void btAbbrechen_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }
}

