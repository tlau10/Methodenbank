/*
 * Created on 01.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;

import java.beans.XMLDecoder;
import java.util.LinkedList;
import java.util.Vector;

import javax.swing.JOptionPane;

import rechtsVorLinks.RechtsVorLinksEinstellungen;

import kreisverkehrTyp2.KreisverkehrTyp2Einstellungen;
import verkehrsplaner.AllgemeineEinstellungen;
import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.NormaleStrasseEinstellungen;
import verkehrsplaner.QuelleEinstellungen;
import verkehrsplaner.SenkeEinstellungen;
import vorfahrt.VorfahrtEinstellungen;
import ampelGross.AmpelGrossEinstellungen;
import ampelKlein.AmpelKleinEinstellungen;
import ampelMittel.AmpelMittelEinstellungen;
import ampelTyp2.AmpelTyp2Einstellungen;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FactoryGUI {

	private Vector liste;
	private GuiController controller;
	private Dateizugriff datei;

	public FactoryGUI(){
		liste = new Vector();
		datei = new Dateizugriff();
	}
	
	private void erstelleGuiObjekte(LinkedList einstellungen, AllgemeineEinstellungen allgemein){
		
		controller.removeAlleAbschnitte(allgemein.getIdCounter());
		
		//Alle Abschnitte erstellen
		for(int i=0;i<einstellungen.size();i++){
			
			EinstellungsDaten daten = (EinstellungsDaten) einstellungen.get(i);
			Abschnitt a=null;
			
			if(daten.getType().equals("AmpelTyp2Einstellungen")){
				a = new AmpelAbschnitt((AmpelTyp2Einstellungen)daten,controller);
			}
			else if(daten.getType().equals("AmpelKleinEinstellungen")){
				a = new AmpelAbschnitt((AmpelKleinEinstellungen)daten,controller);
			}
			else if(daten.getType().equals("AmpelMittelEinstellungen")){
				a = new AmpelAbschnitt((AmpelMittelEinstellungen)daten,controller);
			}
			else if(daten.getType().equals("AmpelGrossEinstellungen")){
				a = new AmpelAbschnitt((AmpelGrossEinstellungen)daten,controller);
			}
			else if(daten.getType().equals("NormaleStrasseEinstellungen")){
				a = new StrassenAbschnitt((NormaleStrasseEinstellungen)daten,controller);
			}
			else if(daten.getType().equals("QuelleEinstellungen")){
				a = new QuelleAbschnitt((QuelleEinstellungen)daten,controller);
			}
			else if(daten.getType().equals("SenkeEinstellungen")){
				a = new SenkeAbschnitt((SenkeEinstellungen)daten,controller);
			}
			else if(daten.getType().equals("KreisverkehrTyp2Einstellungen")){
				a = new KreisverkehrAbschnitt((KreisverkehrTyp2Einstellungen)daten,controller);
			}
			else if(daten.getType().equals("RechtsVorLinksEinstellungen")){
				a = new RechtsVorLinksAbschnitt((RechtsVorLinksEinstellungen)daten,controller);
			}
			else if(daten.getType().equals("VorfahrtEinstellungen")){
				a = new VorfahrtAbschnitt((VorfahrtEinstellungen)daten,controller);
			}
			else{
				System.err.println("Unbekannter Datentyp: "+daten.getType());
				return;
			}
			
			liste.add(a);
			controller.addOhneUndo(a);
		}
		
		
		for(int i=0;i<liste.size();i++){
			Abschnitt b = (Abschnitt) liste.get(i);
			
			EinstellungsDaten daten = (EinstellungsDaten) einstellungen.get(i);
			
			//Alles miteinander verbinden
			for(int j=0;j<b.getMaxAnbindungen();j++){
				if(daten.getAnbindungen()[j]>-1){ //Falls nicht die max Anzahl anbindungen benutzt wurden
					//System.err.println("ID: "+b.getId()+" i:"+i+" j:"+j+" MAX:"+b.getMaxAnbindungen()+" Anbindung:"+sucheAbschnittNachId(daten.getAnbindungen()[j]).getId());
					b.addAbschnitt(sucheAbschnittNachId(daten.getAnbindungen()[j]),j);
				}
					
			}
		}
	}
	
	private Abschnitt sucheAbschnittNachId(int id){
		for(int i=0;i<liste.size();i++){
			if(((Abschnitt)liste.get(i)).getId() == id){
				return ((Abschnitt)liste.get(i));
			}
		}
		
		return null;
	}
	
	public static LinkedList datenEinlesen(XMLDecoder d){
		LinkedList ergebnis = new LinkedList();
    	try{
    		AllgemeineEinstellungen a = (AllgemeineEinstellungen) d.readObject();
    		
    		ergebnis.add(a);
    		
    	  //Reihenfolge aus AllgemeineEinstellungen:
//    		private int anzahlAmpelTyp2=0;
//    		private int anzahlKreisverkehrTyp2=0;
//    		private int anzahlQuellen=0;
//    		private int anzahlSenken=0;
//    		private int anzahlStrassen=0;
//    		private int idCounter=1;
    		
    		for(int i=0;i<a.getAnzahlAmpelTyp2();i++){
    			ergebnis.add((AmpelTyp2Einstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlAmpelKlein();i++){
    			ergebnis.add((AmpelKleinEinstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlAmpelMittel();i++){
    			ergebnis.add((AmpelMittelEinstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlAmpelGross();i++){
    			ergebnis.add((AmpelGrossEinstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlKreisverkehrTyp2();i++){
    			ergebnis.add((KreisverkehrTyp2Einstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlRechtsVorLinks();i++){
    			ergebnis.add((RechtsVorLinksEinstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlVorfahrt();i++){
    			ergebnis.add((VorfahrtEinstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlQuellen();i++){
    			ergebnis.add((QuelleEinstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlSenken();i++){
    			ergebnis.add((SenkeEinstellungen) d.readObject());
    		}
    		for(int i=0;i<a.getAnzahlStrassen();i++){
    			ergebnis.add((NormaleStrasseEinstellungen) d.readObject());
    		}

    		
        }
        catch(Exception f){
          System.out.println("Datei ist nicht vorhanden");
          JOptionPane.showMessageDialog(null,("Ein Fehler ist beim einlesen der Datei aufgetreten"),
                                        "Fehler",JOptionPane.ERROR_MESSAGE);
        }
		
        return ergebnis;
	}
	

	public AllgemeineEinstellungen ladeDaten(GuiController controller){
		this.controller = controller;
		AllgemeineEinstellungen a = new AllgemeineEinstellungen();
		LinkedList alleEinstellungen = datei.LadeEinstellungen();
		
		if(alleEinstellungen != null){
			try{
				a = (AllgemeineEinstellungen) alleEinstellungen.get(0);
				controller.setSize(a.getOldWidth(),a.getOldHeight());
				LinkedList einstellungen = new LinkedList();
				
				for(int i=1;i<alleEinstellungen.size();i++){
					einstellungen.addLast(alleEinstellungen.get(i));
				}
				
				erstelleGuiObjekte(einstellungen, a);
			}
			catch(Exception e){
				System.err.println("Fehler beim Lesen");
				e.printStackTrace();
			}
		}
		return a;
	}
	
	public void speichereDaten(Vector einstellungen, AllgemeineEinstellungen allgemein){
		
		Vector ampelTyp2 = new Vector();
		Vector ampelKlein = new Vector();
		Vector ampelMittel = new Vector();
		Vector ampelGross = new Vector();
		Vector kreisverkehrTyp2 = new Vector();
		Vector rechtsVorLinks = new Vector();
		Vector vorfahrt = new Vector();
		Vector quelle = new Vector();
		Vector senke = new Vector();
		Vector normaleStrasse = new Vector();
		
		//Reihenfolge aus AllgemeineEinstellungen:
//		private int anzahlAmpelTyp2=0;
//		private int anzahlKreisverkehrTyp2=0;
//		private int anzahlQuellen=0;
//		private int anzahlSenken=0;
//		private int anzahlStrassen=0;
//		private int idCounter=1;
		
		
		//Sortieren und Z�hlen der verschiedenen Einstellungen
		for(int i=0;i<einstellungen.size();i++){
			
			EinstellungsDaten daten = (EinstellungsDaten) einstellungen.get(i);
			
			if(daten.getType().equals("AmpelTyp2Einstellungen")){
				ampelTyp2.add(daten);
			}
			else if(daten.getType().equals("AmpelKleinEinstellungen")){
				ampelKlein.add(daten);
			}
			else if(daten.getType().equals("AmpelMittelEinstellungen")){
				ampelMittel.add(daten);
			}
			else if(daten.getType().equals("AmpelGrossEinstellungen")){
				ampelGross.add(daten);
			}
			
			else if(daten.getType().equals("KreisverkehrTyp2Einstellungen")){
				kreisverkehrTyp2.add(daten);
			}
			else if(daten.getType().equals("RechtsVorLinksEinstellungen")){
				rechtsVorLinks.add(daten);
			}
			else if(daten.getType().equals("VorfahrtEinstellungen")){
				vorfahrt.add(daten);
			}

			else if(daten.getType().equals("QuelleEinstellungen")){
				quelle.add(daten);
			}
			else if(daten.getType().equals("SenkeEinstellungen")){
				senke.add(daten);
			}
			else if(daten.getType().equals("NormaleStrasseEinstellungen")){
				normaleStrasse.add(daten);
			}
			else{
				System.err.println("Unbekannter Datentyp: "+daten.getType());
				return;
			}
		}
		
		allgemein.setAnzahlAmpelTyp2(ampelTyp2.size());
		allgemein.setAnzahlAmpelKlein(ampelKlein.size());
		allgemein.setAnzahlAmpelMittel(ampelMittel.size());
		allgemein.setAnzahlAmpelGross(ampelGross.size());
		
		allgemein.setAnzahlKreisverkehrTyp2(kreisverkehrTyp2.size());
		allgemein.setAnzahlRechtsVorLinks(rechtsVorLinks.size());
		allgemein.setAnzahlVorfahrt(vorfahrt.size());
		allgemein.setAnzahlQuellen(quelle.size());
		allgemein.setAnzahlSenken(senke.size());
		allgemein.setAnzahlStrassen(normaleStrasse.size());
		
		
		LinkedList sortierteEinstellungen = new LinkedList();
		sortierteEinstellungen.addFirst(allgemein);
		
		for(int i=0;i<ampelTyp2.size();i++){
			sortierteEinstellungen.addLast(ampelTyp2.get(i));
		}
		for(int i=0;i<ampelKlein.size();i++){
			sortierteEinstellungen.addLast(ampelKlein.get(i));
		}
		for(int i=0;i<ampelMittel.size();i++){
			sortierteEinstellungen.addLast(ampelMittel.get(i));
		}
		for(int i=0;i<ampelGross.size();i++){
			sortierteEinstellungen.addLast(ampelGross.get(i));
		}
		for(int i=0;i<kreisverkehrTyp2.size();i++){
			sortierteEinstellungen.addLast(kreisverkehrTyp2.get(i));
		}
		for(int i=0;i<rechtsVorLinks.size();i++){
			sortierteEinstellungen.addLast(rechtsVorLinks.get(i));
		}
		for(int i=0;i<vorfahrt.size();i++){
			sortierteEinstellungen.addLast(vorfahrt.get(i));
		}
		for(int i=0;i<quelle.size();i++){
			sortierteEinstellungen.addLast(quelle.get(i));
		}
		for(int i=0;i<senke.size();i++){
			sortierteEinstellungen.addLast(senke.get(i));
		}
		for(int i=0;i<normaleStrasse.size();i++){
			sortierteEinstellungen.addLast(normaleStrasse.get(i));
		}
		
		//Speichern aufrufen
		datei.SpeichereEinstellungen(sortierteEinstellungen);
		
	}
	
}
