package gui;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.util.LinkedList;

import javax.swing.*;

public class Dateizugriff {
	 private JFileChooser JFileChosser1 = new JFileChooser();
	  
	  
	  public LinkedList LadeEinstellungen(){
	  	LinkedList ergebnis= null;
	  	
		  //Nur XML anzeigen
	  	JFileChosser1.addChoosableFileFilter(new javax.swing.filechooser.FileFilter() {
	  		public boolean accept(File f) {
		        if (f.isDirectory()) return true;
		        return f.getName().toLowerCase().endsWith(".xml");
		    }
		    public String getDescription () { return "XML"; }  
		     });
		  
	  	int status = JFileChosser1.showOpenDialog(null);
		if(status == JFileChooser.APPROVE_OPTION)
		{
			File datei = JFileChosser1.getSelectedFile();
		      
		    //System.out.println(datei.length()); um Dateil�nge zu ermitteln
		    if (datei != null)
		    {
		    	try // try-catch Prozedur um eventl Fehler abzufangen
				{
		        	
		    		XMLDecoder d = new XMLDecoder(new BufferedInputStream(new FileInputStream(datei)));
		    		
		    		ergebnis = FactoryGUI.datenEinlesen(d);

		        	d.close();
	      
		        }
		        catch(FileNotFoundException f) // F�ngt Fehler beim �ffnen ab
		        {
		          System.out.println("Datei ist nicht vorhanden");
		          JOptionPane.showMessageDialog(null,("Datei: "+datei.getAbsolutePath()+" ist nicht vorhanden"),
		                                        "Fehler",JOptionPane.ERROR_MESSAGE);
		        }
		     }
		 }
		    return ergebnis; 
	  }
		  

	  //Achtung: der Vector einstellungen muss spezielle Spezifikationen erf�llen
	  //         damit die Daten sp�ter wieder gelesen werden k�nnen
	  public void SpeichereEinstellungen(LinkedList einstellungen){
		    boolean speichern=true;
		    
		    //Nur XML sehen/speichern
		    JFileChosser1.addChoosableFileFilter(new javax.swing.filechooser.FileFilter() {
		        public boolean accept(File f) {
		          if (f.isDirectory()) return true;
		          return f.getName().toLowerCase().endsWith(".xml");
		        }
		        public String getDescription () { return "XML"; }  
		      });
		    
		    
		    int status = JFileChosser1.showSaveDialog(null);
		    if(status == JFileChooser.APPROVE_OPTION)
		    {
		      File datei = JFileChosser1.getSelectedFile(); //Dateiname �bertrageb
		      
		      //Routine zur �berpr�fung der Dateiendung
		      String pathname = datei.getPath();   
		      if(!pathname.endsWith(".xml")){
		    	  pathname += ".xml";
		    	  datei = new File(pathname);
		      }

		      
		      if(datei.exists()==true)
		      {
		        int entscheidung = JOptionPane.showConfirmDialog(null,
		            "Datei existiert bereits!\nDatei �berschreiben?","Abfrage",
		            JOptionPane.YES_NO_OPTION,JOptionPane.INFORMATION_MESSAGE);
		        if(entscheidung == JOptionPane.NO_OPTION)
		        {
		          speichern = false;
		        }
		      }
		      if(datei == null)
		      {
		        speichern = false;
		      }

		      if(speichern == true)
		      {
		        try
		        {
					XMLEncoder e = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(datei)));
					
					for(int i=0;i<einstellungen.size();i++){
						e.writeObject(einstellungen.get(i));
					}
					e.close();
		        }
		        catch(FileNotFoundException f) // F�ngt Fehler beim Datei erstellen ab
		        {
		          System.out.println("Fehler beim Anlegen der Datei: "+datei);
		          JOptionPane.showMessageDialog(null,"Fehler beim Anlegen der Datei",
		                                        "Fehler",JOptionPane.ERROR_MESSAGE);
		        }
		      }
		    }
	  }
	  
	  
	  public String LadeHintergrund(){
	  	int status = JFileChosser1.showOpenDialog(null);
		if(status == JFileChooser.APPROVE_OPTION)
		{
			File datei = JFileChosser1.getSelectedFile();
		    if (datei != null)
		    {
		    	return datei.getAbsolutePath();
		    }
		}
		    return null; 
	  }
	  

	  
	  
	  
	  
	  private final JFileChooser dateiname = new JFileChooser();
	  
	  public void export(String Text) // Die Export Methode
	  {
		  //Filter f�r CSV Dateiendung hinzuf�gen
	    dateiname.addChoosableFileFilter(new javax.swing.filechooser.FileFilter() {
	        public boolean accept(File f) {
	          if (f.isDirectory()) return true;
	          return f.getName().toLowerCase().endsWith(".csv");
	        }
	        public String getDescription () { return "CSV"; }  
	      });
	  
		  
	    boolean speichern=true;
	    int status = dateiname.showSaveDialog(null);
	    if(status == JFileChooser.APPROVE_OPTION)	//Statischer Zugriff
	    {
	      File datei = dateiname.getSelectedFile(); //Dateiname �bertrageb
	      
	      //Routine zur �berpr�fung der Dateiendung
	      String pathname = datei.getPath();
	      if(!pathname.endsWith(".csv")){
	    	  pathname += ".csv";
	    	  datei = new File(pathname);
	      }

	      if(datei.exists()==true)
	      {
	        int entscheidung = JOptionPane.showConfirmDialog(null,
	            "Datei existiert bereits!\nDatei �berschreiben?","Abfrage",
	            JOptionPane.YES_NO_OPTION,JOptionPane.INFORMATION_MESSAGE);
	        if(entscheidung == JOptionPane.NO_OPTION)
	        {
	          speichern = false;
	        }
	      }
	      if(datei == null)
	      {
	        speichern = false;
	      }

	      if(speichern == true)
	      {
	        try
	        {
	          FileWriter ausgabestrom = new FileWriter(datei);
	          ausgabestrom.write(Text); //Auswahl des zu speichernden String
	          ausgabestrom.close();
	        }
	        catch(FileNotFoundException f) // F�ngt Fehler beim Datei erstellen ab
	        {
	          System.out.println("Fehler beim Anlegen der Datei: "+datei);
	          JOptionPane.showMessageDialog(null,"Fehler beim Anlegen der Datei",
	                                        "Fehler",JOptionPane.ERROR_MESSAGE);
	        }
	        catch(IOException f) // F�ngt Fehler beim Schreiben ab
	        {
	          System.out.println("Fehler beim Schreiben der Datei: " +datei);
	          JOptionPane.showMessageDialog(null,"Fehler beim Schreiben der Datei",
	                                        "Fehler",JOptionPane.ERROR_MESSAGE);
	        }
	      }
	    }
	  }	
}

