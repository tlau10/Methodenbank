package gui;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;

import verkehrsplaner.AllgemeineEinstellungen;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Factory;
import verkehrsplaner.Status;
import verkehrsplaner.WarteschlangeErgebnis;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class GUI extends JFrame implements Runnable{

  private static final long serialVersionUID = 5952688352252330021L;
  private String modus = "";
  private StrassenAbschnitt tempStrasse;
  private Abschnitt tempAbschnitt;
  private Konnektor tempKonnektor;
  private int eX,eY;
  private boolean zeigeNamen=false;
  private boolean animationStop=false;
  private AllgemeineEinstellungen aE = new AllgemeineEinstellungen();
  private EinstellungenGUI einstellungen;
  private int lastErgebnis=0;
  private Vector ergebnis;
  private String ampelTyp="K";

  private JPanel contentPane;
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu jMenuFile = new JMenu();
  private JMenuItem jMenuFileExit = new JMenuItem();
  private JMenu jMenuHelp = new JMenu();
  private JMenuItem jMenuHelpAbout = new JMenuItem();
  private JMenuItem jMenuFileLoad = new JMenuItem();
  private JMenuItem jMenuFileSave = new JMenuItem();
  private JMenuItem jMenuFileEinstellungen = new JMenuItem();
  private JMenuItem jMenuFileLoadHintergrund = new JMenuItem();
  private JSlider mySlider = new JSlider(1,10);	//Slider zur Geschwindigkeitsregulierung
  private JButton btBewegen = new JButton();
  private JButton btBewegenSimu = new JButton();
  private JButton btBewegenErgebnis = new JButton();
  private JButton btRechtsVorLinks = new JButton();
  private JButton btVorfahrt = new JButton();
  private JButton btAmpel = new JButton();
  private JButton btKreisverkehr = new JButton();
  private JButton btStrasse = new JButton();
  private JButton btEinstellungen = new JButton();
  private JButton btAnimationsdetails = new JButton();
  private JButton btAnimationStoppen = new JButton();
  private JButton btZeigeNamen = new JButton();
  private JButton btZeigeNamenSimu = new JButton();
  private JButton btLoeschen = new JButton();
  private JButton btUndo = new JButton();
  private JButton btRedo = new JButton();
  private GuiController jpController = new GuiController();
  private JPanel jPanel2 = new JPanel();
  private JButton btStart = new JButton();
  private FlowLayout flowLayout1 = new FlowLayout();
  private JPanel jPanel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel3 = new JPanel();
  private FlowLayout flowLayout2 = new FlowLayout();
  private JButton btQuelle = new JButton();
  private JButton btSenke = new JButton();
  private JTextField tfDauer = new JTextField();
  private JPopupMenu myPopup = new JPopupMenu();
  private JToolBar toolbar = new JToolBar();
  private JToolBar toolbarNeu = new JToolBar();
  private JToolBar toolbarSimu = new JToolBar();
  private JToolBar toolbarErgebnis = new JToolBar();
  private JButton btErgebnisDetails = new JButton();
  private JButton btErgebnisBeenden = new JButton();
  private JButton btErgebnisExport = new JButton();
  private JProgressBar pbFortschritt = new JProgressBar();
  private JComboBox cbStrasse = new JComboBox();
  private JComboBox cbErgebnis = new JComboBox();
  private JComboBox cbAmpel = new JComboBox();
  private JLabel labelGeschw = new JLabel();

  //Den Frame konstruieren
  public GUI() {
  	aE = new AllgemeineEinstellungen();
  	einstellungen = new EinstellungenGUI();
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Initialisierung der Komponenten
  private void jbInit() throws Exception  {
    btQuelle.setText("Quelle");
    btQuelle.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btQuelle_actionPerformed(e);
      }
    });
    btSenke.setText("Senke");
    btSenke.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btSenke_actionPerformed(e);
      }
    });
    btAnimationStoppen.setText(" STOP ");
    btAnimationStoppen.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
      	btAnimationStoppen_actionPerformed(e);
      }
    });
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(1024, 700));
    this.setTitle("Verkehrsplaner-GUI");

    this.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        this_mouseReleased(e);
      }
    });
    jpController.setBackground(Color.white);
    jpController.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        jpController_mousePressed(e);
      }
      public void mouseClicked(MouseEvent e) {
        jpController_mouseClicked(e);
      }
      public void mouseReleased(MouseEvent e) {
        jpController_mouseReleased(e);
      }
    });
    jpController.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
      public void mouseDragged(MouseEvent e) {
        jpController_mouseDragged(e);
      }
    });

    JMenuItem myPopupEinstellungen = new JMenuItem("Einstellungen");
    myPopupEinstellungen.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
      	myPopupEinstellungen_actionPerformed(e);
      }
    });
    myPopup.add(myPopupEinstellungen);
    
    
    JMenuItem myPopupBewegen = new JMenuItem("Bewegen");
    myPopupBewegen.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
      	myPopupBewegen_actionPerformed(e);
      }
    });
    myPopup.add(myPopupBewegen);
    
    myPopup.addSeparator();
    
    JMenuItem myPopupQuelle = new JMenuItem("neue Quelle");
    myPopupQuelle.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
      	myPopupQuelle_actionPerformed(e);
      }
    });
    myPopup.add(myPopupQuelle);
    
    JMenuItem myPopupSenke = new JMenuItem("neue Senke");
    myPopupSenke.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
      	myPopupSenke_actionPerformed(e);
      }
    });
    myPopup.add(myPopupSenke);
    
//    JMenuItem myPopupKreisverkehr = new JMenuItem("neuer Kreisverkehr");
//    myPopupKreisverkehr.addActionListener(new ActionListener()  {
//      public void actionPerformed(ActionEvent e) {
//      	myPopupKreisverkehr_actionPerformed(e);
//      }
//    });
//    myPopup.add(myPopupKreisverkehr);
//    
//    JMenuItem myPopupAmpel = new JMenuItem("neue Ampel");
//    myPopupAmpel.addActionListener(new ActionListener()  {
//      public void actionPerformed(ActionEvent e) {
//      	myPopupAmpel_actionPerformed(e);
//      }
//    });
//    myPopup.add(myPopupAmpel);
//    
//    myPopup.addSeparator();
//    
//    JMenuItem myPopupStrasse = new JMenuItem("Strassenbau-Modus");
//    myPopupStrasse.addActionListener(new ActionListener()  {
//      public void actionPerformed(ActionEvent e) {
//      	myPopupStrasse_actionPerformed(e);
//      }
//    });
//    myPopup.add(myPopupStrasse);
    

    
    this.addComponentListener(new ComponentListener(){
    	public void componentResized(ComponentEvent e){
    		myWindows_componentResized(e);
    	}
    	public void componentHidden(ComponentEvent e){}
    	public void componentMoved(ComponentEvent e){}
    	public void componentShown(ComponentEvent e){}

    });
    
    jMenuFile.setText("Datei");
    jMenuFileExit.setText("Beenden");
    jMenuFileExit.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	jMenuFileExit_actionPerformed(e);
        }
      });
    jMenuFileLoad.setText("Laden");
    jMenuFileLoad.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuFileLoad_actionPerformed(e);
      }
    });
    jMenuFileSave.setText("Speichern");
    jMenuFileSave.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuFileSave_actionPerformed(e);
      }
    });
    jMenuFileLoadHintergrund.setText("Hintergrundbild Laden");
    jMenuFileLoadHintergrund.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuFileLoadHintergrund_actionPerformed(e);
      }
    });
    jMenuFileEinstellungen.setText("Allgemeine Einstellungen");
    jMenuFileEinstellungen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
          jMenuFileEinstellungen_actionPerformed(e);
        }
      });
    jMenuHelp.setText("Hilfe");
    jMenuHelpAbout.setText("Info");
    jMenuHelpAbout.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	jMenuHelpAbout_actionPerformed(e);
        }
      });
    btBewegen.setText(" Bewegen ");
    btBewegen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btBewegen_actionPerformed(e);
        }
      });
    btBewegenSimu.setText(" Bewegen ");
    btBewegenSimu.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btBewegen_actionPerformed(e);
        }
      });
    btBewegenErgebnis.setText(" Bewegen ");
    btBewegenErgebnis.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btBewegen_actionPerformed(e);
        }
      });
    btAmpel.setText(" Ampel ");
    btAmpel.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btAmpel_actionPerformed(e);
        }
      });
    btRechtsVorLinks.setText(" RechtsVorLinks ");
    btRechtsVorLinks.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btRechtsVorLinks_actionPerformed(e);
          }
        });
    btVorfahrt.setText(" Vorfahrt ");
    btVorfahrt.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btVorfahrt_actionPerformed(e);
          }
        });
    btKreisverkehr.setText(" Kreisverkehr ");
    btKreisverkehr.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btKreisverkehr_actionPerformed(e);
          }
        });
    btStrasse.setText(" Stra�enbau Modus ");
    btStrasse.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btStrasse_actionPerformed(e);
          }
        });
    btEinstellungen.setText(" Einstellungen ");
    btEinstellungen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btEinstellungen_actionPerformed(e);
          }
        });
    btAnimationsdetails.setText(" Animations Details ");
    btAnimationsdetails.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btAnimationsDetails_actionPerformed(e);
          }
        });
    btZeigeNamen.setText("   Namen anzeigen  ");
    btZeigeNamen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btZeigeNamen_actionPerformed(e);
          }
        });
    btZeigeNamenSimu.setText("   Namen anzeigen  ");
    btZeigeNamenSimu.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btZeigeNamen_actionPerformed(e);
          }
        });
    btLoeschen.setText(" L�schen ");
    btLoeschen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btloeschen_actionPerformed(e);
          }
        });
    btUndo.setText(" Undo ");
    btUndo.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btUndo_actionPerformed(e);
          }
        });
    btRedo.setText(" Redo ");
    btRedo.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btRedo_actionPerformed(e);
          }
        });
    btErgebnisExport.setText(" Ergebnis exportieren ");
    btErgebnisExport.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	btErgebnisExport_actionPerformed(e);
        	
          }
    });
    btErgebnisDetails.setText(" Detailansicht ");
    btErgebnisDetails.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	btErgebnisDetails_actionPerformed(e);
        	
          }
    });
    btErgebnisBeenden.setText(" Ergebnisansicht schlie�en");
    btErgebnisBeenden.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	btErgebnisBeenden_actionPerformed(e);
          }
    });
    cbStrasse.addItem(" Nebenstra�e ");
    cbStrasse.addItem(" Hauptstra�e ");
    cbStrasse.addItem(" Bundesstra�e ");
    cbStrasse.setMaximumSize(new Dimension(125,20));
    cbStrasse.addItemListener( new ItemListener() {
        public void itemStateChanged( ItemEvent e ) {
        	modus = "strasse";
        }
      });
    
    cbAmpel.addItem(" Klein ");
    cbAmpel.addItem(" Mittel ");
    cbAmpel.addItem(" Gro� ");
    cbAmpel.addItem(" Optimiert ");
    cbAmpel.setMaximumSize(new Dimension(75,20));
    cbAmpel.addItemListener( new ItemListener() {
        public void itemStateChanged( ItemEvent e ) {
        	if(cbAmpel.getSelectedIndex() == 0)
        		ampelTyp = "K";
        	else if(cbAmpel.getSelectedIndex() == 1)
        		ampelTyp = "M";
        	else if(cbAmpel.getSelectedIndex() == 2)
        		ampelTyp = "G";
        	else if(cbAmpel.getSelectedIndex() == 3)
        		ampelTyp = "O";
        }
      });
    
    cbErgebnis.addItem(" aktuelle WS l�nge ");
    cbErgebnis.addItem(" durchs. WS l�nge ");
    cbErgebnis.addItem(" max WS l�nge ");
    cbErgebnis.addItem(" durchs. Wartezeit ");
    cbErgebnis.addItem(" proz. Stra�enauslastung ");
    cbErgebnis.addItem(" proz. Stau ");
    cbErgebnis.setMaximumSize(new Dimension(250,20));
    cbErgebnis.addItemListener( new ItemListener() {
        public void itemStateChanged( ItemEvent e ) {
        	cbErgebnis_itemStateChanged(e);
        }
      });
    
    jpController.setBounds(new Rectangle(20, 55, 972, 535));
    jpController.setLayout(null);
    labelGeschw.setMinimumSize(new Dimension(100,20));
    jPanel2.setBorder(BorderFactory.createLineBorder(Color.black));
    jPanel2.setLayout(flowLayout1);
    btStart.setText(" Simulation starten ");
    btStart.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	btStart_actionPerformed(e);
        	
          }
    });
    tfDauer.setText("   "+Double.toString(aE.getSimulationsDauer()));
    jPanel1.setBounds(new Rectangle(20, 570, 972, 76));
    jPanel1.setLayout(borderLayout1);
    jPanel3.setLayout(flowLayout2);
    jPanel3.setBorder(BorderFactory.createLineBorder(Color.black));
    jMenuFile.add(jMenuFileLoad);
    jMenuFile.add(jMenuFileSave);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuFileLoadHintergrund);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuFileEinstellungen);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuFileExit);
    jMenuHelp.add(jMenuHelpAbout);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenuHelp);
    toolbarErgebnis.add(btBewegenErgebnis,null);
    toolbarErgebnis.addSeparator();
    toolbarErgebnis.add(btErgebnisDetails,null);
    toolbarErgebnis.add(cbErgebnis,null);
    toolbarErgebnis.addSeparator();
    toolbarErgebnis.add(btErgebnisExport,null);
    toolbarErgebnis.add(btErgebnisBeenden,null);
    toolbarSimu.add(btBewegenSimu,null);
    toolbarSimu.addSeparator();
    toolbarSimu.add(btZeigeNamenSimu,null);
    toolbarSimu.addSeparator();
    toolbarSimu.add(btAnimationsdetails,null);
    toolbarSimu.addSeparator();
    toolbarSimu.add( new JLabel(" Langsam "));
    toolbarSimu.add(mySlider,null);
    toolbarSimu.add( new JLabel(" Schnell "));
    toolbarSimu.addSeparator();
    toolbarSimu.add(labelGeschw,null);
    toolbarSimu.addSeparator();
    toolbarSimu.add(btAnimationStoppen,null);
    toolbar.add(btBewegen,null);
    toolbar.addSeparator();
    toolbarNeu.add( new JLabel(" Neu: "));
    toolbarNeu.addSeparator();
    toolbarNeu.add(btStrasse,null);
    toolbarNeu.add(cbStrasse,null);
    toolbarNeu.addSeparator();
    toolbar.add(btEinstellungen,null );
    toolbar.add(btZeigeNamen,null);
    toolbar.addSeparator();
    toolbar.add(btUndo);
    toolbar.add(btRedo);
    toolbar.addSeparator();
    toolbarNeu.add(btQuelle);
    toolbarNeu.add(btSenke);
    toolbarNeu.add(btRechtsVorLinks);
    toolbarNeu.add(btVorfahrt);
    toolbarNeu.add(btKreisverkehr);
    toolbarNeu.add(btAmpel,null);
    toolbarNeu.add(cbAmpel,null);
    toolbarNeu.addSeparator();
    toolbar.add(btLoeschen);
    toolbar.addSeparator();
    toolbar.add( new JLabel(" Dauer: "));
    toolbar.add(tfDauer,null);
    toolbar.add(btStart,null);
    toolbar.setFloatable(false); //Toolbar ist nicht verschiebbar in ein extra Fenster
    toolbarNeu.setFloatable(false); //Toolbar ist nicht verschiebbar in ein extra Fenster
    toolbar.setBounds(new Rectangle(0, 0, 972, 25));
    toolbarNeu.setBounds(new Rectangle(0,26,972,25));
    toolbarSimu.setVisible(false);
    toolbarSimu.setBounds(new Rectangle(0, 0, 972, 25));	//Toolbar f�r die Animation
    toolbarSimu.setFloatable(false); //Toolbar ist nicht verschiebbar in ein extra Fenster
    toolbarErgebnis.setVisible(false);
    toolbarErgebnis.setBounds(new Rectangle(0, 0, 972, 25));	//Toolbar f�r die Animation
    toolbarErgebnis.setFloatable(false); //Toolbar ist nicht verschiebbar in ein extra Fenster
    pbFortschritt.setVisible(false);
    pbFortschritt.setBounds(new Rectangle(0,26,972,25));			//Fortschrittsbalken
    contentPane.add(jpController, null);
    contentPane.add(toolbar,null);
    contentPane.add(toolbarNeu,null);
    contentPane.add(pbFortschritt,null);
    contentPane.add(toolbarSimu,null);
    contentPane.add(toolbarErgebnis,null);
    this.setJMenuBar(jMenuBar1);
    cbStrasse.setSelectedIndex(1);
  }



//Gr��en�nderungen des Fensters �bernehmen
protected void myWindows_componentResized(ComponentEvent e) {
	jpController.setSize(this.getWidth()-50,this.getHeight()-115);
}

//protected void myPopupAmpel_actionPerformed(ActionEvent e) {
//    jpController.add(new AmpelAbschnitt(jpController.getNewId(),eX,eY,jpController,ampelTyp));
//    this.repaint();
//}
//
//protected void myPopupKreisverkehr_actionPerformed(ActionEvent e) {
//    jpController.add(new KreisverkehrAbschnitt(jpController.getNewId(),eX,eY,jpController));
//    this.repaint();
//}

protected void myPopupSenke_actionPerformed(ActionEvent e) {
    jpController.add(new SenkeAbschnitt(jpController.getNewId(),eX,eY,jpController));
    this.repaint();
}

protected void myPopupQuelle_actionPerformed(ActionEvent e) {
    jpController.add(new QuelleAbschnitt(jpController.getNewId(),eX,eY,jpController));
    this.repaint();
}

protected void myPopupEinstellungen_actionPerformed(ActionEvent e) {
	Abschnitt tmp = jpController.findByPos(eX,eY);
    if(tmp != null){
      tmp.zeigeEinstellungen();       
    }
}

protected void myPopupStrasse_actionPerformed(ActionEvent e) {
    modus = "strasse";
}

protected void myPopupBewegen_actionPerformed(ActionEvent e) {
    modus = "bewegen";
}

//Aktion Datei | Beenden durchgef�hrt
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  //Aktion Hilfe | Info durchgef�hrt
  public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
    GUI_Infodialog dlg = new GUI_Infodialog(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.pack();
    dlg.setVisible(true);
  }

  //�berschrieben, so dass eine Beendigung beim Schlie�en des Fensters m�glich ist
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }
  

  protected void jMenuFileSave_actionPerformed(ActionEvent e) {
  	aE.setIdCounter(jpController.getNewId());
  	aE.setOldHeight(jpController.getHeight());
  	aE.setOldWidth(jpController.getWidth());
  	
  	aE.setPfadHintergrund(jpController.getHintergrund());
  	aE.setSimulationsDauer(Double.parseDouble(tfDauer.getText()));
  	
  	FactoryGUI factory = new FactoryGUI();
  	factory.speichereDaten(jpController.getAlleEinstellungen(),aE);
  }


  protected void jMenuFileLoad_actionPerformed(ActionEvent e) {

  	FactoryGUI factory = new FactoryGUI();
  	aE = factory.ladeDaten(jpController);
  	if(aE != null){
  	  	jpController.setNewId(aE.getIdCounter());
  	  	jpController.setHintergrund(aE.getPfadHintergrund());
  	  	tfDauer.setText("   "+Double.toString(aE.getSimulationsDauer()));
  	  	jpController.repaint();
  	}
  	
  	jpController.setSize(this.getWidth()-50,this.getHeight()-115);
  }
  
  protected void jMenuFileLoadHintergrund_actionPerformed(ActionEvent e) {
  	Dateizugriff datei = new Dateizugriff();
  	jpController.setHintergrund(datei.LadeHintergrund());
  	jpController.repaint();
  }
  
  protected void jMenuFileEinstellungen_actionPerformed(ActionEvent e) {
    einstellungen.initialisieren(aE);
    einstellungen.setSize(550,475);
    einstellungen.setTitle("Allgemeine Einstellungen");
    einstellungen.setVisible(true);
  }

  void btUndo_actionPerformed(ActionEvent e) {
  	jpController.undo();
  }

  void btRedo_actionPerformed(ActionEvent e) {
  	jpController.redo();
  }
  
  void btBewegen_actionPerformed(ActionEvent e) {
    modus = "bewegen";
  }

  void btAmpel_actionPerformed(ActionEvent e) {
   modus = "ampel";
  }
  
  void btRechtsVorLinks_actionPerformed(ActionEvent e) {
  	modus = "rechtsVorLinks";
   }
  
  void btVorfahrt_actionPerformed(ActionEvent e) {
  	modus = "vorfahrt";
   }

  void btKreisverkehr_actionPerformed(ActionEvent e) {
    modus = "kreisverkehr";
  }

  void btStrasse_actionPerformed(ActionEvent e) {
    modus = "strasse";
  }

  void btEinstellungen_actionPerformed(ActionEvent e) {
    modus = "einstellungen";
  }
  
  void btAnimationsDetails_actionPerformed(ActionEvent e) {
    modus = "animationsdetails";
  }

  void btZeigeNamen_actionPerformed(ActionEvent e) {
  	if(zeigeNamen == false){
  		jpController.zeigeNamen(true);
  	  	btZeigeNamen.setText(" Namen verstecken ");
  	    btZeigeNamenSimu.setText(" Namen verstecken ");
  	  	zeigeNamen = true;
  	}
  	else{
  		jpController.zeigeNamen(false);
  	  	btZeigeNamen.setText("   Namen anzeigen  ");
  	    btZeigeNamenSimu.setText("   Namen anzeigen  ");
  	  	zeigeNamen = false;
  	}
  	
  }
  
  void btloeschen_actionPerformed(ActionEvent e) {
    modus = "loeschen";
  }
  
  void btAnimationStoppen_actionPerformed(ActionEvent e) {
  	animationStop=true;
  }

  void btSenke_actionPerformed(ActionEvent e) {
    modus = "senke";
  }

  void btQuelle_actionPerformed(ActionEvent e) {
    modus = "quelle";
  }



  // JPanel Event
 void jpController_mouseClicked(MouseEvent e) {
 	
 	if (e.getButton() == 3 || e.isPopupTrigger()){
 		
 		//Kontextmen� aufrufen
 		eX = e.getX();
 		eY = e.getY();
 		myPopup.show(e.getComponent(),e.getX(), e.getY());

 	}
    else if (modus.equals("einstellungen") || e.getButton() == 3){
        Abschnitt tmp = jpController.findByPos(e.getX(),e.getY());
        if(tmp != null){
          tmp.zeigeEinstellungen();       
        }
      }
    else if(modus.equals("animationsdetails")){
    	Abschnitt tmp = jpController.findByPos(e.getX(),e.getY());
        if(tmp != null){
          tmp.zeigeAnimationsDetails();    
        }
    }
    else if(modus.equals("ergebnisdetails")){
    	Abschnitt tmp = jpController.findByPos(e.getX(),e.getY());
        if(tmp != null){
          tmp.zeigeErgebnis();    
        }
    }

 }

 void jpController_mouseDragged(MouseEvent e) {
   // Kreuzung verschieben
 	
   if (modus.equals("bewegen")) {
     if (tempAbschnitt != null) {
     	tempAbschnitt.setPos(e.getX(),e.getY());
     	this.repaint();
     }
   }    //Strasse ziehen
   else if (modus.equals("strasse") && tempStrasse != null) {
     tempStrasse.setSimPos(e.getX(),e.getY());	//Zeichnen beim ziehen
     if(jpController.findKonnektorByPos(e.getX(), e.getY()) != null){
     	tempStrasse.overKonnektor(true);
     }
     else{
     	tempStrasse.overKonnektor(false);
     }
     jpController.paintKante(tempStrasse);

   }
 }

 void jpController_mousePressed(MouseEvent e) {

 	if(e.getButton() != 1 ){	//Nur Linke Maustaste beachten
 		return;
 	}
 	
   if (modus.equals("strasse")) {		//Neue Strasse erstellen
     // neue Stra�e
     tempKonnektor = jpController.findKonnektorByPos(e.getX(), e.getY());    // element auf das gelickt wurde ermitteln
     if (tempKonnektor != null) {     // muss vom typ Kreuzung sein
     	tempStrasse = new StrassenAbschnitt(jpController.getNewId(),
      		tempKonnektor,jpController,cbStrasse.getSelectedIndex());         // tempor�re neue Stra�e anlegen
     }
   }
   else if(modus.equals("bewegen")){
     tempAbschnitt = jpController.findByPos(e.getX(), e.getY());
   }
 }

 void this_mouseReleased(MouseEvent e) {
 }

 void jpController_mouseReleased(MouseEvent e) {

 	if(e.getButton() != 1 ){	//Nur Linke Maustaste beachten
 		jpController.paintKante(null);
 		tempStrasse=null;
 		return;
 	}
 	
 	//Neue Stra�e beim Aufziehen loslassen
   if ((modus.equals("strasse")) && (tempStrasse != null)) {       // wenn status auf Stra�e erstellen steht und eine tempStrasse da ist
     // es wurde begonnen eine Stra�e zu erstellen

     Konnektor theReleased;
     theReleased = jpController.findKonnektorByPos(e.getX(), e.getY());
     if (theReleased != null) {

       if ((theReleased != tempKonnektor)) {
         // maus wurde auf einem Konnektor losgelassen
         tempStrasse.setDestKnoten(theReleased);

         if ((jpController.findKante(tempStrasse.getA(),tempStrasse.getB())==null) &&
            ((jpController.findKante(tempStrasse.getB(),tempStrasse.getA()))==null) &&
			(tempStrasse.getA() != tempStrasse.getB())
            && tempStrasse.getA().weiterAnbindungenMoeglich(tempStrasse.getKonnektorA())
            && tempStrasse.getB().weiterAnbindungenMoeglich(tempStrasse.getKonnektorB())) {     // pr�fen ob die Stra�e schon angelegt wurde

//          tempStrasse.getA().addStrasse(tempStrasse);		// Dies erledigt ab sofort der
//          tempStrasse.getB().addStrasse(tempStrasse);		//     GuiController
          jpController.add(tempStrasse);          // temp. Stra�e in den Controller aufnehmen
         }

         jpController.paintKante(null);

         tempStrasse=null;
         this.repaint();
       }
     }
     else {
       jpController.paintKante(null);
       tempStrasse=null;
     }
   }			//Damit auch beim Bewegen eine Ampel, ... erstellt werden kann
   else if (modus.equals("ampel")) {
    jpController.add(new AmpelAbschnitt(jpController.getNewId(),e.getX(),e.getY(),jpController,ampelTyp));
    this.repaint();
  }
  else if (modus.equals("kreisverkehr")) {
    jpController.add(new KreisverkehrAbschnitt(jpController.getNewId(),e.getX(),e.getY(),jpController));
    this.repaint();
  }
  else if (modus.equals("rechtsVorLinks")) {
    jpController.add(new RechtsVorLinksAbschnitt(jpController.getNewId(),e.getX(),e.getY(),jpController));
    this.repaint();
  }
  else if (modus.equals("vorfahrt")) {
    jpController.add(new VorfahrtAbschnitt(jpController.getNewId(),e.getX(),e.getY(),jpController));
    this.repaint();
  }

  else if (modus.equals("loeschen")) {
    jpController.removeElement(e.getX(), e.getY());
  }

  else if (modus.equals("quelle")){
    jpController.add(new QuelleAbschnitt(jpController.getNewId(),e.getX(),e.getY(),jpController));
    this.repaint();
  }
  else if (modus.equals("senke")){
    jpController.add(new SenkeAbschnitt(jpController.getNewId(),e.getX(),e.getY(),jpController));
    this.repaint();
  }
 }
 

 void btStart_actionPerformed(ActionEvent e) {
 	toolbar.setVisible(false);
 	toolbarNeu.setVisible(false);
 	pbFortschritt.setVisible(true);
 	toolbarSimu.setVisible(true);
 	
    animation = new Thread(this);
    animation.start ();
 }
 
 void btErgebnisBeenden_actionPerformed(ActionEvent e){
 	toolbarErgebnis.setVisible(false);
  	toolbarNeu.setVisible(true);
  	toolbar.setVisible(true);
 }
 
 void btErgebnisDetails_actionPerformed(ActionEvent e){
 	modus = "ergebnisdetails";
 }
 
 void btErgebnisExport_actionPerformed(ActionEvent ev){
 	//System.err.println("Noch nicht implementiert");
 	String ausgabe = "Ergebnis�bersicht:\n\n";
 	
 	for(int i=0;i<ergebnis.size();i++){
 		Ergebnis e = (Ergebnis) ergebnis.get(i);
 		Abschnitt tmp = jpController.findByID(e.getId());
 		if(tmp != null){
 			
 			boolean vorWS=false;
 			
 			ausgabe += "Kreuzungs-ID: "+tmp.getId()+"; Kreuzungs-Name: " +tmp.getNamen()+"\n";
 			if(e.laengeVorWS() > 0){
 				vorWS=true;
 				ausgabe += "Daten der vorgelagerten WS:\n";
 				ausgabe += "WS-ID;Beschreibung;L�nge;durchs. L�nge;max L�nge;durchs. Wartezeit;proz. Stra�enauslastung;proz. Stau\n";
 				for(int j=0;j<e.laengeVorWS();j++){
 					WarteschlangeErgebnis ws = e.getVorWS(j);
 					ausgabe += Integer.toString(j)+";"+ws.getBeschreibung()
 					+";"+ws.getAnzahlFahrzeuge()+";"
 					+ptk(ws.getDurchsWartendeFahrzeuge())+";"+ws.getMaxAnzahlFahrzeuge()
 					+";"+ptk(ws.getDurchsVerweilzeitWS())+";"+ptk(ws.getProzentualeStrassenauslastung())
 					+";"+ptk(ws.getProzentualBlockiert())
 					+"\n";
 				}
 			}
 			
 			ausgabe += "\nDaten der WS:\n";
 			ausgabe += "WS-ID;Beschreibung;L�nge;durchs. L�nge;max L�nge;durchs. Wartezeit;proz. Stra�enauslastung";
 			if(!vorWS)
 				ausgabe += ";proz. Stau";
 			ausgabe += "\n";
 			for(int j=0;j<e.laengeWS();j++){
 				WarteschlangeErgebnis ws = e.getWS(j);
 				ausgabe += Integer.toString(j)+";"+ws.getBeschreibung()
 				+";"+ws.getAnzahlFahrzeuge()+";"
 				+ptk(ws.getDurchsWartendeFahrzeuge())+";"+ws.getMaxAnzahlFahrzeuge()
 				+";"+ptk(ws.getDurchsVerweilzeitWS())+";"+ptk(ws.getProzentualeStrassenauslastung());
 				if(!vorWS)
 					ausgabe +=";"+ptk(ws.getProzentualBlockiert());
 				ausgabe +="\n";
 			}
 			
 			ausgabe += "\n\n\n";
 		}
 	}
 	
 	Dateizugriff datei = new Dateizugriff();
 	datei.export(ausgabe);
 }
 
 private String ptk(double eingabe){
 	String ausgabe = Double.toString(eingabe);
 	ausgabe = ausgabe.replace('.',',');
 	return ausgabe;
 }
 
 
 
 void cbErgebnis_itemStateChanged(ItemEvent e){
 	if(lastErgebnis == cbErgebnis.getSelectedIndex()){
 		return;
 	}
 	lastErgebnis = cbErgebnis.getSelectedIndex();
 	
// 	aktuelle WS l�nge
// 	durchs. WS l�nge
// 	durchs. Wartezeit
// 	proz. Stra�enauslastung
// 	proz. Stau
//	Max WS L�nge
 	int eModus=0;
 	
 	if(cbErgebnis.getSelectedIndex() == 0){	//aktuelle WS l�nge
 		eModus=0;
 	}
 	else if(cbErgebnis.getSelectedIndex() == 1){ //durchs. WS l�nge
 		eModus=1;
 	}
 	else if(cbErgebnis.getSelectedIndex() == 3){ //durchs. Wartezeit
 		eModus=2;
 	}
 	else if(cbErgebnis.getSelectedIndex() == 4){ //proz. Stra�enauslastung
 		eModus=3;
 	}
 	else if(cbErgebnis.getSelectedIndex() == 5){ //proz. Stau
 		eModus=4;
 	}
 	else if(cbErgebnis.getSelectedIndex() == 2){//Max WS L�nge
 		eModus = 5;
 	}
 	
 	jpController.setErgebnisModus(eModus);
 }

 private void setErgebnis(Vector ergebnis){
 	this.ergebnis = ergebnis;
 	for(int i=0;i<ergebnis.size();i++){
 		Ergebnis e = (Ergebnis) ergebnis.get(i);
 		//System.err.println("Setze Ergebnis "+i+" bei Kreuzung "+e.getId());
 		Abschnitt tmp = jpController.findByID(e.getId());
 		if(tmp != null){
 			tmp.setErgebnis(e);
 		}
 	}
 }
 
 private Thread animation;
 
 public void run (){	
 	animationStop=false;
  	Vector daten = jpController.getAlleEinstellungen();
  	Factory simu = new Factory();
  	double dauer = Double.parseDouble(tfDauer.getText());
  	int teiler = (int) (dauer/100.0);
  	if(!simu.initalisiereSimulation(daten,dauer,aE)){	//Fehler abfangen
		pbFortschritt.setVisible(false);
	  	toolbarSimu.setVisible(false);
	  	toolbarNeu.setVisible(true);
	  	toolbar.setVisible(true);
  		return;
  	}

  	Status s = simu.naechstesEreignis();
  	
  	long zeitDiff=0;
  	long zeitAlt=0;
  	long zeitAkt=0;
  	
  	long durchgang=0;
  	long letzterDurchgang=0;
  	
  	int beschleunigung=10;
  	
  	double simuZeit=0;
  	
  	while(s != null){
  		zeitAkt = System.currentTimeMillis();
  		zeitDiff = zeitAkt - zeitAlt;
  		
  		Abschnitt a = jpController.findByID(s.getId());
  		a.setStatus(s);
  		s = simu.naechstesEreignis();
  		
  		if(zeitDiff > 100){
  			beschleunigung = (int)Math.pow(mySlider.getValue(),2);
  			labelGeschw.setText(Double.toString(Math.pow(mySlider.getValue(),2))+"X");
  			//System.out.println(mySlider.getValue());
  	  		zeitAlt = zeitAkt;
  			jpController.repaint();						//TODO Resourcenverbrauch verringern
  			//eventl. Hintergrundbild ausschalten
  			int fortschritt = (int) (simu.getZeit()/teiler);
  			pbFortschritt.setValue(fortschritt);
  			durchgang++;
  			if(animationStop){
  	  			pbFortschritt.setVisible(false);
  	  			toolbarSimu.setVisible(false);
  	  			toolbarErgebnis.setVisible(true);
  	  			setErgebnis(simu.auswertung());
  				return;
  			}
  		}
  		
  									//Anzeigedauer in sekunden *Beschleunigungsvektor
  		if(simu.getZeit()-simuZeit > 0.1*beschleunigung){
  	  		try{
  	  			if(letzterDurchgang+1 >= durchgang && zeitDiff < 100)	//Problem bei �berlastung -> zus�tzliches Bremsen verhindern
  	  				Thread.sleep(100-zeitDiff);	//Restliche Zeit schlafen
  	  			letzterDurchgang = durchgang;
  	  		}
  	  		catch (Exception e) {
  	  			e.printStackTrace();
  	  			Thread.currentThread().interrupt();
  	  			pbFortschritt.setVisible(false);
  	  			toolbarSimu.setVisible(false);
  	  			toolbarNeu.setVisible(true);
  	  			toolbar.setVisible(true);
  	  			return;
  	  		}
  	  		
  			simuZeit = simu.getZeit();
  		}
  	}
  	
		pbFortschritt.setVisible(false);
		toolbarSimu.setVisible(false);
		toolbarErgebnis.setVisible(true);
		setErgebnis(simu.auswertung());
  	return;
 }
}