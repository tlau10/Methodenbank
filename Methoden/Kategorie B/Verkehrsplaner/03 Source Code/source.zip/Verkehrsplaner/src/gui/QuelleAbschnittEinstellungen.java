package gui;

import java.awt.*;
import javax.swing.*;

import verkehrsplaner.QuelleEinstellungen;

import java.awt.event.*;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class QuelleAbschnittEinstellungen extends JDialog {
  private static final long serialVersionUID = 1193328365807674944L;
  private JPanel panel1 = new JPanel();
  private JPanel jPanel1 = new JPanel();
  private JButton btOK = new JButton();
  private JButton btAbbrechen = new JButton();
  private JPanel jPanel2 = new JPanel();
  private GridLayout gridLayout1 = new GridLayout(10,1);
  private JLabel jLabel1 = new JLabel();
  private JTextField tfName = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JTextField tfErwartungswert = new JTextField();
  private JLabel jLabel3 = new JLabel();
//  private JTextField tfVarianz = new JTextField();
  private JTextField tfK = new JTextField();
  private JLabel jLabel4 = new JLabel();
  private JTextField tfAnkunftsGeschwindigkeit = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JTextField tfAnzahlLKWs = new JTextField();
  
  private QuelleEinstellungen daten;
  private GuiController controller;

  public QuelleAbschnittEinstellungen(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public QuelleAbschnittEinstellungen() {
    this(null, "", false);
  }

  public QuelleAbschnittEinstellungen(QuelleEinstellungen daten, GuiController controller) {
  this(null, "", false);
  this.daten = daten;
  this.controller = controller;
  }
  
  public void initialisieren(KreuzungGUI kreuzung){
  	tfName.setText(daten.getName());
  	tfErwartungswert.setText(Double.toString(daten.getErwartungswert()));
//  	tfVarianz.setText(Double.toString(daten.getStandardabweichung()));
  	tfK.setText(Integer.toString(daten.getK()));
  	tfAnkunftsGeschwindigkeit.setText(Double.toString(daten.getAnkunftsGeschwindigkeit()));
  	tfAnzahlLKWs.setText(Double.toString(daten.getProzentuallerAnteilLKWs()*100.0));
  }


  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jPanel1.setBounds(new Rectangle(4, 293, 394, 35));
    btOK.setText("OK");
    btOK.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btOK_actionPerformed(e);
          }
        });
    btAbbrechen.setText("Abbrechen");
    btAbbrechen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btAbbrechen_actionPerformed(e);
          }
        });
    jPanel2.setBounds(new Rectangle(2, 21, 395, 250));
    jPanel2.setLayout(gridLayout1);
    jLabel1.setText("Quelle Name:");
    tfName.setText("");
    jLabel2.setToolTipText("");
    jLabel2.setText("Erwartungswert:");
    tfErwartungswert.setText("3.0");
    jLabel3.setText("Stufenzahl K:");
//    tfVarianz.setText("1.0");
    tfK.setText("2");
    jLabel4.setText("Ankunftsgeschwindigkeit der Fahrzeug in km/h:");
    tfAnkunftsGeschwindigkeit.setText("50.0");
    jLabel5.setText("Anzahl der LKWs am Verkehr in Prozent:");
    tfAnzahlLKWs.setText("10.0");
    getContentPane().add(panel1);
    panel1.add(jPanel1, null);
    jPanel1.add(btOK, null);
    jPanel1.add(btAbbrechen, null);
    panel1.add(jPanel2, null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(tfName, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(tfErwartungswert, null);
    jPanel2.add(jLabel3, null);
//    jPanel2.add(tfVarianz, null);
    jPanel2.add(tfK, null);
    jPanel2.add(jLabel4, null);
    jPanel2.add(tfAnkunftsGeschwindigkeit, null);
    jPanel2.add(jLabel5, null);
    jPanel2.add(tfAnzahlLKWs, null);
  }

  void btOK_actionPerformed(ActionEvent e) {
  	daten.setName(tfName.getText());
  	daten.setErwartungswert(Double.parseDouble(tfErwartungswert.getText()));
//  	daten.setStandardabweichung(Double.parseDouble(tfVarianz.getText()));
  	daten.setK(Integer.parseInt(tfK.getText()));
  	daten.setAnkunftsGeschwindigkeit(Double.parseDouble(tfAnkunftsGeschwindigkeit.getText()));
  	daten.setProzentuallerAnteilLKWs(Double.parseDouble(tfAnzahlLKWs.getText())/100.0);
  	controller.repaint();
    this.setVisible(false);
  }

  void btAbbrechen_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }
}

