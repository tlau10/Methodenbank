/*
 * Created on 21.10.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;

import java.awt.Frame;
import java.awt.Rectangle;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import verkehrsplaner.Ergebnis;
import verkehrsplaner.WarteschlangeErgebnis;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class KreuzungErgebnis extends JDialog {
	private static final long serialVersionUID = -8614392195979883315L;
	private JPanel panel1 = new JPanel();
	private JPanel jPanel1 = new JPanel();
	private JTextArea taInfo = new JTextArea();
	private JScrollPane spInfo = new JScrollPane();
	
	private String ausgabe="";
	
	public KreuzungErgebnis(Frame frame, String title, boolean modal) {
	  super(frame, title, modal);
	  try {
	    jbInit();
	    pack();
	  }
	  catch(Exception ex) {
	    ex.printStackTrace();
	  }
	}
	
	public KreuzungErgebnis() {
		this(null, "", false);
	}
	
	private void jbInit() throws Exception {
	  panel1.setLayout(null);
	  jPanel1.setLayout(null);
	  jPanel1.setBounds(new Rectangle(10, 10, 700, 480));
	  
	  spInfo.setBounds(new Rectangle(0, 0, 680, 470));
	  taInfo.setText("Kein Ergebnis vorhanden");
	  spInfo.getViewport().add(taInfo, null);
	  jPanel1.add(spInfo,null);
	  
	  getContentPane().add(panel1);
	  panel1.add(jPanel1, null);
	}
	
	public void initialsieren(){
		taInfo.setText(ausgabe);
	}
	
	public void setErgebnis(Ergebnis e){
//	 	aktuelle WS l�nge
//	 	durchs. WS l�nge
//	 	durchs. Wartezeit
//	 	proz. Stra�enauslastung
//	 	proz. Stau
//		Max WS L�nge
		
		boolean vorWS=false;
		
		ausgabe = "Ergebnis�bersicht:\n";
		if(e.laengeVorWS() > 0){
			vorWS = true;
			ausgabe += "Daten der vorgelagerten WS:\n";
 			ausgabe += "WS-ID\tBeschreibung\t\t\tL�nge\tdurchs. L�nge\tmax L�nge\tdurchs. Wartezeit\tproz. Stra�enauslastung\tproz. Stau\n";
 			for(int j=0;j<e.laengeVorWS();j++){
 					WarteschlangeErgebnis ws = e.getVorWS(j);
 					ausgabe += Integer.toString(j)+"\t"+ws.getBeschreibung()
 					+"\t\t"+ws.getAnzahlFahrzeuge()+"\t"
 					+ptk(ws.getDurchsWartendeFahrzeuge())+"\t\t"+ws.getMaxAnzahlFahrzeuge()
 					+"\t\t"+ptk(ws.getDurchsVerweilzeitWS())+"\t\t\t"+ptk(ws.getProzentualeStrassenauslastung())
 					+"\t\t\t"+ptk(ws.getProzentualBlockiert())
 					+"\n";
 			}
//			ausgabe += "Daten der vorgelagerten WS:\n";
//			ausgabe += "ID\tL�nge\td. L�nge\tmax L�nge\td. Wartezeit\tproz. Stra�enauslastung\tproz. Stau\n";
//			for(int i=0;i<e.laengeVorWS();i++){
//				WarteschlangeErgebnis ws = e.getVorWS(i);
//				ausgabe += Integer.toString(i)+"\t"+ws.getAnzahlFahrzeuge()+"\t"
//				+ws.getDurchsWartendeFahrzeuge()+"\t\t"+ws.getMaxAnzahlFahrzeuge()
//				+"\t\t"+ws.getDurchsVerweilzeitWS()+"\t\t"+ws.getProzentualeStrassenauslastung()
//				+"\t\t\t"+ws.getProzentualBlockiert()
//				+"\n";
//			}
		}
		
//		ausgabe += "\nDaten der WS:\n";
//		ausgabe += "ID\tL�nge\td. L�nge\tmax L�nge\td. Wartezeit\tproz. Stra�enauslastung\tproz. Stau\n";
//		for(int i=0;i<e.laengeWS();i++){
//			WarteschlangeErgebnis ws = e.getWS(i);
//			ausgabe += Integer.toString(i)+"\t"+ws.getAnzahlFahrzeuge()+"\t"
//			+ws.getDurchsWartendeFahrzeuge()+"\t\t"+ws.getMaxAnzahlFahrzeuge()
//			+"\t\t"+ws.getDurchsVerweilzeitWS()+"\t\t"+ws.getProzentualeStrassenauslastung()
//			+"\t\t\t"+ws.getProzentualBlockiert()
//			+"\n";
//		}
		
		ausgabe += "\nDaten der WS:\n";
		ausgabe += "WS-ID\tBeschreibung\t";
		if(vorWS)
			ausgabe += "\t";
 		ausgabe += "L�nge\tdurchs. L�nge\tmax L�nge\tdurchs. Wartezeit\tproz. Stra�enauslastung";
 		if(!vorWS)
 			ausgabe += "\tproz. Stau";
 		ausgabe += "\n";
 		for(int j=0;j<e.laengeWS();j++){
 				WarteschlangeErgebnis ws = e.getWS(j);
 				ausgabe += Integer.toString(j)+"\t"+ws.getBeschreibung()
 				+"\t\t"+ws.getAnzahlFahrzeuge()+"\t"
 				+ptk(ws.getDurchsWartendeFahrzeuge())+"\t\t"+ws.getMaxAnzahlFahrzeuge()
 				+"\t\t"+ptk(ws.getDurchsVerweilzeitWS())+"\t\t\t"+ptk(ws.getProzentualeStrassenauslastung());
 				
 				if(!vorWS)
 					ausgabe +="\t\t\t"+ptk(ws.getProzentualBlockiert());
 				ausgabe +="\n";
 			}
		
		ausgabe += "ENDE\n";
		
		taInfo.setText(ausgabe);
	}
	
	 private String ptk(double eingabe){
		 	String ausgabe = Double.toString(eingabe);
		 	ausgabe = ausgabe.replace('.',',');
		 	return ausgabe;
		 }

}
