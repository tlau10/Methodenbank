/*
 * Created on 30.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

import rechtsVorLinks.RechtsVorLinksEinstellungen;
/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RechtsVorLinksAbschnittEinstellungen  extends JDialog {
	private static final long serialVersionUID = -2895981229146211904L;
	private JPanel panel1 = new JPanel();
	private JPanel jPanel1 = new JPanel();
	private FlowLayout flowLayout1 = new FlowLayout();
	private JButton btOK = new JButton();
	private JButton btAbbrechen = new JButton();
	private JPanel jPanel2 = new JPanel();
	private GridLayout gridLayout1 = new GridLayout(3,2);
	private JLabel jLabel1 = new JLabel();
	private JTextField tfName = new JTextField();
	private JLabel jLabel2 = new JLabel();
	private JTextField tfBreite = new JTextField();
	private JComboBox cbModus = new JComboBox();
	private JLabel labelModus = new JLabel();
	  
	  
	  private JTable tVerteilungAbbieger;

	  private JLabel jLabel20 = new JLabel();
	  private JLabel jLabel21 = new JLabel();
	  private JLabel jLabel22 = new JLabel();
	  private JLabel jLabel23 = new JLabel();
	  private JLabel jLabel24 = new JLabel();
	  private JLabel jLabel25 = new JLabel();
	  private JLabel jLabel26 = new JLabel();
	  private JPanel jPanel3 = new JPanel();
	  
	  private RechtsVorLinksEinstellungen daten;
	  private GuiController controller;
	  private int modus;
	  private String[][] manuellVerteilungAbbieger = new String[4][3];
	  private KreuzungGUI kreuzung;

	  public RechtsVorLinksAbschnittEinstellungen(Frame frame, String title, boolean modal) {
	    super(frame, title, modal);
	    try {
	      jbInit();
	      pack();
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	  }

	  public RechtsVorLinksAbschnittEinstellungen() {
	    this(null, "", false);
	  }

	  public RechtsVorLinksAbschnittEinstellungen(RechtsVorLinksEinstellungen daten, GuiController controller) {
	  this(null, "", false);
	  this.daten = daten;
	  this.controller = controller;
	}
	  
	  public void initialisieren(KreuzungGUI kreuzung){
	  	this.kreuzung = kreuzung;
	  	int[] strassen = daten.getAnbindungen();
	  	
	    jLabel20.setText("N "+kreuzung.getStrassenNameById(strassen[0]));
	    jLabel21.setText("O "+kreuzung.getStrassenNameById(strassen[1]));
	    jLabel22.setText("S "+kreuzung.getStrassenNameById(strassen[2]));
	    jLabel23.setText("W "+kreuzung.getStrassenNameById(strassen[3]));
	    
	    tfBreite.setText(Double.toString(daten.getBreite()));
	    tfName.setText(daten.getName());
	  	for(int i=0;i<4;i++){
	  		for(int j=0;j<3;j++){
	  			tVerteilungAbbieger.setValueAt(Double.toString(daten.getAbbiegenWahl()[i][j]),j,i);
	  			manuellVerteilungAbbieger[i][j] = Double.toString(daten.getAbbiegenWahl()[i][j]);
	  		}
	  	}
	  	modus = -1;
	  	cbModus.setSelectedIndex(daten.getModus());
	  	setModus_actionPerformed(cbModus);
	  }


	  private void jbInit() throws Exception {
	    panel1.setLayout(null);
	    jPanel1.setLayout(flowLayout1);
	    jPanel1.setBounds(new Rectangle(1, 302, 504, 40));
	    btOK.setText("OK");
	    btOK.addActionListener(new ActionListener()  {
	        public void actionPerformed(ActionEvent e) {
	        	btOK_actionPerformed(e);
	          }
	        });
	    btAbbrechen.setText("Abbrechen");
	    btAbbrechen.addActionListener(new ActionListener()  {
	        public void actionPerformed(ActionEvent e) {
	        	btAbbrechen_actionPerformed(e);
	          }
	        });
	    jPanel2.setBounds(new Rectangle(10, 9, 459, 76));
	    jPanel2.setLayout(gridLayout1);
	    jLabel1.setText("Kreuzungsname:");
	    jLabel2.setText("Kreuzungsbreite in m:");
	    tfBreite.setText("3.0");
	    tfName.setText("");
	    jPanel3.setBounds(new Rectangle(-6, 130, 489, 115));
	    jPanel3.setLayout(null);

	    jLabel20.setText("NORD");
	    jLabel20.setBounds(new Rectangle(125, 0, 85, 17));
	    jLabel21.setText("OST");
	    jLabel21.setBounds(new Rectangle(212, 0, 85, 17));
	    jLabel22.setText("S�D");
	    jLabel22.setBounds(new Rectangle(300, 0, 85, 17));
	    jLabel23.setText("WEST");
	    jLabel23.setBounds(new Rectangle(387, 0, 85, 17));
	    jLabel24.setText("Rechtsabbieger");
	    jLabel24.setBounds(new Rectangle(28, 20, 96, 17));
	    jLabel25.setText("Geradeausfahrer");
	    jLabel25.setBounds(new Rectangle(23, 40, 95, 17));
	    jLabel26.setText("Linksabbieger");
	    jLabel26.setBounds(new Rectangle(36, 60, 90, 23));

	    String verteilungAbbiegendata[][] = {
	        {
	        "33", "33", "33", "33"}
	        , {
	        "33", "33", "33", "33"}
	        , {
	        "33", "33", "33", "33"}
	    };
	    String columnNames[] = {
	        "NORD", "Ost", "Sued", "West"};
	    tVerteilungAbbieger = new JTable( verteilungAbbiegendata , columnNames);

	    tVerteilungAbbieger.setMaximumSize(new Dimension(5, 5));
	    tVerteilungAbbieger.setMinimumSize(new Dimension(4, 4));
	    tVerteilungAbbieger.setRowHeight(20);
	    tVerteilungAbbieger.setBounds(new Rectangle(125, 20, 350, 60));
	    labelModus.setText("Abbiegewahrscheinlichkeiten: ");
	    cbModus.addItem("Automatik Modus");
	    cbModus.addItem("Manueller Modus");
	    cbModus.addItemListener( new ItemListener() {
	        public void itemStateChanged( ItemEvent e ) {
	          setModus_actionPerformed((JComboBox)e.getSource());
	        }
	      });
	    getContentPane().add(panel1);
	    jPanel1.add(btOK, null);
	    jPanel1.add(btAbbrechen, null);
	    panel1.add(jPanel3, null);
	    panel1.add(jPanel2, null);
	    jPanel2.add(labelModus,null);
	    jPanel2.add(cbModus,null);
	    jPanel2.add(jLabel1, null);
	    jPanel2.add(tfName, null);
	    jPanel2.add(jLabel2, null);
	    jPanel2.add(tfBreite, null);
	    jPanel3.add(tVerteilungAbbieger, null);
	    jPanel3.add(jLabel20,null);
	    jPanel3.add(jLabel21,null);
	    jPanel3.add(jLabel22,null);
	    jPanel3.add(jLabel23,null);
	    jPanel3.add(jLabel24,null);
	    jPanel3.add(jLabel25,null);
	    jPanel3.add(jLabel26,null);
	    panel1.add(jPanel1, null);

	  }

	  void btOK_actionPerformed(ActionEvent e) {
		double[][] abbiegenWahl = daten.getAbbiegenWahl();
		
		for(int i=0;i<4;i++){
			for(int j=0;j<3;j++){
				abbiegenWahl[i][j] = Double.parseDouble(tVerteilungAbbieger.getValueAt(j,i).toString());
			}
		}
	  	
		daten.setAbbiegenWahl(abbiegenWahl);
		daten.setBreite(Double.parseDouble(tfBreite.getText()));
		daten.setName(tfName.getText());
		daten.setModus(cbModus.getSelectedIndex());
	  	controller.repaint();
	    this.setVisible(false);
	  }

	  void btAbbrechen_actionPerformed(ActionEvent e) {
	    this.setVisible(false);
	  }
	  
	  void setModus_actionPerformed(JComboBox selectedChoice){
	  	if(selectedChoice.getSelectedIndex() == modus){
	  		return;
	  	}
	  	
	    if ( selectedChoice.getSelectedIndex() == 0){
	      	//System.out.println("Modus: Auto");
	      	tVerteilungAbbieger.setEnabled(false);
	      	tVerteilungAbbieger.setBackground(Color.LIGHT_GRAY);
	      	for(int i=0;i<4;i++){	//Manuelle Eingabe sichern
	      		for(int j=0;j<3;j++){
	      			manuellVerteilungAbbieger[i][j] = tVerteilungAbbieger.getValueAt(j,i).toString();
	      		}
	      	}
	      	modus = 0;
	      	double[][] autoAbbiegen = kreuzung.getAutoAbbiegen();
	      	for(int i=0;i<4;i++){	//Automatische Werte eintragen
	      		for(int j=0;j<3;j++){
	      			tVerteilungAbbieger.setValueAt(Double.toString(autoAbbiegen[i][j]),j,i);
	      		}
	      	}
	      }
	      else if(selectedChoice.getSelectedIndex() == 1){
	    	//System.out.println("Modus: Manuell");
	      	tVerteilungAbbieger.setEnabled(true);
	      	tVerteilungAbbieger.setBackground(Color.WHITE);
	      	for(int i=0;i<4;i++){	//Manuelle Eingabe wiederherstellen
	      		for(int j=0;j<3;j++){
	      			tVerteilungAbbieger.setValueAt(manuellVerteilungAbbieger[i][j],j,i);
	      		}
	      	}
	    	modus = 1;
	      }
	  }
}
