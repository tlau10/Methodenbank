package gui;

import java.awt.*;

import ampelGross.AmpelGrossEinstellungen;
import ampelKlein.AmpelKleinEinstellungen;
import ampelMittel.AmpelMittelEinstellungen;
import ampelTyp2.AmpelTyp2Einstellungen;

import verkehrsplaner.AmpelEinstellungen;
import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Status;
//import java.util.*;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class AmpelAbschnitt extends KreuzungGUI {

	private int maxStrassen=4;
	private AmpelAbschnittEinstellungen property;
	private AmpelEinstellungen daten;
	private AbschnittAnimation animation;
	protected KreuzungErgebnis kErgebnis;
	private Ergebnis e;
	private String ampelTyp="O";

  public AmpelAbschnitt(int id, int x, int y, GuiController c, String ampelTyp) {
       this.id = id;
       this.x = x;
       this.y = y;
       this.ampelTyp = ampelTyp;
       konn = new Konnektor[4];
       
       daten = new AmpelTyp2Einstellungen();
	   if(ampelTyp.equals("K")){
	   		daten = new AmpelKleinEinstellungen();
	   }
	   else if(ampelTyp.equals("M")){
	   		daten = new AmpelMittelEinstellungen();
	   }
	   else if(ampelTyp.equals("G")){
	   		daten = new AmpelGrossEinstellungen();
	   }
       
       daten.setId(id);
       daten.setName(daten.getName()+Integer.toString(id));
       property = new AmpelAbschnittEinstellungen(daten,c);
       animation = new AbschnittAnimation();
       konn[0] = new Konnektor(this,x,y-14,0);
       konn[1] = new Konnektor(this,x+22,y,1);
       konn[2] = new Konnektor(this,x,y+14,2);
       konn[3] = new Konnektor(this,x-22,y,3);
       angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
       kErgebnis = new KreuzungErgebnis();
   }
  
  public AmpelAbschnitt(AmpelEinstellungen daten, GuiController c) {
    this.id = daten.getId();
    this.x = daten.getX();
    this.y = daten.getY();
    this.daten = daten;
    konn = new Konnektor[maxStrassen];
    property = new AmpelAbschnittEinstellungen(daten,c);
    animation = new AbschnittAnimation();
    konn[0] = new Konnektor(this,x,y-14,0);
    konn[1] = new Konnektor(this,x+22,y,1);
    konn[2] = new Konnektor(this,x,y+14,2);
    konn[3] = new Konnektor(this,x-22,y,3);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
    kErgebnis = new KreuzungErgebnis();
    
    if(daten.getType().equals("AmpelTyp2Einstellungen")){
    	ampelTyp="O";
    }
    else if(daten.getType().equals("AmpelKleinEinstellungen")){
    	ampelTyp="K";
    }
    else if(daten.getType().equals("AmpelMittelEinstellungen")){
    	ampelTyp="M";
    }
    else if(daten.getType().equals("AmpelGrossEinstellungen")){
    	ampelTyp="G";
    }
}
  
  public String getNamen(){
  	return daten.getName();
  }

   public void paintMe(Graphics g)  {

     if (isBlockiert==true) {
       g.setColor(Color.red);
     }
     else {
       g.setColor(Color.orange);
     }
     
     g.setColor(Color.lightGray);
     g.fillRect(x-12,y-6,24,12);
     g.fillRect(x-6,y-12,12,24);

     g.setColor(Color.darkGray);
     g.drawRect(x-12,y-12,24,24);
     g.drawRect(x-12,y-12,6,6);
     g.drawRect(x+6,y-12,6,6);
     g.drawRect(x-12,y+6,6,6);
     g.drawRect(x+6,y+6,6,6);
     
     g.drawLine(x,y-12,x,y-7);
     g.drawLine(x,y+12,x,y+7);
     g.drawLine(x-12,y,x-7,y);
     g.drawLine(x+12,y,x+7,y);     
     
     //Die beiden AmpelSymbole
     g.setColor(Color.red);
     g.fillRect(x-20,y-9,6,6);
     g.setColor(Color.orange);
     g.fillRect(x-20,y-3,6,6);
     g.setColor(Color.green);
     g.fillRect(x-20,y+3,6,6);
     g.setColor(Color.darkGray);
     g.drawRect(x-20,y-9,6,18);
     g.drawLine(x-20,y-3,x-14,y-3);
     g.drawLine(x-20,y+3,x-14,y+3);
     
     g.setColor(Color.red);
     g.fillRect(x+14,y-9,6,6);
     g.setColor(Color.orange);
     g.fillRect(x+14,y-3,6,6);
     g.setColor(Color.green);
     g.fillRect(x+14,y+3,6,6);
     g.setColor(Color.darkGray);
     g.drawRect(x+14,y-9,6,18);
     g.drawLine(x+14,y-3,x+20,y-3);
     g.drawLine(x+14,y+3,x+20,y+3);
     
     for(int i=0;i<4;i++){
      	konn[i].paintMe(g);
      }
     
     g.setColor(Color.black);
     g.drawString(ampelTyp,x-3,y+4);
     if(zeigeNamen){
        g.drawString(daten.getName(),x-25,y+25);
     }
   }
   
   public boolean istInPosition(int x1, int y1) {
	  	if(x1>x-20 && x1<x+20 && y1>y-12 && y1<y+12){
	  		return true;
	  	}
	  	return false;
   }
   
   public void zeigeEinstellungen() {
   	 setAnbindungen();
   	 property.initialisieren(this);
     property.setSize(500,450);
     property.setTitle("Ampeleinstellungen");
     property.setVisible(true);

   }
   
	private void setAnbindungen(){
		daten.setAnbindungen(sortiereAnbindungen());
		
	}

	public String getName() {
	    return daten.getName();
	}

	public EinstellungsDaten getEinstellungen() {
		setAnbindungen();
		if(daten.getModus() == 0){	//Falls Automatisches Abbiegewahl gewollt
			daten.setAbbiegenWahl(getAutoAbbiegen());
		}								//TODO auto Ampelphasen speichern
		daten.setX(x);
		daten.setY(y);
		return daten;
	}
	
	public void zeigeAnimationsDetails() {
		animation.setTitle("Ampel Animation");
		animation.setSize(300,200);
		animation.setVisible(true);
	}
	
	public void setStatus(Status s){
		for(int i=0;i<s.getAnzahlWS();i++){
			StrassenAbschnitt abs = getStrasseById(s.getWsId()[i]);
			
			if(abs != null){
				abs.setWSBeschriftung(this,s.getWsLaenge()[i]);
			}
		}
		animation.setText(s.getInfoText());
	}
	
    public void setPos(int x1, int y1) {
    	x=x1;
    	y=y1;
        konn[0].setPos(x,y-14);
        konn[1].setPos(x+22,y);
        konn[2].setPos(x,y+14);
        konn[3].setPos(x-22,y);
    }
  
	public Konnektor getKonnektor(int x, int y) {
		for(int i=0;i<4;i++){
			if(konn[i].istInPosition(x,y)){
				return konn[i];
			}
		}
		return null;
	}
	
	public void setErgebnis(Ergebnis e){
		this.e = e;
		
		if(kErgebnis != null){
			kErgebnis.setErgebnis(e);
		}
		else{
			System.err.println("Ergebnis�bersicht exisitiert nicht");
		}
	}
	
	public void setErgebnisModus(int modus){
		if(kErgebnis == null)
			return; 
//	 	aktuelle WS l�nge
//	 	durchs. WS l�nge
//	 	durchs. Wartezeit
//	 	proz. Stra�enauslastung
//	 	proz. Stau
//		Max WS L�nge
		
		for(int i=0;i<4;i++){
			StrassenAbschnitt abs = angebundeneStrassen[i];
			
			if(abs != null){
				if(modus == 0)
					abs.setWSBeschriftung(this,e.getAnzahlFahrzeuge()[i]);
				else if(modus == 1)
					abs.setWSBeschriftung(this,e.getDurchsWSlaenge()[i]);
				else if(modus == 2)
					abs.setWSBeschriftung(this,e.getDurchsWartezeit()[i]);
				else if(modus == 3)
					abs.setWSBeschriftung(this,e.getProzAuslastung()[i]);//
				else if(modus == 4)
					abs.setWSBeschriftung(this,e.getProzStau()[i]);//
				else if(modus == 5)
					abs.setWSBeschriftung(this,e.getMaxLaenge()[i]);//
			}
		}
		
		
//		for(int i=0;i<4;i++){
//			StrassenAbschnitt abs = angebundeneStrassen[i];
//			
//			if(abs != null){	//TODO Anpassen
//				double summe=0;
//				if(modus == 0){
//					summe += e.getVorWS(i).getAnzahlFahrzeuge();
//					summe += e.getWS(i*2).getAnzahlFahrzeuge();
//					summe += e.getWS(i*2+1).getAnzahlFahrzeuge();
//				}
//				else if(modus == 1){
//					summe += e.getVorWS(i).getDurchsWartendeFahrzeuge();
//					summe += e.getWS(i*2).getDurchsWartendeFahrzeuge();
//					summe += e.getWS(i*2+1).getDurchsWartendeFahrzeuge();
//				}
//				else if(modus == 2){
//					summe += e.getWS(i*2).getDurchsWartendeFahrzeuge()*e.getWS(i*2).getAbgefertigteFahrzeuge();
//					summe += e.getWS(i*2+1).getDurchsWartendeFahrzeuge()*e.getWS(i*2+1).getAbgefertigteFahrzeuge();
//					summe = summe / (e.getWS(i*2).getAbgefertigteFahrzeuge()+e.getWS(i*2+1).getAbgefertigteFahrzeuge());
//					summe += e.getVorWS(i).getDurchsVerweilzeitWS();
//				}
//				else if(modus == 3){
//					summe += e.getVorWS(i).getProzentualeStrassenauslastung()*e.getVorWS(i).getMaxLaengeInMeter();
//					summe += e.getWS(i*2).getProzentualeStrassenauslastung()*e.getWS(i*2).getMaxLaengeInMeter();
//					summe += e.getWS(i*2+1).getProzentualeStrassenauslastung()*e.getWS(i*2+1).getMaxLaengeInMeter();
//					summe /= (e.getVorWS(i).getMaxLaengeInMeter()+e.getWS(i*2).getMaxLaengeInMeter()
//							+e.getWS(i*2+1).getMaxLaengeInMeter());
//				}
//				else if(modus == 4){
//					summe += e.getVorWS(i).getProzentualBlockiert();
//				}
//				else if(modus == 5){
//					summe += e.getVorWS(i).getMaxAnzahlFahrzeuge();
//					summe += e.getWS(i*2).getMaxAnzahlFahrzeuge();
//					summe += e.getWS(i*2+1).getMaxAnzahlFahrzeuge();
//				}
//				abs.setWSBeschriftung(this,summe);
//			}
//		}
	}
	
	public void zeigeErgebnis() {
	  	// TODO Auto-generated method stub
		if(kErgebnis == null){
			return;
		}
		kErgebnis.initialsieren();
		kErgebnis.setTitle("Ergebnis");
		kErgebnis.setSize(720,510);
		kErgebnis.setVisible(true);
		kErgebnis.initialsieren();
	}
}
