/*
 * Created on 01.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;

import java.util.LinkedList;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UndoController {
	private LinkedList undo;
	private LinkedList undoAbschnitt;
	private LinkedList redo;
	private LinkedList redoAbschnitt;
	private GuiController controller;
	
	public UndoController(GuiController controller){
		this.controller = controller;
		undo = new LinkedList();
		redo = new LinkedList();
		undoAbschnitt = new LinkedList();
		redoAbschnitt = new LinkedList();
	}
	
	public void add(Abschnitt a){
		controller.addOhneUndo(a);
		setUndo("remove",a);
		//Wenn man weiter Arbeitet, muss die Redo Liste verschwinden >>sonst Probleme
		redo = new LinkedList();
		redoAbschnitt = new LinkedList();
	}
	
	public void remove(Abschnitt a){
		controller.removeElementOhneUndo(a);
		setUndo("add",a);
//		Wenn man weiter Arbeitet, muss die Redo Liste verschwinden >>sonst Probleme
		redo = new LinkedList();
		redoAbschnitt = new LinkedList();
	}
	
	private void setUndo(String befehl, Abschnitt a){
		undo.addLast(befehl);
		undoAbschnitt.addLast(a);
	}
	
	private void setRedo(String befehl, Abschnitt a){
		redo.addLast(befehl);
		redoAbschnitt.addLast(a);
	}
	
	public void undo(){
		if(undo.size()>0){
			String befehl = (String) undo.getLast();
			Abschnitt a = (Abschnitt) undoAbschnitt.getLast();
			
//			System.out.println("Undo "+befehl+" Abschnitttyp"+a.getType()+" ID:"+a.getId());
			
			undo.removeLast();
			undoAbschnitt.removeLast();
			
			if(befehl.equals("add")){
				setRedo("remove",a);
				controller.addOhneUndo(a);
			}
			else if (befehl.equals("remove")){
				setRedo("add",a);
				controller.removeElementOhneUndo(a);
			}
		}
	}
	
	public void redo(){
		if(redo.size()>0){
			String befehl = (String) redo.getLast();
			Abschnitt a = (Abschnitt) redoAbschnitt.getLast();
			
//			System.out.println("Redo "+befehl+" Abschnitttyp"+a.getType()+" ID:"+a.getId());
			
			redo.removeLast();
			redoAbschnitt.removeLast();
			
			if(befehl.equals("add")){
				setUndo("remove",a);
				controller.addOhneUndo(a);
			}
			else if (befehl.equals("remove")){
				setUndo("add",a);
				controller.removeElementOhneUndo(a);
			}
		}
	}
	
	public void restart(){
		undo = new LinkedList();
		redo = new LinkedList();
		undoAbschnitt = new LinkedList();
		redoAbschnitt = new LinkedList();
	}
}
