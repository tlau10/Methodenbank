/*
 * Created on 30.10.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;

import java.awt.Color;
import java.awt.Graphics;

import rechtsVorLinks.RechtsVorLinksEinstellungen;

import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Status;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RechtsVorLinksAbschnitt  extends KreuzungGUI{
	private int maxStrassen=4;
	private RechtsVorLinksAbschnittEinstellungen property;
	private RechtsVorLinksEinstellungen daten;
	private AbschnittAnimation animation;
	protected KreuzungErgebnis kErgebnis;
	private Ergebnis e;

  public RechtsVorLinksAbschnitt(int id, int x, int y, GuiController c) {
       this.id = id;
       this.x = x;
       this.y = y;
       konn = new Konnektor[4];
       
       daten = new RechtsVorLinksEinstellungen();
       
       daten.setId(id);
       daten.setName(daten.getName()+Integer.toString(id));
       property = new RechtsVorLinksAbschnittEinstellungen(daten,c);
       animation = new AbschnittAnimation();
       konn[0] = new Konnektor(this,x,y-14,0);
       konn[1] = new Konnektor(this,x+16,y,1);
       konn[2] = new Konnektor(this,x,y+14,2);
       konn[3] = new Konnektor(this,x-16,y,3);
       angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
       kErgebnis = new KreuzungErgebnis();
   }
  
  public RechtsVorLinksAbschnitt(RechtsVorLinksEinstellungen daten, GuiController c) {
    this.id = daten.getId();
    this.x = daten.getX();
    this.y = daten.getY();
    this.daten = daten;
    konn = new Konnektor[maxStrassen];
    property = new RechtsVorLinksAbschnittEinstellungen(daten,c);
    animation = new AbschnittAnimation();
    konn[0] = new Konnektor(this,x,y-14,0);
    konn[1] = new Konnektor(this,x+16,y,1);
    konn[2] = new Konnektor(this,x,y+14,2);
    konn[3] = new Konnektor(this,x-16,y,3);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
    kErgebnis = new KreuzungErgebnis();
}
  
  public String getNamen(){
  	return daten.getName();
  }

   public void paintMe(Graphics g)  {

     if (isBlockiert==true) {
       g.setColor(Color.red);
     }
     else {
       g.setColor(Color.orange);
     }
     
     g.setColor(Color.lightGray);
     g.fillRect(x-12,y-6,24,12);
     g.fillRect(x-6,y-12,12,24);

     g.setColor(Color.darkGray);
     g.drawRect(x-12,y-12,24,24);
     g.drawRect(x-12,y-12,6,6);
     g.drawRect(x+6,y-12,6,6);
     g.drawRect(x-12,y+6,6,6);
     g.drawRect(x+6,y+6,6,6);
     
     g.drawLine(x,y-12,x,y-7);
     g.drawLine(x,y+12,x,y+7);
     g.drawLine(x-12,y,x-7,y);
     g.drawLine(x+12,y,x+7,y);     
     
     for(int i=0;i<4;i++){
      	konn[i].paintMe(g);
      }
     
     g.setColor(Color.black);
     if(zeigeNamen){
        g.drawString(daten.getName(),x-25,y+25);
     }
   }
   
   public boolean istInPosition(int x1, int y1) {
	  	if(x1>x-12 && x1<x+12 && y1>y-12 && y1<y+12){
	  		return true;
	  	}
	  	return false;
   }
   
   public void zeigeEinstellungen() {
   	 setAnbindungen();
   	 property.initialisieren(this);
     property.setSize(500,450);
     property.setTitle("Rechts vor Links Kreuzung Einstellungen");
     property.setVisible(true);

   }
   
	private void setAnbindungen(){
		daten.setAnbindungen(sortiereAnbindungen());
		
	}

	public String getName() {
	    return daten.getName();
	}

	public EinstellungsDaten getEinstellungen() {
		setAnbindungen();
		if(daten.getModus() == 0){	//Falls Automatisches Abbiegewahl gewollt
			daten.setAbbiegenWahl(getAutoAbbiegen());
		}								
		daten.setX(x);
		daten.setY(y);
		return daten;
	}
	
	public void zeigeAnimationsDetails() {
		animation.setTitle("Rechts vor Links Kreuzung Animation");
		animation.setSize(300,200);
		animation.setVisible(true);
	}
	
	public void setStatus(Status s){
		for(int i=0;i<s.getAnzahlWS();i++){
			StrassenAbschnitt abs = getStrasseById(s.getWsId()[i]);
			
			if(abs != null){
				abs.setWSBeschriftung(this,s.getWsLaenge()[i]);
			}
		}
		animation.setText(s.getInfoText());
	}
	
    public void setPos(int x1, int y1) {
    	x=x1;
    	y=y1;
        konn[0].setPos(x,y-14);
        konn[1].setPos(x+16,y);
        konn[2].setPos(x,y+14);
        konn[3].setPos(x-16,y);
    }
  
	public Konnektor getKonnektor(int x, int y) {
		for(int i=0;i<4;i++){
			if(konn[i].istInPosition(x,y)){
				return konn[i];
			}
		}
		return null;
	}
	
	public void setErgebnis(Ergebnis e){
		this.e = e;
		
		if(kErgebnis != null){
			kErgebnis.setErgebnis(e);
		}
		else{
			System.err.println("Ergebnis�bersicht exisitiert nicht");
		}
	}
	
	public void setErgebnisModus(int modus){
		if(kErgebnis == null)
			return; 
//	 	aktuelle WS l�nge
//	 	durchs. WS l�nge
//	 	durchs. Wartezeit
//	 	proz. Stra�enauslastung
//	 	proz. Stau
//		Max WS L�nge
		
		for(int i=0;i<4;i++){
			StrassenAbschnitt abs = angebundeneStrassen[i];
			
			if(abs != null){
				if(modus == 0)
					abs.setWSBeschriftung(this,e.getAnzahlFahrzeuge()[i]);
				else if(modus == 1)
					abs.setWSBeschriftung(this,e.getDurchsWSlaenge()[i]);
				else if(modus == 2)
					abs.setWSBeschriftung(this,e.getDurchsWartezeit()[i]);
				else if(modus == 3)
					abs.setWSBeschriftung(this,e.getProzAuslastung()[i]);//
				else if(modus == 4)
					abs.setWSBeschriftung(this,e.getProzStau()[i]);//
				else if(modus == 5)
					abs.setWSBeschriftung(this,e.getMaxLaenge()[i]);//
			}
		}
	}
	
	public void zeigeErgebnis() {
	  	// TODO Auto-generated method stub
		if(kErgebnis == null){
			return;
		}
		kErgebnis.initialsieren();
		kErgebnis.setTitle("Ergebnis");
		kErgebnis.setSize(720,510);
		kErgebnis.setVisible(true);
		kErgebnis.initialsieren();
	}
}
