package gui;

import java.awt.*;

import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Status;

import kreisverkehrTyp2.KreisverkehrTyp2Einstellungen;
//import java.util.*;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class KreisverkehrAbschnitt extends KreuzungGUI {

	private int maxStrassen=4;
	private KreisverkehrAbschnittEinstellungen property;
	private AbschnittAnimation animation;
	private KreisverkehrTyp2Einstellungen daten;
	protected KreuzungErgebnis kErgebnis;
	private Ergebnis e;

  public KreisverkehrAbschnitt(int id, int x, int y, GuiController c){
    this.id = id;
    this.x = x;
    this.y = y;
    konn = new Konnektor[4];
    daten = new KreisverkehrTyp2Einstellungen();
    daten.setId(id);
    daten.setName(daten.getName()+Integer.toString(id));
    property = new KreisverkehrAbschnittEinstellungen(daten,c);
    animation = new AbschnittAnimation();
    konn[0] = new Konnektor(this,x,y-16,0);
    konn[1] = new Konnektor(this,x+16,y,1);
    konn[2] = new Konnektor(this,x,y+16,2);
    konn[3] = new Konnektor(this,x-16,y,3);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
    kErgebnis = new KreuzungErgebnis();
}

  public KreisverkehrAbschnitt(KreisverkehrTyp2Einstellungen daten, GuiController c) {
    this.id = daten.getId();
    this.x = daten.getX();
    this.y = daten.getY();
    this.daten = daten;
    konn = new Konnektor[4];
    property = new KreisverkehrAbschnittEinstellungen(daten,c);
    animation = new AbschnittAnimation();
    konn[0] = new Konnektor(this,x,y-16,0);
    konn[1] = new Konnektor(this,x+16,y,1);
    konn[2] = new Konnektor(this,x,y+16,2);
    konn[3] = new Konnektor(this,x-16,y,3);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
    kErgebnis = new KreuzungErgebnis();
}
  
  public String getNamen(){
  	return daten.getName();
  }
  
  public void paintMe(Graphics g)  {
    g.setColor(Color.lightGray);
    g.fillOval(x-16,y-16,32,32);
    g.setColor(Color.green);
    g.fillOval(x-10,y-10,20,20);	
  	
  if (isBlockiert==true) {
    g.setColor(Color.red);
  }
  else {
    //g.setColor(Color.yellow);
  	g.setColor(Color.darkGray);
  }

  g.drawOval(x-16,y-16,32,32);
  g.drawOval(x-10,y-10,20,20);
//  g.fillOval(x-16,y-16,32,32);
  
  for(int i=0;i<4;i++){
  	konn[i].paintMe(g);
  }
  
  if(zeigeNamen){
  	g.setColor(Color.black);
    g.drawString(daten.getName(),x-26,y+26);
  }
  g.setColor(Color.yellow);
}
  
  public boolean istInPosition(int x1, int y1) {
    int dx, dy, radius;
    dx = x-x1;
    dy = y-y1;
    radius=16;

    if (dx<0) dx=dx*(-1);     // aus negativen werten positive machen
    if (dy<0) dy=dy*(-1);

    if ((dx < radius) && (dy < radius))
      return true;
    else
      return false;
  }

public void zeigeEinstellungen() {
	setAnbindungen();
	property.initialisieren(this);
	property.setTitle("Kreisverkehreinstellungen");
	property.setSize(500,380);
	property.setVisible(true);
}

private void setAnbindungen(){
	daten.setAnbindungen(sortiereAnbindungen());
	
}

  public String getName() {
    return daten.getName();
  }
  
  public EinstellungsDaten getEinstellungen() {
  	setAnbindungen();
	daten.setX(x);
	daten.setY(y);
	if(daten.getModus() == 0){	//Falls Automatisches Abbiegewahl gewollt
		daten.setAbbiegenWahl(getAutoAbbiegen());
	}
	return daten;
}
  

  public void zeigeAnimationsDetails() {
  	// TODO Auto-generated method stub
	animation.setTitle("Kreisverkehr Animation");
	animation.setSize(520,340);
	animation.setVisible(true);
  }

  public void setStatus(Status s){
	for(int i=0;i<s.getAnzahlWS();i++){
		StrassenAbschnitt abs = getStrasseById(s.getWsId()[i]);
		
		if(abs != null){
			abs.setWSBeschriftung(this,s.getWsLaenge()[i]);
		}
	}
	animation.setText(s.getInfoText());
}

    public void setPos(int x1, int y1) {
    	x=x1;
    	y=y1;
        konn[0].setPos(x,y-16);
        konn[1].setPos(x+16,y);
        konn[2].setPos(x,y+16);
        konn[3].setPos(x-16,y);
    }
  
	public Konnektor getKonnektor(int x, int y) {
		for(int i=0;i<4;i++){
			if(konn[i].istInPosition(x,y)){
				return konn[i];
			}
		}
		return null;
	}
	
	public void setErgebnis(Ergebnis e){
		this.e = e;
		if(e == null)
			System.err.println("Es wurde ein null Ergebnis gesetzt");
		
		if(kErgebnis != null && e != null){
			kErgebnis.setErgebnis(e);
		}
		else{
			System.err.println("Ergebnis�bersicht exisitiert nicht");
		}
	}
	
	public void setErgebnisModus(int modus){
		if(kErgebnis == null)
			return; 
//	 	aktuelle WS l�nge
//	 	durchs. WS l�nge
//	 	durchs. Wartezeit
//	 	proz. Stra�enauslastung
//	 	proz. Stau
//		Max WS L�nge
		
		for(int i=0;i<4;i++){
			StrassenAbschnitt abs = angebundeneStrassen[i];
			
			if(abs != null){
				if(modus == 0)
					abs.setWSBeschriftung(this,e.getAnzahlFahrzeuge()[i]);
				else if(modus == 1)
					abs.setWSBeschriftung(this,e.getDurchsWSlaenge()[i]);
				else if(modus == 2)
					abs.setWSBeschriftung(this,e.getDurchsWartezeit()[i]);
				else if(modus == 3)
					abs.setWSBeschriftung(this,e.getProzAuslastung()[i]);//
				else if(modus == 4)
					abs.setWSBeschriftung(this,e.getProzStau()[i]);//
				else if(modus == 5)
					abs.setWSBeschriftung(this,e.getMaxLaenge()[i]);//
			}
		}
		
//		for(int i=0;i<4;i++){
//			StrassenAbschnitt abs = angebundeneStrassen[i];
//			
//			if(abs != null){
//				if(modus == 0)
//					abs.setWSBeschriftung(this,e.getWS(i).getAnzahlFahrzeuge());
//				else if(modus == 1)
//					abs.setWSBeschriftung(this,e.getWS(i).getDurchsWartendeFahrzeuge());
//				else if(modus == 2)
//					abs.setWSBeschriftung(this,e.getWS(i).getDurchsVerweilzeitWS());
//				else if(modus == 3)
//					abs.setWSBeschriftung(this,e.getWS(i).getProzentualeStrassenauslastung());//
//				else if(modus == 4)
//					abs.setWSBeschriftung(this,e.getWS(i).getProzentualBlockiert());//
//				else if(modus == 5)
//					abs.setWSBeschriftung(this,e.getWS(i).getMaxAnzahlFahrzeuge());//
//			}
//		}
	}
	
	public void zeigeErgebnis() {
	  	// TODO Auto-generated method stub
		if(kErgebnis == null){
			return;
		}
		kErgebnis.initialsieren();
		kErgebnis.setTitle("Ergebnis");
		kErgebnis.setSize(720,510);
		kErgebnis.setVisible(true);
		kErgebnis.initialsieren();
	}

}
