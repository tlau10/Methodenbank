package gui;

import java.awt.*;

import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.QuelleEinstellungen;
import verkehrsplaner.Status;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class QuelleAbschnitt extends KreuzungGUI{
	private int maxStrassen=1;
	private QuelleAbschnittEinstellungen property;
	private QuelleEinstellungen daten;
	private int winkelAnkunft=0;
	private int winkelNeuesFahrzeug=0;

  public QuelleAbschnitt(int id, int x, int y, GuiController c) {
    this.id = id;
    this.x = x;
    this.y = y;
    super.maxStrassen=maxStrassen;
    konn = new Konnektor[maxStrassen];
    konn[0] = new Konnektor(this,x,y,0);
    daten = new QuelleEinstellungen();
    daten.setId(id);
    daten.setName(daten.getName()+Integer.toString(id));
    property = new QuelleAbschnittEinstellungen(daten,c);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
  }
  
  public QuelleAbschnitt(QuelleEinstellungen daten, GuiController c) {
    this.id = daten.getId();
    this.x = daten.getX();
    this.y = daten.getY();
    konn = new Konnektor[maxStrassen];
    konn[0] = new Konnektor(this,x,y,0);
    this.daten = daten;
    super.maxStrassen=maxStrassen;
    property = new QuelleAbschnittEinstellungen(daten,c);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
}
  
  public String getNamen(){
  	return daten.getName();
  }
  
	private void setAnbindungen(){
		int[] tmp = daten.getAnbindungen();
		if(angebundeneStrassen[0] != null){
			tmp[0] = ((StrassenAbschnitt)angebundeneStrassen[0]).getId();
		}
		daten.setAnbindungen(tmp);
	}

  public void paintMe(Graphics g) {

  	Color cAnkunft=Color.orange;
//  	Color cNeuesFahrzeug=Color.red;
  	
    if (isBlockiert == true) {
    	g.setColor(Color.red);
    }
    else {
        g.setColor(Color.white);

    }
    
    g.setColor(Color.white);
    g.fillRect(x-12,y-12,24,24);
    
    g.setColor(cAnkunft);
    g.fillArc(x-8,y-8,16,16,90,-winkelAnkunft);
    
//    g.setColor(cNeuesFahrzeug);
//    g.fillArc(x-4,y-4,8,8,90,-winkelNeuesFahrzeug);
    
    g.setColor(Color.lightGray);
    g.drawRoundRect(x-12,y-12,24,24,4,4);
    g.setColor(Color.gray);
    g.drawRoundRect(x-11,y-11,22,22,4,4);
    g.setColor(Color.lightGray);
    g.drawRoundRect(x-10,y-10,20,20,4,4);
    
//    g.fill3DRect(x-16,y-16,32,32,false);

    g.setColor(Color.black);
    Font f = g.getFont();
    Font meins = new Font(f.getFontName(),f.getStyle(),f.getSize()+7);
    g.setFont(meins);
    g.drawString("Q",x-6,y+6);
    
    g.setFont(f);
    
//    g.fillRect(x-4,y-16,8,32);
//    g.fillOval(x,y-5,9,9);
    //g.fillOval(x - 20, y - 20, 40, 40);
    if(zeigeNamen){
      g.drawString(daten.getName(), x - 20, y+24);
    }

  }
  
  public boolean istInPosition(int x1, int y1) {
  	if(x1>x-12 && x1<x+12 && y1>y-12 && y1<y+12){
  		return true;
  	}
  	return false;
  }

  public void zeigeEinstellungen() {
  	
    setAnbindungen();
    property.initialisieren(this);
    property.setSize(405,380);
    property.setTitle("Quelleneinstellungen");
    property.setVisible(true);

  }

  public String getName() {
    return daten.getName();
  }

  public EinstellungsDaten getEinstellungen() {
  	setAnbindungen();
	daten.setX(x);
	daten.setY(y);
	return daten;
}

  public void zeigeAnimationsDetails() {
  	// TODO Auto-generated method stub
  	
  }
  
  public void setStatus(Status s){
  	if(s.isAnkunft()){
  	  	winkelAnkunft += 10;
  	  	
  	  	if(winkelAnkunft > 360){
  	  		winkelAnkunft -= 360;
  	  	}
  	}
  	else if(s.isNeuesFahrzeug()){
  		winkelNeuesFahrzeug += 10;
  		
  	  	if(winkelNeuesFahrzeug > 360){
  	  	winkelNeuesFahrzeug -= 360;
  	  	}
  	}
  }
  
  public void setPos(int x1, int y1) {
    x=x1;
    y=y1;
    konn[0].setPos(x1,y1);
  }

	public Konnektor getKonnektor(int x, int y) {
		if(istInPosition(x,y)){
			return konn[0];
		}
		return null;
	}
	
	public void setErgebnis(Ergebnis e) {
		// TODO Auto-generated method stub
		
	}
	
	public void zeigeErgebnis() {
		// TODO Auto-generated method stub
		
	}

	public void setErgebnisModus(int modus) {
		// TODO Auto-generated method stub
		
	}

}
