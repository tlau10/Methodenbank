/*
 * Created on 15.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gui;
import java.awt.*;

import javax.swing.*;
/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AbschnittAnimation extends JDialog {
	private static final long serialVersionUID = -1201084914948997778L;
	JPanel panel1 = new JPanel();
	private JScrollPane jscroll = new JScrollPane();
	JPanel jPanel1 = new JPanel();
	JTextArea taInfo = new JTextArea();
	
	public AbschnittAnimation(Frame frame, String title, boolean modal) {
	  super(frame, title, modal);
	  try {
	    jbInit();
	    pack();
	  }
	  catch(Exception ex) {
	    ex.printStackTrace();
	  }
	}
	
	public AbschnittAnimation() {
	  this(null, "", false);
	}
	
	private void jbInit() throws Exception {
	  panel1.setLayout(null);
	  jPanel1.setLayout(null);
	  jPanel1.setBounds(new Rectangle(10, 10, 500, 320));
	  jscroll.setBounds(new Rectangle(0, 0, 480, 300));
//	  taInfo.setBounds(new Rectangle(0, 0, 480, 300));
	  jscroll.getViewport().add(taInfo, null);
	  jPanel1.add(jscroll,null);
	  
	  getContentPane().add(panel1);
	  panel1.add(jPanel1, null);
	}
	
	public void setText(String text){
		taInfo.setText(text);
	}
}
