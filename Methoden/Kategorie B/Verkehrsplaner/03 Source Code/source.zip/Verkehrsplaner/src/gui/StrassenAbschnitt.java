package gui;

import java.awt.*;

import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.NormaleStrasseEinstellungen;
import verkehrsplaner.Status;

/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class StrassenAbschnitt implements Abschnitt {

  private KreuzungGUI a,b;
  private int id,simX,simY;
  private double wsA,wsB;
//  private boolean isBlockiert=false;
  private boolean[] richtungBlockiert={false,false};
  private StrassenAbschnittEinstellungen einstellungen;
  private NormaleStrasseEinstellungen daten;
  private int kreuzungsCounter=0;
  private boolean zeigeNamen=false;
  private int kurveX=-1;
  private int kurveY=-1;
  private int strassenArt=0;
  private Konnektor konnA;
  private Konnektor konnB;
  private boolean oKonnektor=false;

  public StrassenAbschnitt(int id, Konnektor konn, GuiController controller, int strassenArt) {
  	this.konnA = konn;
    this.id = id;
    this.a = konn.getKreuzung();
    b = null;
    wsA = 0;
    wsB = 0;
    simX = a.getX();
    simY = a.getY();
    daten = new NormaleStrasseEinstellungen();
    daten.setId(id);
    daten.setName(daten.getName()+Integer.toString(id));
    this.strassenArt = strassenArt;
    if(strassenArt == 0){
    	daten.setFahrzeugeProMinute(3.0);
    }
    else if(strassenArt == 1){
    	daten.setFahrzeugeProMinute(10.0);
    }
    else{
    	daten.setFahrzeugeProMinute(20.0);
    }
    
    einstellungen = new StrassenAbschnittEinstellungen(daten, controller);
}

  
  public StrassenAbschnitt(NormaleStrasseEinstellungen daten, GuiController c){
  	this.id = daten.getId();
    this.daten = daten;
    kurveX = daten.getKurveX();
    kurveY = daten.getKurveY();
    strassenArt = daten.getStrassenArt();
    einstellungen = new StrassenAbschnittEinstellungen(daten, c);
  }
  
  public String getNamen(){
  	return daten.getName();
  }

	private void setAnbindungen(){
		int[] ergebnis = new int[2];
		ergebnis[0] = a.getId();
		ergebnis[1] = b.getId();
		daten.setAnbindungen(ergebnis);
	}

	public double getFahrzeugeProMinute(KreuzungGUI k){
		return daten.getFahrzeugeProMinute();
	}
	
    public KreuzungGUI getA() {
      return a;
    }

    public KreuzungGUI getB() {
      return b;
    }

    public String getType() {
      return "strasse";
    }
    
    public String getName(){
    	return daten.getName();
    }

    public void setWSBeschriftung(KreuzungGUI k, double wsLaenge){
    	if(k == a){
    		wsA = wsLaenge;
    	}
    	else if(k == b){
    		wsB = wsLaenge;
    	}
    }

    public void setDestKnoten(Konnektor konn) {
    	this.konnB = konn;
    	this.b=konn.getKreuzung();
    }

//    public void setBlockiert(boolean m) {
//    	isBlockiert = m;
//    }

    public void paintMe(Graphics g)  {
    	



      if (richtungBlockiert[0]==true || richtungBlockiert[1]==true) {
        g.setColor(new Color(255,50,50));
      }
      else {
        if(strassenArt > 1){
        	g.setColor(Color.ORANGE);
        }
        else{
        	 g.setColor(new Color(100,100,255));
        }
      }

      Graphics2D g2 = (Graphics2D) g;
      g2.setStroke( new BasicStroke( strassenArt+1 ) );

      int aX;
      int aY;
      
      if(konnA != null){
      	aX = konnA.getX();
		aY = konnA.getY();
      }
      else{
      	aX = a.getX();
      	aY = a.getY();
      }
      
      if (b==null) {
        // zeichnen beim drag'n drop
      	if(oKonnektor)
      		g2.setColor(Color.RED);
        g2.drawLine(aX,aY,simX,simY);
      }
      else {
        // Normal zeichnen
    	  

        int bX;
        int bY;
        
        if(konnB != null){
        	bX = konnB.getX();
        	bY = konnB.getY();
        }
        else{
        	bX = b.getX();
        	bY = b.getY();
        }

      	
      	if(kurveX > -1 && kurveY > -1){
      		g2.drawLine(aX,aY,kurveX,kurveY);
      		g2.drawLine(kurveX,kurveY,bX,bY);
      		g2.drawRect(kurveX-2,kurveY-2,4,4);
      	}
      	else{
      		g2.drawLine(aX,aY,bX,bY);
      	}
        
      	g2.setStroke( new BasicStroke( 1 ) );
      	
      	g.setColor(Color.BLACK);
      	
      	int wsX;
    	int wsY;			//TODO Problem beim Fenster gr��e ver�ndern -> kurven anpassen
    	
    	//Entfernung in Pixel vom WS-Anzeige zur Kreuzung
    	double entfernung=27.0;
    	
    	//Einfahrt Verboten-Schild abstand
    	double einfahrtVerboten=14.0;
    	
    	
    	//Einbahnstra�e anzeigen
    	if(daten.getFahrspuren()[0] <= 0){
        	if(kurveX > -1 && kurveY > -1){
    			//a^2+b^2=c^2  // c/entfernung = divisor
    			double divisor = Math.sqrt(Math.pow(Math.abs(kurveX-aX),2)+Math.pow(Math.abs(kurveY-aY),2));
    			divisor = divisor / einfahrtVerboten;
    			wsX = (int) (aX + (kurveX - aX)/divisor);
    			wsY = (int) (aY + (kurveY - aY)/divisor);
    		}
    		else{
    			double divisor = Math.sqrt(Math.pow(Math.abs(bX-aX),2)+Math.pow(Math.abs(bY-aY),2));
    			divisor = divisor / einfahrtVerboten;
    			wsX = (int) (aX + (bX - aX)/divisor);
    			wsY = (int) (aY + (bY - aY)/divisor);
    		}

//        	g.setColor(Color.RED);
//        	g.fillOval(wsX-4, wsY-4, 9, 9); //Klein
//        	g.setColor(Color.white);
//        	g.fillRect(wsX-2, wsY, 6, 2);
        	
//        	g.setColor(Color.RED);
//        	g.fillOval(wsX-5, wsY-5, 10,10); //Mittel
//        	g.setColor(Color.white);
//        	g.fillRect(wsX-3, wsY-1, 7, 3);
        	
//			g.setColor(Color.RED);        	
//        	g.fillOval(wsX-5, wsY-5, 11, 11);	//ALT
//        	g.setColor(Color.white);
//        	g.fillRect(wsX-3, wsY, 8, 2);
        	
			g.setColor(Color.RED);        	
			g.fillRect(wsX-5, wsY-1, 10, 2);
			g.fillRect(wsX-1, wsY-5, 2, 10);
			g.fillRect(wsX-4, wsY-3, 8, 6);
			g.fillRect(wsX-3, wsY-4, 6, 8);
        	g.setColor(Color.white);
        	g.fillRect(wsX-3, wsY-1, 6, 2);
        	
    	}
    	if(daten.getFahrspuren()[1] <= 0){
        	if(kurveX > -1 && kurveY > -1){
        		double divisor = Math.sqrt(Math.pow(Math.abs(bX-kurveX),2)+Math.pow(Math.abs(bY-kurveY),2));
        		divisor = divisor / einfahrtVerboten;
            	wsX = (int) (bX + (kurveX - bX)/divisor);
            	wsY = (int) (bY + (kurveY - bY)/divisor);
        	}
        	else{
        		double divisor = Math.sqrt(Math.pow(Math.abs(bX-aX),2)+Math.pow(Math.abs(bY-aY),2));
        		divisor = divisor / einfahrtVerboten;
            	wsX = (int) (bX + (aX - bX)/divisor);
            	wsY = (int) (bY + (aY - bY)/divisor);
        	}

			g.setColor(Color.RED);        	
			g.fillRect(wsX-5, wsY-1, 10, 2);
			g.fillRect(wsX-1, wsY-5, 2, 10);
			g.fillRect(wsX-4, wsY-3, 8, 6);
			g.fillRect(wsX-3, wsY-4, 6, 8);
        	g.setColor(Color.white);
        	g.fillRect(wsX-3, wsY-1, 6, 2);
    	}
    	
    	
    	
    	//WS w�hrend der Animation anzeigen
    	g.setColor(Color.black);
    	
        if(wsA>0){	
        	
        	if(kurveX > -1 && kurveY > -1){
    			//a^2+b^2=c^2  // c/entfernung = divisor
    			double divisor = Math.sqrt(Math.pow(Math.abs(kurveX-aX),2)+Math.pow(Math.abs(kurveY-aY),2));
    			divisor = divisor / entfernung;
    			wsX = (int) (aX + (kurveX - aX)/divisor);
    			wsY = (int) (aY + (kurveY - aY)/divisor);
    		}
    		else{
    			double divisor = Math.sqrt(Math.pow(Math.abs(bX-aX),2)+Math.pow(Math.abs(bY-aY),2));
    			divisor = divisor / entfernung;
    			wsX = (int) (aX + (bX - aX)/divisor);
    			wsY = (int) (aY + (bY - aY)/divisor);
    		}
        	
        	//Blockaderichtung zeigen
        	if (richtungBlockiert[1]){
        		g.setColor(Color.red);
        		g.drawOval(wsX-8, wsY-8, 24, 14);
        		g.setColor(Color.BLACK);
        	}
        	
        	if(wsA == Math.ceil(wsA))
        		g.drawString(Integer.toString((int)wsA),wsX-4,wsY+4);
        	else
        		g.drawString(Double.toString(wsA),wsX-4,wsY+4);
        }
        
        if(wsB>0){
        	if(kurveX > -1 && kurveY > -1){
        		double divisor = Math.sqrt(Math.pow(Math.abs(bX-kurveX),2)+Math.pow(Math.abs(bY-kurveY),2));
        		divisor = divisor / entfernung;
            	wsX = (int) (bX + (kurveX - bX)/divisor);
            	wsY = (int) (bY + (kurveY - bY)/divisor);
        	}
        	else{
        		double divisor = Math.sqrt(Math.pow(Math.abs(bX-aX),2)+Math.pow(Math.abs(bY-aY),2));
        		divisor = divisor / entfernung;
            	wsX = (int) (bX + (aX - bX)/divisor);
            	wsY = (int) (bY + (aY - bY)/divisor);
        	}

        	//Blockaderichtung zeigen
        	if (richtungBlockiert[0] == true){
        		g.setColor(Color.red);
        		g.drawOval(wsX-8, wsY-8, 24, 14);
        		g.setColor(Color.BLACK);
        	}	

        	if(wsB == Math.ceil(wsB))
        		g.drawString(Integer.toString((int)wsB),wsX-4,wsY+4);
        	else
        		g.drawString(Double.toString(wsB),wsX-4,wsY+4);
        }

        //Namen anzeigen
        if(zeigeNamen){
            g.setColor(Color.black);

            if(kurveX > -1 && kurveY > -1){
            	g.drawString(daten.getName(), kurveX - 20, kurveY);
            }
            else{
            	int xMitte = (aX + bX)/2;
                int yMitte = (aY + bY)/2;
            	g.drawString(daten.getName(), xMitte - 20, yMitte);
            }
        }
      }
    }
    
    public void setPos(int x, int y){
    	kurveX = x;
    	kurveY = y;
    }


    public boolean istInPosition(int x1, int y1) {
      //�berpr�fen ob der Klick sich �berhaupt in der N�he der Strasse befand
      int aX = konnA.getX();
      int aY = konnA.getY();
      int bX = konnB.getX();
      int bY = konnB.getY();
      
      if(!(kurveX > -1 && kurveY > -1)){
      	return istAufStrasse(x1,y1,aX,aY,bX,bY);
      }
      else{
      	if(istAufStrasse(x1,y1,aX,aY,kurveX,kurveY)){
      		return true;
      	}
      	else if(istAufStrasse(x1,y1,kurveX,kurveY,bX,bY)){
      		return true;
      	}
      	else{
      		return false;
      	}
      }
    }
    
    private boolean istAufStrasse(int x1, int y1, int aX, int aY, int bX, int bY){
        double c,m,y,diff;
        
        if (aX < bX) {
            if ((x1<aX-5) || (x1>bX+5)) 
            	return false;
          }
          else {
            if ((x1>aX+5) || (x1<bX-5)) 
            	return false;
          }

          if (aY < bY) {
            if ((y1<aY-5) || (y1>bY+5)) 
            	return false;
          }
          else {
            if ((y1>aY+5) || (y1<bY-5)) 
            	return false;
          }
          

          //�berpr�fen ob die Strasse wirklich angeklickt wurde
          //Problem: m kann unendlich werden bzw sehr gro� (�ber 5 schon probleme)-> Funktioniert nicht mehr
          m=((double)(aY-bY))/((double)(aX-bX));

          c=(-1.0)*(m*aX)+aY;

          y=(double)((m*x1)+c);
          
          diff=Math.abs(y-y1);


          if (diff <=7.0) {//Falls die Abweichung gering genug
            return true;
          }
          else if(Math.abs(m) > 1.0 && diff <= 7.0*Math.abs(m)){
          	return true;
          }
          else if(Math.abs(m) > 10){
          	return true;
          }
          return false;
    }

    public void setSimPos(int x, int y) {
    	simX = x;
    	simY = y;
    }

    public void zeigeEinstellungen() {
      setAnbindungen();
      einstellungen.initialisieren(this);
      einstellungen.setSize(410,380);
      einstellungen.setTitle("Stra�eneinstellungen");
      einstellungen.setVisible(true);
    }
    
    public KreuzungGUI getAndereKreuzung(KreuzungGUI aktuelle){
    	if(aktuelle == a && a != b){
    		return b;
    	}
    	else if (aktuelle == b && a!=b){
    		return a;
    	}
    	else if(a==b){
    		System.err.println("Fehler Stra�e ID: "+id+" wurde nicht richtig implementiert");
    		return null;
    	}
    	else{
    		System.err.println("Fehler unbekannt Kreuzung "+a.getName()+" ID:"+a.getId());
    		return null;
    	}
    }
    
    //Funktion um Einbahnstrassen in der Automatik ermitteln
    public int getAnzahlSpurenVonKreuzungWeg(KreuzungGUI k){
    	if(k == a)
    		return daten.getFahrspuren()[0];
    	else if(k == b)
    		return daten.getFahrspuren()[1];
    	
    	return 0;
    }


  public int getId() {
    return id;
  }
  
  public EinstellungsDaten getEinstellungen() {
  	daten.setKurveX(kurveX);
  	daten.setKurveY(kurveY);
  	daten.setStrassenArt(strassenArt);
  	
  	int[] konn = new int[2];
  	konn[0] = konnA.getNummer();
  	konn[1] = konnB.getNummer();
  	daten.setKonnektoren(konn);
  	
  	setAnbindungen();
	return daten;
}

	public void addAbschnitt(Abschnitt ab, int richtung) {
		if(kreuzungsCounter == 0){
			this.a = (KreuzungGUI) ab;
			konnA = ((KreuzungGUI)ab).verbindeKonnektor(daten.getKonnektoren()[0],this);
		}
		else if(kreuzungsCounter == 1){
			this.b = (KreuzungGUI) ab;
			konnB = ((KreuzungGUI)ab).verbindeKonnektor(daten.getKonnektoren()[1],this);
		}
		kreuzungsCounter++;
	}
	
	public int getMaxAnbindungen() {
		return 2;
	}
	
	public void zeigeNamen(boolean b){
	   	zeigeNamen = b;
	   }
	
	public void setStatus(Status s) {
//		isBlockiert = false;
		
//		richtungBlockiert[0] = false;
//		richtungBlockiert[1] = false;
//		
//		if(s.isBlockiert()[0]){
//			richtungBlockiert[0] = true;
//		}
//		if(s.isBlockiert()[1]){
//			richtungBlockiert[1] = true;
//		}
		
		richtungBlockiert = s.isBlockiert();
		
//		for(int i=0;i<2;i++){
//			if(richtungBlockiert[i]){
//				isBlockiert = true;
//			}
//		}
	}
	
	public void zeigeAnimationsDetails() {
		// TODO Auto-generated method stub
		
	}
	
	public int getX(){
		return kurveX;
	}
	
	public int getY(){
		return kurveY;
	}

	public int getWinkelX(KreuzungGUI k){
		if(kurveX > -1)
			return kurveX;
		return getAndereKreuzung(k).getX();
	}
	
	public int getWinkelY(KreuzungGUI k){
		if(kurveY > -1)
			return kurveY;
		return getAndereKreuzung(k).getY();
	}
	
	public int getKonnektorA(){
		if(konnA != null){
			return konnA.getNummer();
		}
		else{
			return daten.getKonnektoren()[0];
		}
	}
	
	public int getKonnektorB(){
		if(konnB != null){
			return konnB.getNummer();
		}
		else{
			return daten.getKonnektoren()[1];
		}
	}
	
	public void overKonnektor(boolean oKonnektor){
		this.oKonnektor = oKonnektor;
	}

	public void setErgebnis(Ergebnis e) {
		// TODO Auto-generated method stub
		
	}

	public void zeigeErgebnis() {
		// TODO Auto-generated method stub
		
	}

	public void setErgebnisModus(int modus) {
		// TODO Auto-generated method stub
		
	}

}
