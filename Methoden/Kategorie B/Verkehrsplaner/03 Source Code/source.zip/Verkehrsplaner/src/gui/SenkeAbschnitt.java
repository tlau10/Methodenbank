package gui;

import java.awt.*;

import verkehrsplaner.EinstellungsDaten;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.SenkeEinstellungen;
import verkehrsplaner.Status;
/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class SenkeAbschnitt extends KreuzungGUI {
	private int maxStrassen=1;
	private SenkeAbschnittEinstellungen property;
	private SenkeEinstellungen daten;
//	private GuiController c;
	private int winkel=0;

	
  public SenkeAbschnitt(int id, int x, int y, GuiController c) {
    this.id = id;
    this.x = x;
    this.y = y;
    super.maxStrassen=maxStrassen;
    konn = new Konnektor[maxStrassen];
    konn[0] = new Konnektor(this,x,y,0);
    daten = new SenkeEinstellungen();
    daten.setId(id);
    daten.setName(daten.getName()+Integer.toString(id));
    property = new SenkeAbschnittEinstellungen(daten,c);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
//    this.c = c;

  }

  public SenkeAbschnitt(SenkeEinstellungen daten, GuiController c) {
    this.id = daten.getId();
    this.x = daten.getX();
    this.y = daten.getY();
    konn = new Konnektor[maxStrassen];
    konn[0] = new Konnektor(this,x,y,0);
    this.daten = daten;
    super.maxStrassen=maxStrassen;
    property = new SenkeAbschnittEinstellungen(daten,c);
    angebundeneStrassen = new StrassenAbschnitt[maxStrassen];
}
  
  public String getNamen(){
  	return daten.getName();
  }
  
  public void paintMe(Graphics g) {
//		g.drawImage(new ImageIcon("D:\\senke.png").getImage(),x-16,y-16,c);
  	Color c;
  	
    if (isBlockiert == true) {
    	c=Color.RED;
    }
    else {
        //g.setColor(Color.white);
    	//c=new Color(255,255,farbe);
    	c=Color.orange;
    }
    
    g.setColor(Color.white);
    g.fillRect(x-12,y-12,24,24);
    
    g.setColor(c);
    //fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) 
    g.fillArc(x-8,y-8,16,16,90,-winkel);
    
    g.setColor(Color.lightGray);
    g.drawRoundRect(x-12,y-12,24,24,4,4);
    g.setColor(Color.gray);
    g.drawRoundRect(x-11,y-11,22,22,4,4);
    g.setColor(Color.lightGray);
    g.drawRoundRect(x-10,y-10,20,20,4,4);

    g.setColor(Color.black);
    Font f = g.getFont();
    Font meins = new Font(f.getFontName(),f.getStyle(),f.getSize()+7);
    g.setFont(meins);
    g.drawString("S",x-5,y+7);
    
    g.setFont(f);
//    
//    int xM=x-4;
//    int yM=y-16;
    
//    int[] xPoly = {xM+0,xM+7,xM+7, xM+5, xM+4, xM+5, xM+7, xM+7, xM+0}; 
//    int[] yPoly = {yM+0,yM+0,yM+11,yM+12,yM+15,yM+19,yM+19,yM+31,yM+31};
//    
//  	g.fillPolygon(xPoly,yPoly,9);
    
//    g.fillRect(x-4,y-16,4,32);
//    
//    g.fillRect(x,y-16,2,14);
//    g.fillRect(x,y+2 ,2,14);
//    
//    g.fillRect(x+2,y-16,2,12);
//    g.fillRect(x+2,y+4,2,12);
  	
    if(zeigeNamen){
        g.setColor(Color.black);
        g.drawString(daten.getName(), x - 20, y+24);
    }

  }
  
  public boolean istInPosition(int x1, int y1) {
  	if(x1>x-12 && x1<x+12 && y1>y-12 && y1<y+12){
  		return true;
  	}
  	return false;
  }

  public void zeigeEinstellungen() {
    setAnbindungen();
    property.initialisieren(this);
    property.setSize(400,330);
    property.setTitle("Senkeneinstelllungen");
    property.setVisible(true);
  }
  
	private void setAnbindungen(){
		int[] tmp = daten.getAnbindungen();
		if(angebundeneStrassen[0] != null){
			tmp[0] = ((StrassenAbschnitt)angebundeneStrassen[0]).getId();
		}
		daten.setAnbindungen(tmp);
	}

  public String getName() {
    return daten.getName();
  }
  
  public EinstellungsDaten getEinstellungen() {
  	setAnbindungen();
	daten.setX(x);
	daten.setY(y);
	return daten;
}
  
  public void setStatus(Status s){
  	winkel += 10;
  	
  	if(winkel > 360){
  		winkel -= 360;
  	}
}

  public void zeigeAnimationsDetails() {
  	// TODO Auto-generated method stub
  	
  }
  
    public void setPos(int x1, int y1) {
    	x=x1;
    	y=y1;
    	konn[0].setPos(x1,y1);
    }

	public Konnektor getKonnektor(int x, int y) {
		if(istInPosition(x,y)){
			return konn[0];
		}
		return null;
	}

	public void setErgebnis(Ergebnis e) {
		// TODO Auto-generated method stub
		
	}

	public void zeigeErgebnis() {
		// TODO Auto-generated method stub
		
	}

	public void setErgebnisModus(int modus) {
		// TODO Auto-generated method stub
		
	}

}
