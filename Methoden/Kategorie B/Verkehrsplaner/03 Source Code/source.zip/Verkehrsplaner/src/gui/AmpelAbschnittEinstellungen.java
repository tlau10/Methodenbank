package gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import verkehrsplaner.AmpelEinstellungen;
import verkehrsplaner.AmpelEinstellungenMitAbbiegespur;



/**
 * <p>�berschrift: </p>
 * <p>Beschreibung: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Organisation: </p>
 * @author Christian Gruhler
 * @version 1.0
 */

public class AmpelAbschnittEinstellungen extends JDialog {
	private static final long serialVersionUID = -5314238790945306554L;
	private JPanel panel1 = new JPanel();
	private JPanel jPanel1 = new JPanel();
	private FlowLayout flowLayout1 = new FlowLayout();
	private JButton btOK = new JButton();
	private JButton btAbbrechen = new JButton();
	private JPanel jPanel2 = new JPanel();
	private GridLayout gridLayout1 = new GridLayout(3, 2);
	private JLabel jLabel1 = new JLabel();
	private JTextField tfName = new JTextField();
	private JLabel jLabel2 = new JLabel();
	private JTextField tfBreite = new JTextField();
	private JComboBox cbModus = new JComboBox();
	private JLabel labelModus = new JLabel();

	private JTable tVerteilungAbbieger;
	private JTable tAmpelphasen;
	private JTable tLaengeAbbiegerSpur;

	private JLabel jLabel20 = new JLabel();
	private JLabel jLabel21 = new JLabel();
	private JLabel jLabel22 = new JLabel();
	private JLabel jLabel23 = new JLabel();
	private JLabel jLabel24 = new JLabel();
	private JLabel jLabel25 = new JLabel();
	private JLabel jLabel26 = new JLabel();
	private JPanel jPanel3 = new JPanel();

	private JLabel jLabel3 = new JLabel();
	private JLabel jLabel4 = new JLabel();
	private JLabel jLabel5 = new JLabel();
	private JLabel jLabel6 = new JLabel();
  	private JLabel jLabel7 = new JLabel();
  	private JLabel jLabel8 = new JLabel();
  	private JLabel jLabel9 = new JLabel();
  
  	private JLabel labelOffset = new JLabel();
  	private JTextField tfOffset = new JTextField();
  	private JLabel labelFussgaenger = new JLabel();
  	private JTextField tfFussgaenger = new JTextField();

  	private AmpelEinstellungen daten;
  	private GuiController controller;
  	private int modus;
  	private String[][] manuellVerteilungAbbieger = new String[4][3];
  	private String[] manuellAmpelphasen = new String[4];
  	private KreuzungGUI kreuzung;

  public AmpelAbschnittEinstellungen(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public AmpelAbschnittEinstellungen() {
    this(null, "", false);
  }

  public AmpelAbschnittEinstellungen(AmpelEinstellungen daten, GuiController controller) {
  this(null, "", false);
  this.daten = daten;
  this.controller = controller;
  
	if (daten.getType().equals("AmpelTyp2Einstellungen")){
  	    jLabel5.setText("0 - Nord / Sued Gr�n f�r Geradeaus und Rechtsabbieger");
  	    jLabel6.setText("1 - Nord / Sued Gr�n f�r Linksabbieger");
  	    jLabel7.setText("2 - Ost/ West Gr�n f�r Geradeaus und Rechtsabbieger");
  	    jLabel8.setText("3 - Ost/ West Gr�n f�r Linksabbieger");
  	}
	
	if (daten.getType().equals("AmpelKleinEinstellungen")){
		tLaengeAbbiegerSpur.setVisible(false);
		jLabel3.setVisible(false);
  	}
}
  
  public void initialisieren(KreuzungGUI kreuzung){
  	this.kreuzung = kreuzung;
  	int[] strassen = daten.getAnbindungen();
  	
    jLabel20.setText("N "+kreuzung.getStrassenNameById(strassen[0]));
    jLabel21.setText("O "+kreuzung.getStrassenNameById(strassen[1]));
    jLabel22.setText("S "+kreuzung.getStrassenNameById(strassen[2]));
    jLabel23.setText("W "+kreuzung.getStrassenNameById(strassen[3]));
    
    tfBreite.setText(Double.toString(daten.getBreite()));
    tfName.setText(daten.getName());
    tfOffset.setText(Double.toString(daten.getOffset()));
    tfFussgaenger.setText(Double.toString(daten.getLaengeFussgaengerPhase()));
  	for(int i=0;i<4;i++){
  		for(int j=0;j<3;j++){
  			tVerteilungAbbieger.setValueAt(Double.toString(daten.getAbbiegenWahl()[i][j]),j,i);
  			manuellVerteilungAbbieger[i][j] = Double.toString(daten.getAbbiegenWahl()[i][j]);
  		}
  		tAmpelphasen.setValueAt(Double.toString(daten.getAmpelSchaltZeiten()[i]),0,i);
  		manuellAmpelphasen[i] = Double.toString(daten.getAmpelSchaltZeiten()[i]);
  		
  		if(!daten.getType().equals("AmpelKleinEinstellungen")){
  			AmpelEinstellungenMitAbbiegespur tmp = (AmpelEinstellungenMitAbbiegespur) daten;
  			tLaengeAbbiegerSpur.setValueAt(Double.toString(tmp.getLaengeAbbiegeSpur()[i]),0,i);
  		}
  	}
  	modus = -1;
  	cbModus.setSelectedIndex(daten.getModus());
  	setModus_actionPerformed(cbModus);
  }


  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jPanel1.setLayout(flowLayout1);
    jPanel1.setBounds(new Rectangle(1, 380, 504, 40));
    jPanel2.setBounds(new Rectangle(10, 9, 459, 76));
    jPanel2.setLayout(gridLayout1);
    jLabel1.setText("Kreuzungsname:");
    jLabel2.setText("Kreuzungsbreite in m:");
    tfBreite.setText("9");
    tfName.setText("");
    jPanel3.setBounds(new Rectangle( 0, 90, 490, 285));
    jPanel3.setLayout(null);

    jLabel20.setText("NORD");
    jLabel20.setBounds(new Rectangle(125, 0, 85, 17));
    jLabel21.setText("OST");
    jLabel21.setBounds(new Rectangle(212, 0, 85, 17));
    jLabel22.setText("S�D");
    jLabel22.setBounds(new Rectangle(300, 0, 85, 17));
    jLabel23.setText("WEST");
    jLabel23.setBounds(new Rectangle(387, 0, 85, 17));
    jLabel24.setText("Rechtsabbieger");
    jLabel24.setBounds(new Rectangle(34, 51, 91, 17));
    jLabel25.setText("Geradeausfahrer");
    jLabel25.setBounds(new Rectangle(30, 70, 95, 17));
    jLabel26.setText("Linksabbieger");
    jLabel26.setBounds(new Rectangle(45, 87, 80, 23));

    String verteilungAbbiegendata[][] = {
        {
        "33", "33", "33", "33"}
        , {
        "33", "33", "33", "33"}
        , {
        "33", "33", "33", "33"}
    };
    String columnNames[] = {
        "NORD", "Ost", "Sued", "West"};
    String ampelPhasenData[][] = { {"16","5","16","5" } };
    String linksabbiegerSpur[][] = { {"20","20","20","20" } };
    tVerteilungAbbieger = new JTable(verteilungAbbiegendata, columnNames);
    tAmpelphasen = new JTable(ampelPhasenData,columnNames);
    tLaengeAbbiegerSpur = new JTable(linksabbiegerSpur,columnNames);

    tVerteilungAbbieger.setMaximumSize(new Dimension(5, 5));
    tVerteilungAbbieger.setMinimumSize(new Dimension(4, 4));
    tVerteilungAbbieger.setRowHeight(20);
    tVerteilungAbbieger.setBounds(new Rectangle(125, 50, 350, 60));
    tAmpelphasen.setRowHeight(20);
    tAmpelphasen.setBounds(new Rectangle(125, 205, 350, 20));
    tLaengeAbbiegerSpur.setRowHeight(20);
    tLaengeAbbiegerSpur.setBounds(new Rectangle(125, 20, 350, 20));
    
    btOK.setText("OK");
    btOK.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btOK_actionPerformed(e);
          }
        });
    btAbbrechen.setText("Abbrechen");
    btAbbrechen.addActionListener(new ActionListener()  {
        public void actionPerformed(ActionEvent e) {
        	btAbbrechen_actionPerformed(e);
          }
        });
    jLabel3.setText("L�nge Linksabbiegerspur");
    jLabel3.setBounds(new Rectangle(0, 23, 130, 15));
    jLabel4.setText("Ampelphasen:");
    jLabel4.setBounds(new Rectangle(125, 125, 300, 15));
    jLabel5.setText("0 - Nord Gr�n");
    jLabel5.setBounds(new Rectangle(125, 140, 300, 15));
    jLabel6.setText("1 - Ost Gr�n");
    jLabel6.setBounds(new Rectangle(125, 155, 300, 15));
    jLabel7.setText("2 - S�d Gr�n");
    jLabel7.setBounds(new Rectangle(125, 170, 300, 15));
    jLabel8.setText("3 - West Gr�n");
    jLabel8.setBounds(new Rectangle(125, 185, 300, 15));
    jLabel9.setText("Schaltzeiten:");
    jLabel9.setBounds(new Rectangle(45, 207, 65, 15));
    labelOffset.setText("Phasen Offset:");
    labelOffset.setBounds(new Rectangle(115, 232, 80, 15));
    tfOffset.setBounds(new Rectangle(200, 230, 275, 20));
    tfOffset.setText("0.0");
    labelFussgaenger.setText("L�nge der Fu�g�ngerphase:");
    labelFussgaenger.setBounds(new Rectangle(50, 252, 155, 15));
    tfFussgaenger.setBounds(new Rectangle(200, 250, 275, 20));
    tfFussgaenger.setText("0.0");
    labelModus.setText("Abbiegewahrscheinlichkeiten: ");
    cbModus.addItem("Automatik Modus");
    cbModus.addItem("Manueller Modus");
    cbModus.addItemListener( new ItemListener() {
        public void itemStateChanged( ItemEvent e ) {
          setModus_actionPerformed((JComboBox)e.getSource());
        }
      });
    getContentPane().add(panel1);
    jPanel1.add(btOK, null);
    jPanel1.add(btAbbrechen, null);
    panel1.add(jPanel3, null);
    panel1.add(jPanel2, null);
    jPanel2.add(labelModus,null);
    jPanel2.add(cbModus,null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(tfName, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(tfBreite, null);
    jPanel3.add(tVerteilungAbbieger, null);
    jPanel3.add(tAmpelphasen,null);
    jPanel3.add(jLabel20, null);
    jPanel3.add(jLabel21, null);
    jPanel3.add(jLabel22, null);
    jPanel3.add(jLabel23, null);
    jPanel3.add(jLabel3, null);
    jPanel3.add(jLabel4, null);
    jPanel3.add(jLabel5, null);
    jPanel3.add(jLabel6, null);
    jPanel3.add(jLabel7, null);
    jPanel3.add(jLabel8, null);
    jPanel3.add(jLabel9, null);
    jPanel3.add(jLabel24, null);
    jPanel3.add(jLabel25, null);
    jPanel3.add(jLabel26, null);
    jPanel3.add(tAmpelphasen,null);
    jPanel3.add(tLaengeAbbiegerSpur,null);
    jPanel3.add(labelOffset,null);
    jPanel3.add(tfOffset,null);
    jPanel3.add(labelFussgaenger,null);
    jPanel3.add(tfFussgaenger,null);
    panel1.add(jPanel1, null);

  }

  void btOK_actionPerformed(ActionEvent e) {
	double[][] abbiegenWahl = daten.getAbbiegenWahl();
	double[] ampelSchaltZeit = daten.getAmpelSchaltZeiten();
	double[] laengeAbbiegeSpur = new double[4];
	

	for(int i=0;i<4;i++){
		for(int j=0;j<3;j++){
			abbiegenWahl[i][j] = Double.parseDouble(tVerteilungAbbieger.getValueAt(j,i).toString());
		}
	}
	
	for(int i=0;i<4;i++){
		ampelSchaltZeit[i] = Double.parseDouble(tAmpelphasen.getValueAt(0,i).toString());
		laengeAbbiegeSpur[i] = Double.parseDouble(tLaengeAbbiegerSpur.getValueAt(0,i).toString());
	}
  	
	daten.setAbbiegenWahl(abbiegenWahl);
	daten.setAmpelSchaltZeiten(ampelSchaltZeit);
	
	if(!daten.getType().equals("AmpelKleinEinstellungen")){
			AmpelEinstellungenMitAbbiegespur tmp = (AmpelEinstellungenMitAbbiegespur) daten;
			tmp.setLaengeAbbiegeSpur(laengeAbbiegeSpur);
	}
	
	daten.setBreite(Double.parseDouble(tfBreite.getText()));
	daten.setName(tfName.getText());
	daten.setOffset(Double.parseDouble(tfOffset.getText()));
	daten.setModus(cbModus.getSelectedIndex());
	daten.setLaengeFussgaengerPhase(Double.parseDouble(tfFussgaenger.getText()));
	controller.repaint();
    this.setVisible(false);
  }

  void btAbbrechen_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }
  
  void btUebernehmen_actionPerformed(ActionEvent e) {
  	//TODO
  }
  
  void setModus_actionPerformed(JComboBox selectedChoice){
  	if(selectedChoice.getSelectedIndex() == modus){
  		return;
  	}
  	
    if ( selectedChoice.getSelectedIndex() == 0){
      	//System.out.println("Modus: Auto");
      	//tAmpelphasen.setEnabled(false);	
      	tVerteilungAbbieger.setEnabled(false);
      	//tAmpelphasen.setBackground(Color.LIGHT_GRAY); //TODO
      	tVerteilungAbbieger.setBackground(Color.LIGHT_GRAY);
      	for(int i=0;i<4;i++){
      		for(int j=0;j<3;j++){
      			manuellVerteilungAbbieger[i][j] = tVerteilungAbbieger.getValueAt(j,i).toString();
      		}
      		manuellAmpelphasen[i] = tAmpelphasen.getValueAt(0,i).toString();
      	}
      	modus = 0;
      	double[][] autoAbbiegen = kreuzung.getAutoAbbiegen();
      	for(int i=0;i<4;i++){
      		for(int j=0;j<3;j++){
      			tVerteilungAbbieger.setValueAt(Double.toString(autoAbbiegen[i][j]),j,i);
      		}
      	}
      }
      else if(selectedChoice.getSelectedIndex() == 1){
    	//System.out.println("Modus: Manuell");
      	tAmpelphasen.setEnabled(true);
      	tVerteilungAbbieger.setEnabled(true);
      	tAmpelphasen.setBackground(Color.WHITE);
      	tVerteilungAbbieger.setBackground(Color.WHITE);
      	for(int i=0;i<4;i++){
      		for(int j=0;j<3;j++){
      			tVerteilungAbbieger.setValueAt(manuellVerteilungAbbieger[i][j],j,i);
      		}
      		tAmpelphasen.setValueAt(manuellAmpelphasen[i],0,i);
      	}
    	modus = 1;
      }
  }
}

class AmpelAbschnittEinstellungen_btUebernehmen_actionAdapter implements java.awt.event.ActionListener {
	  AmpelAbschnittEinstellungen adaptee;

	  AmpelAbschnittEinstellungen_btUebernehmen_actionAdapter(AmpelAbschnittEinstellungen adaptee) {
	    this.adaptee = adaptee;
	  }
	  public void actionPerformed(ActionEvent e) {
	    adaptee.btUebernehmen_actionPerformed(e);
	  }
	}
