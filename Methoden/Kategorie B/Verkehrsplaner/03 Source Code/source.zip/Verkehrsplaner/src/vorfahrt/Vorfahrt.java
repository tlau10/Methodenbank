/*
 * Created on 04.11.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

package vorfahrt;

import java.util.LinkedList;

import verkehrsplaner.Ereignis;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Fahrzeug;
import verkehrsplaner.FahrzeugListe;
import verkehrsplaner.Kreuzung;
import verkehrsplaner.NormaleStrasse;
import verkehrsplaner.Physik;
import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Simulationslogik;
import verkehrsplaner.Status;
import verkehrsplaner.Warteschlange;
import verkehrsplaner.Zufallszahlen;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Vorfahrt implements Kreuzung {
	
	private VorfahrtEinstellungen daten;
	private Simulationslogik logik;
	private Physik physik;
	private FahrzeugListe angekuendigteFahrzeuge;
	private Simulationsabschnitt[] anbindung;
	private double zeit;
	
	//Zeit f�r das Vorrausschauende Einfahren
	private double zVorraus=1.0;
	
//	private double segmentlaenge;
	private double segmentNormal;
	private double segmentGross;
	
	private int[] vorfahrtStrassen = new int[2];
	
	private double[][] abbiegenWahl; //Wahrkeit fuer Abbiegen je nach Einfahrt
	
	private Warteschlange[] ws = new Warteschlange[4];
	private VorfahrtSegment[] einfahrt = new VorfahrtSegment[4];
	
	
	private VorfahrtSegment[][] segment = new VorfahrtSegment[2][8];
	
	
	public Vorfahrt(VorfahrtEinstellungen daten){
		this.daten = daten;
		
		angekuendigteFahrzeuge = new FahrzeugListe();
		anbindung = new Simulationsabschnitt[4];
		physik = new Physik();
		//segmentlaenge=daten.getBreite()/2.0;
		segmentNormal = daten.getBreite()/4.0;
		segmentGross = daten.getBreite()*0.34;
		vorfahrtStrassen = daten.getVorfahrtStrassen();
	}
	

	public Ergebnis getErgebnis() {
		Ergebnis e = new Ergebnis(daten.getId());
		
		for(int i=0;i<4;i++){
			e.addWS(ws[i].getErgebnis());
		}
		

		int[] anzahlFahrzeuge = {0,0,0,0};
		double[] durchsWSlaenge = {0.0,0.0,0.0,0.0};
		double[] durchsWartezeit = {0.0,0.0,0.0,0.0};
		double[] prozAuslastung = {0.0,0.0,0.0,0.0};
		double[] prozStau = {0.0,0.0,0.0,0.0};
		int[] maxLaenge = {0,0,0,0};
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				
//			 	aktuelle WS l�nge
				anzahlFahrzeuge[i] = e.getWS(i).getAnzahlFahrzeuge();

//				 durchs. WS l�nge
				durchsWSlaenge[i] = e.getWS(i).getDurchsWartendeFahrzeuge();

//				 durchs. Wartezeit
				durchsWartezeit[i] = e.getWS(i).getDurchsVerweilzeitWS();

//				 proz. Stra�enauslastung
				prozAuslastung[i] = e.getWS(i).getProzentualeStrassenauslastung();
					
//				 proz. Stau
				prozStau[i] = e.getWS(i).getProzentualBlockiert();

//				Max WS L�nge
				maxLaenge[i] = e.getWS(i).getMaxAnzahlFahrzeuge();
			}
		}
		
		e.setAnzahlFahrzeuge(anzahlFahrzeuge);
		e.setDurchsWSlaenge(durchsWSlaenge);
		e.setDurchsWartezeit(durchsWartezeit);
		e.setProzAuslastung(prozAuslastung);
		e.setProzStau(prozStau);
		e.setMaxLaenge(maxLaenge);
		
		return e;
	}

	public void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung) {
		if(himmelsrichtung >= 0 && himmelsrichtung < 4){
			this.anbindung[himmelsrichtung] = anbindung;
		}
		else{
			System.err.println("Fehlerhafte Zuweisung - Stra�e "+daten.getId()+" Richtung:"+himmelsrichtung);
		}
	}

	public void ereignisHandler(Ereignis e) {
		zeit=e.getZeitpunkt();
		
		if(e.getTyp().equals("ankunft")){
			ankunft(e.getFahrzeug());
		}
		else if (e.getTyp().equals("bedienEnde")){
			bedienEnde(((VorfahrtContainer) e.getFahrzeug()));
		}
		else{
			System.err.println("Unbekanntes Ereignis" + e.getTyp());
		}
	}
	
	private void bedienEnde(VorfahrtContainer f){
		
		VorfahrtSegment head = f.getHead();
		VorfahrtSegment tail = f.getTail();
		
		//Verl�sst das Auto die Kreuzung?
		if(head == f.getAusfahrtSegment()){
			if (head==tail){//Das Auto-Heck verl�sst die Kreuzung
				Ereignis e = new Ereignis(logik.getZeit(), f, "ankunft", head.getAusfahrt());
				logik.pushEreignis(e);
				segmentWirdFrei(head); //eventl. Blockade beheben und aus WS einfahren lassen
				
				//TODO eventl. andere Autos einfahren lassen
				autosAusWsEinfahrenLassen();
			}
			else{
				neuesBedienEndeEreignis(f);
			}
		}
		else{
			//Auto f�hrt weiter
			if(f.getNextHead().getStatus().equals("frei") || f.getNextHead().getStatus().equals("reserviert")){ //Auto f�hrt normal weiter
				neuesBedienEndeEreignis(f);
			}
			else{
//				System.err.println("Segment:"+head.getNummer()+" Blockade durch: "+f);
//				System.err.println("BlockadeAuto: "+f.getID());
//				System.err.println("BlockadeEinfahrt: "+f.getEinfahrt());
//				System.err.println("BlockadeAbbiegen: "+f.getAbbiegen());
//				System.err.println("BlockadeAusfahrt: "+f.getAusfahrt());
//				System.err.println("BlockadeHead: "+f.getHead());
//				System.err.println("BlockadeTail: "+f.getTail());
//				
//				System.err.println("BlockadeSegment�bersicht: ");
//				for(int y=0;y<2;y++)
//					for(int z=0;z<2;z++)
//						System.err.println(y+":"+z+" S:"+segment[y][z].getStatus()+" Auto: "+segment[y][z].getAktFahrzeug());
//				
				head.setStatus("blockiert");
				f.getNextHead().setBlockiertesFahrzeug(f);
			}
		}
	}
	
	private void segmentWirdFrei(VorfahrtSegment s){
		s.setAktFahrzeug(null);
		s.setStatus("frei");

		
		//Blockade aufheben
		if(s.getBlockiertesFahrzeug() != null){
			VorfahrtContainer f = s.getBlockiertesFahrzeug();
//			System.err.println("Segment:"+s.getNummer()+"Blockade aufheben durch: "+f);
			s.setBlockiertesFahrzeug(null);
			//f.getHead().setStatus("belegt"); //Wird in neuesBedienEnde erledigt
			
			//Geschwindigkeitsverlust durch die Blockade erfassen-!!!!
			f.setGeschwindigkeit(Physik.getGeschwindigkeitsverlustDurchBlockade(f, zeit, s.getSegmentlaenge()));

			bedienEnde(f);
		}
		else if(s.getWs() != null && einfahrtFrei(s.getWs(),false,null)){	//Eventl. Auto aus WS einfahren lassen!!! 

			VorfahrtContainer f = (VorfahrtContainer) s.getWs().pop(zeit);
					
			//Eventl. anfahren in der Gruppe erm�glichen (Geschw. vorteil)
			VorfahrtContainer letztesF = s.getLetztesFahrzeug();
					
			//Falls das letzte Fahrzeug auch in diesem Segment gestartet ist -> Anfahren in der Gruppe
			if(letztesF != null && letztesF.getEinfahrtSegment() == s){
				f.setGeschwindigkeit(Physik.getGeschwindigkeitBeimAnfahrenInDerGruppe(f, letztesF));
			}	
			//Neues BeidenEndeEreignis f�r das Fahrzeug planen
			f.reserviereRoute();//TODO Reservieren
			neuesBedienEndeEreignis(f);
		}
	}


	public void ankunft(Fahrzeug f) {
		//FahrzeugContainer suchen
		VorfahrtContainer a = (VorfahrtContainer)angekuendigteFahrzeuge.holeFahrzeugAusListeNachID(f.getID());
		a.fahrzeugErreichtWS(zeit);
		a.setStandort(this);
		
		//Fahrzeug bereits beim n�chsten Segment anmelden
		double maxNaechstes=a.getAusfahrtSegment().getAusfahrt().getMaxGeschwindigkeit(this,f);
		a.setMaxVfuerNaechstesSegment(maxNaechstes);
		
		//Einfahrendes Segment ermitteln
		VorfahrtSegment einfahrt = a.getNextHead();
		
		//TODO ANPASSEN
		//Kontrollieren ob das Segment frei und ob eine WS exisitiert 
		if(ws[a.getEinfahrt()].getLaenge(zeit) == 0 && einfahrtFrei(a.getEinfahrt(),true,a)){
			a.reserviereRoute();//TODO
			neuesBedienEndeEreignis(a);
		}
		else{
			//Fahrzeug muss in die Warteschlange
			a.setGeschwindigkeit(0.0);//Auto verliert die Geschwindigkeit in der WS
			einfahrt.getWs().push(a,zeit);
		}
	}
	
	private void neuesBedienEndeEreignis(VorfahrtContainer aktuellesAuto){
		
		aktuellesAuto.setZeitLetztesBedienEnde(zeit);
		
		double zeitpunkt=0.0;
		double maxV = aktuellesAuto.getMaxV();
		double maxNaechstes;
		
		VorfahrtSegment frei = aktuellesAuto.getTail(); //Letztes Segment zwischenspeichern
		
		aktuellesAuto.schritt();	//Head und Tail um 1 Segment weiter bewegen
		VorfahrtSegment head = aktuellesAuto.getHead();
		VorfahrtSegment tail = aktuellesAuto.getTail();
		VorfahrtSegment ausfahrt = aktuellesAuto.getAusfahrtSegment();
		
		head.setStatus("belegt");
		head.setAktFahrzeug(aktuellesAuto);
		
		if(head == ausfahrt){	//Fahrzeug f�hrt aus der Kreuzung aus
			maxNaechstes=aktuellesAuto.getMaxVfuerNaechstesSegment(); //Rausbeschleunigen
		}
		else{	//Fahrzeug f�hrt in der Kreuzung
			maxNaechstes=maxV;
		}
		
		if(tail != null && tail != aktuellesAuto.getEinfahrtSegment()){
				// Freigeben des Vorgaengersegments
			segmentWirdFrei(frei);  //eventl. Blockade beheben und aus WS einfahren lassen
		}

		//Geschwindikeiten und Endzeitpunkte berechnen
		zeitpunkt +=physik.zeitBerechnen(head.getSegmentlaenge(), maxV, maxNaechstes, aktuellesAuto.getFahrzeug());
		//System.out.println("Zeit:"+zeitpunkt);
		zeitpunkt += zeit;
		
		//Ereignis(double zeitpunkt, Fahrzeug fahrzeug, String typ, Simulationsabschnitt standort){
		Ereignis e = new Ereignis(zeitpunkt,aktuellesAuto,"bedienEnde",this);
		logik.pushEreignis(e);
	}

	public double getMaxGeschwindigkeit(Simulationsabschnitt herkunft, Fahrzeug f) {
		//Einfahrt ermitteln
		int einfahrt;
		double maxV=30.0; //TODO Besseren Wert finden
		double tmpMaxV=30.0;
		
		if(herkunft == anbindung[0]){
			einfahrt = 0;
		}
		else if(herkunft == anbindung[1]){
			einfahrt = 1;
		}
		else if(herkunft == anbindung[2]){
			einfahrt = 2;
		}
		else if(herkunft == anbindung[3]){
			einfahrt = 3;
		}
		else{
			System.err.println("herkunft: " + f.getStandort());
			System.err.println("anbindung0: " + anbindung[0]);
			System.err.println("anbindung1: " + anbindung[1]);
			System.err.println("Fehlerhafte Herkunft - "+getTyp()+" "+daten.getId()+" Fahrzeug:"+f.getID());
			return 0.0;
		}

		//Abbiegen und Ausfahrt ermitteln
		double sum=0.0;
		for(int i=0;i<3;i++){
			sum += abbiegenWahl[einfahrt][i];
		}
		double tmp=0.0;
		int abbiegen=0;
		double zufallsZahl=Zufallszahlen.drand();
		for(int i=0;i<3;i++){			//Abbiegen ermitteln
			tmp += abbiegenWahl[einfahrt][i]/sum;
			if (zufallsZahl < tmp){
				abbiegen = i;
				break;
			}
		}
		
		int ausfahrt = einfahrt;

		if (abbiegen == 0){	//Rechts abbiegen
			ausfahrt += 3;	
			tmpMaxV = Physik.getMaxGeschwindigkeitInDerKurve(0.25*daten.getBreite(),f.getHorizontaleBeschleunigung());
		}
		else if (abbiegen == 1){ //Geradeaus fahren
			ausfahrt += 2;
		}
		else{ 			//Links abbiegen
			ausfahrt += 1;
			tmpMaxV = Physik.getMaxGeschwindigkeitInDerKurve(0.75*daten.getBreite(),f.getHorizontaleBeschleunigung());
		}

		if(tmpMaxV < maxV){
			maxV = tmpMaxV;
		}
		
		if (ausfahrt >= 4){
			ausfahrt -= 4;
		}
		
		
		//definition der Route
		
		LinkedList route= new LinkedList();
//		if(einfahrt == 0 && abbiegen == 0){
//			route.addLast(segment[0][0]);
//		}
//		else if(einfahrt == 0 && abbiegen == 1){
//			route.addLast(segment[0][0]);
//			route.addLast(segment[1][0]);
//		}
//		else if(einfahrt == 0 && abbiegen == 2){
//			route.addLast(segment[0][0]);
//			route.addLast(segment[1][0]);
//			route.addLast(segment[1][1]);
//		}
//		else if(einfahrt == 1 && abbiegen == 0){
//			route.addLast(segment[0][1]);
//		}
//		else if(einfahrt == 1 && abbiegen == 1){
//			route.addLast(segment[0][1]);
//			route.addLast(segment[0][0]);
//		}
//		else if(einfahrt == 1 && abbiegen == 2){
//			route.addLast(segment[0][1]);
//			route.addLast(segment[0][0]);
//			route.addLast(segment[1][0]);
//		}
//		else if(einfahrt == 2 && abbiegen == 0){
//			route.addLast(segment[1][1]);
//		}
//		else if(einfahrt == 2 && abbiegen == 1){
//			route.addLast(segment[1][1]);
//			route.addLast(segment[0][1]);
//		}
//		else if(einfahrt == 2 && abbiegen == 2){
//			route.addLast(segment[1][1]);
//			route.addLast(segment[0][1]);
//			route.addLast(segment[0][0]);
//		}
//		else if(einfahrt == 3 && abbiegen == 0){
//			route.addLast(segment[1][0]);
//		}
//		else if(einfahrt == 3 && abbiegen == 1){
//			route.addLast(segment[1][0]);
//			route.addLast(segment[1][1]);
//		}
//		else if(einfahrt == 3 && abbiegen == 2){
//			route.addLast(segment[1][0]);
//			route.addLast(segment[1][1]);
//			route.addLast(segment[0][1]);
//		}
		
		if(einfahrt == 0 && abbiegen == 0){
			route.addLast(segment[0][7]);
			route.addLast(segment[0][6]);
		}
		else if(einfahrt == 0 && abbiegen == 1){
			route.addLast(segment[0][7]);
			route.addLast(segment[0][6]);
			route.addLast(segment[0][5]);
			route.addLast(segment[0][4]);
		}
		else if(einfahrt == 0 && abbiegen == 2){
			route.addLast(segment[0][7]);
			route.addLast(segment[1][0]);
			route.addLast(segment[1][1]);
			route.addLast(segment[0][2]);
		}
		else if(einfahrt == 1 && abbiegen == 0){
			route.addLast(segment[0][1]);
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 1 && abbiegen == 1){
			route.addLast(segment[0][1]);
			route.addLast(segment[0][0]);
			route.addLast(segment[0][7]);
			route.addLast(segment[0][6]);
		}
		else if(einfahrt == 1 && abbiegen == 2){
			route.addLast(segment[0][1]);
			route.addLast(segment[1][1]);
			route.addLast(segment[1][2]);
			route.addLast(segment[0][4]);
		}
		else if(einfahrt == 2 && abbiegen == 0){
			route.addLast(segment[0][3]);
			route.addLast(segment[0][2]);
		}
		else if(einfahrt == 2 && abbiegen == 1){
			route.addLast(segment[0][3]);
			route.addLast(segment[0][2]);
			route.addLast(segment[0][1]);
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 2 && abbiegen == 2){
			route.addLast(segment[0][3]);
			route.addLast(segment[1][2]);
			route.addLast(segment[1][3]);
			route.addLast(segment[0][6]);
		}
		else if(einfahrt == 3 && abbiegen == 0){
			route.addLast(segment[0][5]);
			route.addLast(segment[0][4]);
		}
		else if(einfahrt == 3 && abbiegen == 1){
			route.addLast(segment[0][5]);
			route.addLast(segment[0][4]);
			route.addLast(segment[0][3]);
			route.addLast(segment[0][2]);
		}
		else if(einfahrt == 3 && abbiegen == 2){
			route.addLast(segment[0][5]);
			route.addLast(segment[1][3]);
			route.addLast(segment[1][0]);
			route.addLast(segment[0][0]);
		}
		
		//FahrzeugContainer erstellen und in die Ank�ndigungsliste stellen
		VorfahrtContainer c = 
			new VorfahrtContainer(f,einfahrt,abbiegen,ausfahrt,route,segmentNormal);
		c.setVorherigenStandort(herkunft);
		angekuendigteFahrzeuge.push(c);
		c.setMaxV(maxV);
//		System.out.println("MaxV "+Physik.getMaxGeschwindigkeitInDerKurve(daten.getRadius(),f.getHorizontaleBeschleunigung()));
		return maxV;
	}

	public boolean pruefeInitalisierung() {
		if(logik == null){
			return false;
		}
		
		if(vorfahrtStrassen[0] == -1 || vorfahrtStrassen[1] == -1){
			System.err.println("Vorfahrt Strasse fehlen die Vorfahrtregeln ID: "+daten.getId());
			return false;
		}

		abbiegenWahl = daten.getAbbiegenWahl();
		
		
		//�berpr�fen der Strassenanzahl von Einfahrten und Ausfahrten
		int anzahlStrassen=4;
		for(int i=0;i<4;i++){					
			if(anbindung[i] == null){
				
				if(anzahlStrassen < 3){	//Falls es schon nur 2 Strassen hat
					System.err.println("Fehler: " +daten.getName()+" hat zuwenig Strassen / "+anzahlStrassen+"/"+i);
					return false;	//TODO Kontrollieren
				}
				anzahlStrassen--;


				 //Abbiegen in die nicht existierende Strasse verhindern
				for(int j=0;j<3;j++){
					int strasse=i + (j+1);
					
					if(strasse > 3){
						strasse -=4;
					}
					
					abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
				}
			}
			else{
				//F�r jede Strasse, welche in die Kreuzung m�ndet muss min. 1 andere wieder weg f�hren
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenZurKreuzung(daten.getId()) > 0){
					
					boolean ausfahrtVorhanden=false;
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						if(anbindung[strasse] != null){
							if(((NormaleStrasse)anbindung[strasse]).getAnzahlSpurenVonKreuzungWeg(daten.getId()) > 0){
								ausfahrtVorhanden=true;
								break;
							}
						}
					}
					
					if(!ausfahrtVorhanden){
						System.err.println("Fehler: " +daten.getName()+" hat zuwenig Ausfahrt");
						return false;	//TODO Kontrollieren
					}
				}
				
				//Falls es eine Einbahnstrasse ist
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenVonKreuzungWeg(daten.getId())<1){
					 //Falsches Abbiegen in die Einbahnstrasse verhindern
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
					}
				}
			}
		}
		daten.setAbbiegenWahl(abbiegenWahl);
		
		
		//Initialisierungszeug-------------------------->
		
		//WS initialisieren
		for(int i=0;i<4;i++){
			if(anbindung[i] != null)
				ws[i] = new Warteschlange((NormaleStrasse)anbindung[i],this,anbindung[i].getLaengeFuerWS(this));
			else
				ws[i] = new Warteschlange(null,this,2.0);
		}
		
		ws[0].setBeschreibung("Nord");
		ws[1].setBeschreibung("Ost");
		ws[2].setBeschreibung("S�d");
		ws[3].setBeschreibung("West");


		//Segmente initialisieren
//		for(int i=0;i<2;i++){
//			for(int j=0;j<2;j++){
//				segment[i][j] = new VorfahrtSegment(i*10+j);
//			}
//		}
		
		for(int i=0;i<8;i++){	//Normale Segmente
			segment[0][i] = new VorfahrtSegment(i,segmentNormal);
		}
		for(int i=0;i<4;i++){	//Linksabbiegesegmente in der Mitte
			segment[1][i] = new VorfahrtSegment(i,segmentGross);
		}
		
		
			//Einfahrten zuteilen
//		einfahrt[0] = segment[0][0];
//		einfahrt[1] = segment[0][1];
//		einfahrt[2] = segment[1][1];
//		einfahrt[3] = segment[1][0];
		
		einfahrt[0] = segment[0][7];
		einfahrt[1] = segment[0][1];
		einfahrt[2] = segment[0][3];
		einfahrt[3] = segment[0][5];

		
		for(int i=0;i<4;i++){	//WS den Einfahrten bekannt machen
			einfahrt[i].setWs(ws[i]);
		}

//		segment[0][1].setAusfahrt(anbindung[0]);
//		segment[1][1].setAusfahrt(anbindung[1]);
//		segment[1][0].setAusfahrt(anbindung[2]);
//		segment[0][0].setAusfahrt(anbindung[3]);
		
		segment[0][0].setAusfahrt(anbindung[0]);
		segment[0][2].setAusfahrt(anbindung[1]);
		segment[0][4].setAusfahrt(anbindung[2]);
		segment[0][6].setAusfahrt(anbindung[3]);
		
		return true;
	}

	public String getTyp() {
		return "Vorfahrt";
	}

	public int getID() {
		return daten.getId();
	}

	public int getMaxAnbindungen() {
		return 4;
	}

	public void setSimulationslogik(Simulationslogik logik) {
		this.logik = logik;
	}

	public boolean isBlockiert(Simulationsabschnitt aufrufer) {
		return false; //Kreuzung ist (momentan) nicht blockierbar
	}

	public void setBlockiert(Simulationsabschnitt aufrufer, double zeit) {
//		Kreuzung ist (momentan) nicht blockierbar
	}

	public void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit) {
		this.zeit = zeit;	//aktuelle Zeit
		autosAusWsEinfahrenLassen();
	}
	
	//Autos per Zufall einfahren lassen
	private void autosAusWsEinfahrenLassen(){
		
//		if(!kreuzungIstLeer())//TODO nur f�r debug
//		return;
		
		//Zuerst die Vorfahrtstrassen einfahren lassen
		for(int i=0;i<2;i++){
			if(ws[vorfahrtStrassen[i]].getLaenge(zeit) > 0){
				if(einfahrtFrei(vorfahrtStrassen[i],false,null)){
					VorfahrtContainer a = (VorfahrtContainer)ws[vorfahrtStrassen[i]].pop(zeit);
					a.reserviereRoute(); //TODO
					neuesBedienEndeEreignis(a);
				}
			}
		}
		
		for(int i=0;i<4;i++){
			if(ws[i].getLaenge(zeit) > 0){
				if(einfahrtFrei(i,false,null)){
					VorfahrtContainer a = (VorfahrtContainer)ws[i].pop(zeit);
					a.reserviereRoute(); //TODO
					neuesBedienEndeEreignis(a);
				}
			}
		}
	}

	
	private boolean einfahrtFrei(int wsNr, boolean ankunft, VorfahrtContainer auto){
		
		return einfahrtFrei(ws[wsNr],ankunft,auto);
	}
	
	private boolean einfahrtFrei(Warteschlange ws, boolean ankunft, VorfahrtContainer auto){
		//TODO ANPASSEN
		
		if(ankunft && ws.getLaenge(zeit) == 0){
			if(auto == null){
				System.err.println("Fehlerhafter Auruf von einfahrtFrei");
				return false;
			}
		}
		else if(!ankunft && ws.getLaenge(zeit) > 0){
			auto = (VorfahrtContainer) ws.nextFahrzeug();
		}
		else{
			return false;
		}
		
		if(auto.routeIstFrei() && autoDarfEinfahren(auto) 
				&& !anbindung[auto.getAusfahrt()].isBlockiert(this)){
			return true;
		}
		else{
//			System.err.println("Einfahrt verboten: "+auto.getEinfahrt()+" ID "+auto.getID());
//			System.err.println("WS: "+ws[auto.getEinfahrt()].getLaenge(zeit));
		}
		
		return false;
	}
	
	
	private boolean autoDarfEinfahren(VorfahrtContainer auto){
		//TODO
		int einfahrt = auto.getEinfahrt();
		int abbiegen = auto.getAbbiegen();
		
		//Abbiegen der kommenden Fahrzeuge
		//-1 : Kein Fahrzeug
		// 0 : Rechtsabbieger
		// 1 : Geradeausfahrer
		// 2 : Linksabbieger
		// 3 : Unbekannt
		int[] aF = {-1,-1,-1,-1};
		
//		if(!auto.routeIstFrei()){ //Wird bei einfahrt Frei gemacht
//			return false;
//		}
		
		if(anbindung[auto.getAusfahrt()].isBlockiert(this)){
			return false;
		}
		
		
		//�bersicht �ber die n�chsten Autos bekommen
		for(int i=0;i<4;i++){
			if(ws[i].getLaenge(zeit) > 0){
				aF[i] = ((VorfahrtContainer)ws[i].nextFahrzeug()).getAbbiegen();
			}
			else if (anbindung[i] != null){
				//Schauen, ob was demn�chst von der Strassen kommt
				
				double tmp = ((NormaleStrasse)anbindung[i]).getNaechstenAnkunftZeitpunkt(this);
				tmp -= zeit;
					
				if(tmp >= 0.0 && tmp <= zVorraus){
					aF[i] = 3; //Unbekanntes Abbiegen
						
					int id = ((NormaleStrasse)anbindung[i]).getNaechstenAnkunftID(this);
					VorfahrtContainer a = (VorfahrtContainer)angekuendigteFahrzeuge.zeigeFahrzeugAusListeNachID(id);
						
					if(a != null){
						aF[i] = a.getAbbiegen();
					}
				}
			}
		}
		
		
		//Entscheidungsdiagramm zuerst Spalten dann Zeilen
		//Abbiegen der kommenden Fahrzeuge
		//-1 : Kein Fahrzeug
		// 0 : Rechtsabbieger
		// 1 : Geradeausfahrer
		// 2 : Linksabbieger
		// 3 : Unbekannt
		
		if(istVorfahrtStr(einfahrt)){
			if(istVorfahrtStr(links(einfahrt))){	//Links-Unten
				//Alles OK
			}
			else if(istVorfahrtStr(oben(einfahrt))){ //Unten-Oben
				
				if(abbiegen == 2){ // Linksabbieger achten auf: oben:rechts,gerade,unbekannt	
					if(aF[oben(einfahrt)] == 0 || aF[oben(einfahrt)] == 1 || aF[oben(einfahrt)] == 3){
						return false;
					}
				}
			}
			else if(istVorfahrtStr(rechts(einfahrt))){ //Unten-Rechts
				if(abbiegen == 1){
					if(aF[rechts(einfahrt)] != -1){ //rechts alle
						return false;
					}
				}
				else if(abbiegen == 2){
					if(aF[rechts(einfahrt)] != -1 && aF[rechts(einfahrt)] != 0){//rechts: gerade, links, unbekannt
						return false;
					}
				}
			}
			else{
				System.err.println("Fehlerhafte Vorfahrtsstrasse ID: "+daten.getId());
			}
		}
		else{
			if(!istVorfahrtStr(rechts(einfahrt))){ //Vorfahrstr. Verlauf: Links-Oben
				
				//Algemein:
				if(aF[links(einfahrt)] == 1 || aF[links(einfahrt)] == 3)//links gerade oder unbekannt
					return false;

				if(aF[oben(einfahrt)] == 3)//oben unbekannt
					return false;
				
				if(abbiegen == 0){
					if(aF[oben(einfahrt)] == 2)//oben Linksabbieger
						return false;
				}
				else if(abbiegen == 1){
					if(aF[oben(einfahrt)] == 2)//oben Linksabbieger
						return false;
					if(aF[links(einfahrt)] == 2)//links Linksabbieger
						return false;
					if(aF[rechts(einfahrt)] != -1) //rechts alle
						return false;
				}
				else if(abbiegen == 2){
					if(aF[links(einfahrt)] == 2)//links Linksabbieger
						return false;
					if(aF[oben(einfahrt)] == 0)//oben Rechtsabbieger
						return false;
					if(aF[oben(einfahrt)] == 1)//oben geradeaus
						return false;
					if(aF[rechts(einfahrt)] == 1)//rechts Gerade
						return false;
					if(aF[rechts(einfahrt)] == 2)//rechts Linksabbieger
						return false;
					if(aF[rechts(einfahrt)] == 3)//rechts Unbekannt
						return false;
				}
			}
			else if(!istVorfahrtStr(oben(einfahrt))){ //Vorfahrstr. Verlauf: Links-Rechts
				
				//Allgemein
				if(aF[links(einfahrt)] == 1 || aF[links(einfahrt)] == 3)//links gerade oder unbekannt
					return false;
				

				if(abbiegen == 1){
					if(aF[links(einfahrt)] == 2)//links Linksabbieger
						return false;
					if(aF[rechts(einfahrt)] != -1) //rechts alle
						return false;
				}
				else if(abbiegen == 2){
					if(aF[links(einfahrt)] == 2)//links Linksabbieger
						return false;
					if(aF[oben(einfahrt)] == 3)//oben unbekannt
						return false;
					if(aF[oben(einfahrt)] == 0)//oben Rechtsabbieger
						return false;
					if(aF[oben(einfahrt)] == 1)//oben geradeaus
						return false;
					if(aF[rechts(einfahrt)] == 1)//rechts Gerade
						return false;
					if(aF[rechts(einfahrt)] == 2)//rechts Linksabbieger
						return false;
					if(aF[rechts(einfahrt)] == 3)//rechts Unbekannt
						return false;
				}
			}
			else if(!istVorfahrtStr(links(einfahrt))){ //Vorfahrstr. Verlauf: Oben-Rechts
				
				//Allgemein
				if(aF[oben(einfahrt)] == 3) //oben unbekannt
					return false;
				
				if(abbiegen == 0){
					if(aF[oben(einfahrt)] == 2)//oben Linksabbieger
						return false;	
				}	
				else if(abbiegen == 1){
					if(aF[rechts(einfahrt)] != -1)//rechts alle
						return false;
					if(aF[oben(einfahrt)] == 2)//oben Linksabbieger
						return false;
				}
				else if(abbiegen == 2){
					if(aF[oben(einfahrt)] == 0)//oben Rechtsabbieger
						return false;
					if(aF[oben(einfahrt)] == 1)//oben geradeaus
						return false;
					if(aF[rechts(einfahrt)] == 1)//rechts Gerade
						return false;
					if(aF[rechts(einfahrt)] == 2)//rechts Linksabbieger
						return false;
					if(aF[rechts(einfahrt)] == 3)//rechts Unbekannt
						return false;
				}
			}
			else{
				System.err.println("Fehlerhafte Vorfahrtsstrasse ID: "+daten.getId());
			}
		}

		
		return true;
	}
	
	private boolean istVorfahrtStr(int str){
		if(str == vorfahrtStrassen[0] || str == vorfahrtStrassen[1])
			return true;
		return false;
	}
	
	private int links(int einfahrt){
		einfahrt +=1;
		if(einfahrt > 3)
			einfahrt -= 4;
		return einfahrt;
	}
	
	private int oben(int einfahrt){
		einfahrt +=2;
		if(einfahrt > 3)
			einfahrt -= 4;
		return einfahrt;
	}
	
	private int rechts(int einfahrt){
		einfahrt -= 1;
		if(einfahrt < 0)
			einfahrt += 4;
		return einfahrt;
	}
	

	
//	private boolean kreuzungIstLeer(){
//		for(int i=0;i<2;i++){
//			for(int j=0;j<2;j++){
//				if(!segment[i][j].getStatus().equals("frei")){
//					return false;
//				}
//			}
//		}
//		return true;
//	}


	public double getLaengeFuerWS(Simulationsabschnitt aufrufer) {
		return 3.0; //Kreuzung bietet kaum Platz f�r eine WS
	}
	
	public Status getStatus() {
		Status s = new Status(daten.getId());
		s.setAnzahlWS(4);
		int[] wsId = new int[4]; 
		int[] wsLaenge = new int[4]; 
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				wsId[i] = anbindung[i].getID();
			}
			else{
				wsId[i] = -1;
			}
		}
		
		wsLaenge[0] = ws[0].getLaenge(zeit);
		wsLaenge[1] = ws[1].getLaenge(zeit);
		wsLaenge[2] = ws[2].getLaenge(zeit);
		wsLaenge[3] = ws[3].getLaenge(zeit);
		
		String info="";
		int anzahlBelegterSegmente=0;
		
		info += "Segment�bersicht\n";
//		for(int i=0;i<2;i++){
//			for(int j=0;j<2;j++){
//				if(segment[i][j].getStatus() == "belegt" || segment[i][j].getStatus() == "blockiert"){
//					anzahlBelegterSegmente++;
//					
////					if(segment[i][j].getAktFahrzeug()==null && segment[i][j].getBlockiertesFahrzeug()==null
////							&& segment[i][j].getLetztesFahrzeug() != null){
////						System.err.println("AutoID: "+segment[i][j].getLetztesFahrzeug().getID());
////						System.err.println("Auto: "+segment[i][j].getLetztesFahrzeug());
////						System.err.println("Laenge: "+segment[i][j].getLetztesFahrzeug().getLaengeInMeter());
////						System.err.println("Einfahrt: "+segment[i][j].getLetztesFahrzeug().getEinfahrt());
////						System.err.println("Ausfahrt: "+segment[i][j].getLetztesFahrzeug().getAusfahrt());
////						System.err.println("Abbiegen: "+segment[i][j].getLetztesFahrzeug().getAbbiegen());
////						System.err.println("Routenlaenge: "+segment[i][j].getLetztesFahrzeug().getRoute().size());
////						System.err.println("Head: "+segment[i][j].getLetztesFahrzeug().getHead().getNummer());
////						System.err.println("Tail: "+segment[i][j].getLetztesFahrzeug().getTail());
////						System.err.println("LastHead: "+segment[i][j].getLetztesFahrzeug().getLastHead());
////						System.err.println("LastTail: "+segment[i][j].getLetztesFahrzeug().getLastTail());
////						
////						LinkedList route = segment[i][j].getLetztesFahrzeug().getRoute();
////						for(int y=0;y<route.size();y++)
////							System.err.println(y+": "+((VorfahrtSegment)route.get(y)).getNummer());
////						
////						System.err.println("\n\nSegment�bersicht: ");
////						for(int y=0;y<2;y++)
////							for(int z=0;z<2;z++)
////								System.err.println(y+":"+z+" S:"+segment[y][z].getStatus()+" Auto: "+segment[y][z].getAktFahrzeug());
////					}
//					
//					
//					
//					//info += "Segment "+Integer.toString(i)+Integer.toString(j)+" Belegt durch ";
////					System.err.println("Segment: "+i+j+"  Status:"+segment[i][j].getStatus()+" @"+segment[i][j]);
////					System.err.println(segment[i][j].getAktFahrzeug());
////					System.err.println(segment[i][j].getBlockiertesFahrzeug());
////					System.err.println(segment[i][j].getLetztesFahrzeug());
//					//info += Integer.toString(segment[i][j].getAktFahrzeug().getID())+"\t";
//				}
//				else{
//					//info +="\t";
//				}
//				info += getSegmentStatus(i, j);
//			}
//			info += "\n";
//		}
		
		info += "\t"+getSegmentStatus(0,7)+"\t"+getSegmentStatus(0,0)+"\n";
		info += getSegmentStatus(0,6)+"\t"+getSegmentStatus(1,0)+"\t"+getSegmentStatus(0,1)+"\n";
		info += "\t"+getSegmentStatus(1,3)+"\t"+getSegmentStatus(1,1)+"\n";
		info += getSegmentStatus(0,5)+"\t"+getSegmentStatus(1,2)+"\t"+getSegmentStatus(0,2)+"\n";
		info += "\t"+getSegmentStatus(0,4)+"\t"+getSegmentStatus(0,3)+"\n";
		
		
		info += "Belegte Segmente: " + Integer.toString(anzahlBelegterSegmente);
		
		s.setInfoText(info);
		s.setWsId(wsId);
		s.setWsLaenge(wsLaenge);
		return s;
	}
	
	private String getSegmentStatus(int i, int j){
		if(segment[i][j].getAktFahrzeug() != null){
			return Integer.toString(segment[i][j].getAktFahrzeug().getID())+"\t";
		}
		else{
			return "__\t";
		}
	}
}
