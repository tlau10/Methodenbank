package vorfahrt;

import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Warteschlange;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class VorfahrtSegment {
	private int nummer;
	private VorfahrtContainer aktFahrzeug;
	private VorfahrtContainer letztesFahrzeug;
	private String status;
	private Warteschlange ws;
	private Simulationsabschnitt ausfahrt;
	private VorfahrtContainer blockiertesFahrzeug;
	private double segmentlaenge;

	public VorfahrtSegment(int nummer, double segmentlaenge) {
		this.nummer = nummer;
		this.segmentlaenge = segmentlaenge;
		aktFahrzeug = null;
		status = "frei";
		ws=null;
		ausfahrt=null;
		blockiertesFahrzeug=null;
	}

	/**
	 * @return Returns the blockiertesFahrzeug.
	 */
	public VorfahrtContainer getBlockiertesFahrzeug() {
		return blockiertesFahrzeug;
	}
	/**
	 * @param blockiertesFahrzeug The blockiertesFahrzeug to set.
	 */
	public void setBlockiertesFahrzeug(VorfahrtContainer blockiertesFahrzeug) {
		this.blockiertesFahrzeug = blockiertesFahrzeug;
	}
	/**
	 * @return Returns the ausfahrt.
	 */
	public Simulationsabschnitt getAusfahrt() {
		return ausfahrt;
	}
	/**
	 * @param ausfahrt The ausfahrt to set.
	 */
	public void setAusfahrt(Simulationsabschnitt ausfahrt) {
		this.ausfahrt = ausfahrt;
	}
	/**
	 * @return Returns the ws.
	 */
	public Warteschlange getWs() {
		return ws;
	}
	/**
	 * @param ws The ws to set.
	 */
	public void setWs(Warteschlange ws) {
		this.ws = ws;
	}
	/**
	 * @return Returns the aktuelleFahrzeug.
	 */
	public VorfahrtContainer getAktFahrzeug() {
		return aktFahrzeug;
	}
	/**
	 * @param aktFahrzeug The aktuelleFahrzeug to set.
	 */
	public void setAktFahrzeug(VorfahrtContainer aktFahrzeug) {
		this.letztesFahrzeug = this.aktFahrzeug;
		this.aktFahrzeug = aktFahrzeug;
	}
	/**
	 * @return Returns the letztesFahrzeug.
	 */
	public VorfahrtContainer getLetztesFahrzeug() {
		return letztesFahrzeug;
	}
	/**
	 * @return Returns the nummer of the Segment.
	 */
	public int getNummer() {
		return nummer;
	}
	
	
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public double getSegmentlaenge() {
		return segmentlaenge;
	}
	
	
	
}
