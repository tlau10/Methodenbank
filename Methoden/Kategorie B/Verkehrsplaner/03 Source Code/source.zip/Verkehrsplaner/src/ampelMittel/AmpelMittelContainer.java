/*
 * Created on 27.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ampelMittel;

import java.util.LinkedList;

import verkehrsplaner.Fahrzeug;
import verkehrsplaner.KreuzungFahrzeugContainer;
import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Warteschlange;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AmpelMittelContainer implements KreuzungFahrzeugContainer {
	private Fahrzeug f;
	private Simulationsabschnitt vorherigerStandort;
	private double startInWS=0.0;

	private int einfahrt;
	private int abbiegen;
	private int ausfahrt;
	
	private double maxNaechstes;
	private double zeitLetztesBedienEnde;
	
	private double maxV;
	
	private AmpelMittelSegment lastHead;
	private AmpelMittelSegment lastTail;
	
	private Warteschlange wS;
	
	private LinkedList route;
	private int head = -1;
	private int tail;
	private int laenge; //In Segmenten
	private double sicherheitsabstand = 1.5;//Halbe Wagenl�nge Sicherheitsabstand + Verschnitt beim Segment
								//Eventl. einfach 1 Segment sicherheitsabstand besser ???
	
	public AmpelMittelContainer(Fahrzeug f, int einfahrt, int abbiegen, int ausfahrt,
								LinkedList route, double segmentlaenge) {
		this.f = f;
		if(f != null){
			this.vorherigerStandort = f.getStandort();
		}
		this.einfahrt = einfahrt;
		this.abbiegen = abbiegen;
		this.ausfahrt = ausfahrt;
		this.route = route;
		this.laenge = (int) Math.ceil((f.getLaengeInMeter()*sicherheitsabstand)/segmentlaenge);
		this.tail = head-laenge+1;
		wS = ((AmpelMittelSegment)route.getFirst()).getWs();
	}
	
	public AmpelMittelSegment getNextHead(){
		AmpelMittelSegment ergebnis;
		if(head+1<route.size()){
			ergebnis = (AmpelMittelSegment) route.get(head+1);
		}
		else{
			ergebnis = (AmpelMittelSegment) route.get(route.size()-1);
		}
		return ergebnis;
	}

	
	public AmpelMittelSegment getNextTail(){
		AmpelMittelSegment ergebnis;
		if(tail>=-1 && tail+1<route.size()){
			ergebnis = (AmpelMittelSegment) route.get(tail+1);
		}
		else if(tail>=-1 && tail+1>=route.size()){
			ergebnis = (AmpelMittelSegment) route.get(route.size()-1);
		}
		else{
			ergebnis = null;
		}
		return ergebnis;
	}
	
	public AmpelMittelSegment getHead(){
		if(head > -1 && head<route.size()){
			return (AmpelMittelSegment) route.get(head);
		}
		else if(head > -1 && head>=route.size()){
			return (AmpelMittelSegment) route.get(route.size()-1);
		}
		return null;
	}
	
	public AmpelMittelSegment getTail(){
		if(tail > -1 && tail<route.size()){
			return (AmpelMittelSegment) route.get(tail);
		}
		else if(tail > -1 && tail>=route.size()){
			System.err.println("AmpelMittel: Tail geht �ber sein Ziel hinaus");
			return (AmpelMittelSegment) route.get(route.size()-1);
		}
		return null;
	}
	
	//Warnung: es muss immer zuerst ein head++ durchgef�hrt werden vor tail �berpr�fung
	public void schritt(){
		lastHead = getHead();
		lastTail = getTail();
		head++;
		tail++;
	}
	
	public double getZeitLetztesBedienEnde() {
		return zeitLetztesBedienEnde;
	}

	public void setZeitLetztesBedienEnde(double zeitLetztesBedienEnde) {
		this.zeitLetztesBedienEnde = zeitLetztesBedienEnde;
	}
	
	public double getMaxVfuerNaechstesSegment(){
		return maxNaechstes;
	}
	
	public void setMaxVfuerNaechstesSegment(double naechstesMaxV){
		maxNaechstes = naechstesMaxV;
	}
	
	public AmpelMittelSegment getAusfahrtSegment(){
		return (AmpelMittelSegment) route.get(route.size()-1);
	}
	
	public AmpelMittelSegment getEinfahrtSegment(){
		return (AmpelMittelSegment) route.get(0);
	}

	public AmpelMittelSegment getLastHead() {
		return lastHead;
	}

	public AmpelMittelSegment getLastTail() {
		return lastTail;
	}
	public LinkedList getRoute() {
		return route;
	}
	public Fahrzeug getFahrzeug() {
		return f;
	}

	public Simulationsabschnitt getVorherigenStandort() {
		return vorherigerStandort;
	}

	public void setVorherigenStandort(Simulationsabschnitt s) {
		this.vorherigerStandort = s;
	}

	public double fahrzeugVerlaesstWS(double zeitpunkt){
		return (zeitpunkt-startInWS);
	}
	
	public void fahrzeugErreichtWS(double zeitpunkt){
		startInWS = zeitpunkt;
	}

	public int getID() {
		return f.getID();
	}

	public double getStartZeitpunkt() {
		return f.getStartZeitpunkt();
	}

	public Simulationsabschnitt getStandort() {
		return f.getStandort();
	}

	public double getLaengeInMeter() {
		return f.getLaengeInMeter();
	}

	public double getBeschleunigung() {
		return f.getBeschleunigung();
	}

	public double getGeschwindigkeit() {
		return f.getGeschwindigkeit();
	}

	public String getTyp() {
		return "FahrzeugContainer - " + f.getTyp();
	}

	public void setStandort(Simulationsabschnitt s) {
		f.setStandort(s);
	}

	public void setGeschwindigkeit(double v) {
		f.setGeschwindigkeit(v);
		
	}

	public void setStartZeitpunkt(double startZeit) {
		f.setStartZeitpunkt(startZeit);
	}

	public int getEinfahrt() {
		return einfahrt;
	}

	public int getAusfahrt() {
		return ausfahrt;
	}

	public int getAbbiegen() {
		return abbiegen;
	}

	public double getBremsbeschleunigung() {
		return f.getBremsbeschleunigung();
	}

	public double getHorizontaleBeschleunigung() {
		return f.getHorizontaleBeschleunigung();
	}

	public double getMaxV() {
		return maxV;
	}

	public void setMaxV(double maxV) {
		this.maxV = maxV;
	}
	
	public Warteschlange getWS() {
		return wS;
	}

	public double ankunftWsZeitpunkt() {
		return startInWS;
	}
	
	public double getLetzteGeschwindigkeit() {
		return f.getLetzteGeschwindigkeit();
	}
}
