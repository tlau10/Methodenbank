/*
 * Created on 28.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface AmpelEinstellungenMitAbbiegespur extends AmpelEinstellungen{
	public double[] getLaengeAbbiegeSpur();
	public void setLaengeAbbiegeSpur(double[] laengeAbbiegeSpur);
}
