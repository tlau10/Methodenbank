/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface Fahrzeug {
	int getID();
	double getStartZeitpunkt();
//	Ereignis[] getBisherigeEreignisse();
//	Simulationsabschnitt[] getReiseweg();
	Simulationsabschnitt getStandort();
	double getLaengeInMeter();
	double getBeschleunigung();
	double getBremsbeschleunigung();
	double getHorizontaleBeschleunigung();
	double getGeschwindigkeit();
	double getLetzteGeschwindigkeit();
	String getTyp();
	
//	void setNeuesEreignis(Ereignis e);
	void setStandort(Simulationsabschnitt s);
	void setGeschwindigkeit(double v);
	void setStartZeitpunkt(double startZeit);
}
