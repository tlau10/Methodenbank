/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Senke implements Simulationsabschnitt{
	private int id;
				//Eventl. einen Weg finden eine passendere Geschw. zu finden.

	private Simulationsabschnitt anbindung;
	private Simulationslogik logik;
	private SenkeEinstellungen daten;
	
	public Senke(int id){
		this.id = id;
		anbindung = null;
	}
	
	public Senke(SenkeEinstellungen daten){
		this.daten = daten;
		id = daten.getId();
	}
	
	public void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung) {
		if (himmelsrichtung == 0){
			this.anbindung = anbindung;
		}
		else{
			System.err.println("Fehlerhafte Zuweisung - Senke "+id+" Richtung:"+himmelsrichtung);
		}
	}

	public void ereignisHandler(Ereignis e) {
		// TODO Auto-generated method stub
		
		if(e.getTyp().equals("ankunft")){
			ankunft(e.getFahrzeug());
		}
		else{
			System.err.println("Unbekanntes Ereignis (Senke) " + e.getTyp());
		}
	}

	public void ankunft(Fahrzeug f) {
		// Statistische Auswertungen: Fahrzeuge
		f.setStandort(this);
//		System.out.println("Fahrzeug " +f.getID()+" erreicht Senke " +id+" um "+logik.getZeit()+" Dauer: "+(logik.getZeit()-f.getStartZeitpunkt()));
	}

	public double getMaxGeschwindigkeit(Simulationsabschnitt aufrufer, Fahrzeug f) {
		return daten.getMaxGeschwindigkeit();
	}

	public boolean pruefeInitalisierung() {
		if(anbindung != null && logik != null){
			return true;
		}
		else{
			return false;
		}
	}
	
	public void setSimulationslogik(Simulationslogik logik){
		this.logik = logik;
	}

	public String getTyp() {
		return "Senke";
	}

	public int getID() {
		return id;
	}

	public int getMaxAnbindungen() {
		return 1;
	}

	public boolean isBlockiert(Simulationsabschnitt aufrufer) {
		// TODO Auto-generated method stub
		return false;
	}

	public void setBlockiert(Simulationsabschnitt aufrufer, double zeit) {
		// TODO Auto-generated method stub
		
	}

	public void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit) {
		// TODO Auto-generated method stub
		
	}

	public double getLaengeFuerWS(Simulationsabschnitt aufrufer) {
		// TODO Auto-generated method stub
		return 1.0;
	}

	public Status getStatus() {
		Status s = new Status(id);
		s.setAnzahlWS(0);
		return s;
	}
	
}
