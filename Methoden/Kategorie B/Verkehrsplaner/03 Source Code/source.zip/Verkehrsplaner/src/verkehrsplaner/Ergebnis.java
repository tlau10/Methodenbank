/*
 * Created on 18.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

import java.util.Vector;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Ergebnis {
	//Hier wird das  Ergebnis einer Klasse gespeichert
	int id;
	Vector vorWS;
	Vector ws;
	int wsLaenge=0;
	int vorWSLaenge=0;
	
	//Ergebnismodi in der GUI
	int[] anzahlFahrzeuge = {0,0,0,0};
	double[] durchsWSlaenge = {0.0,0.0,0.0,0.0};
	double[] durchsWartezeit = {0.0,0.0,0.0,0.0};
	double[] prozAuslastung = {0.0,0.0,0.0,0.0};
	double[] prozStau = {0.0,0.0,0.0,0.0};
	int[] maxLaenge = {0,0,0,0};
	
	public Ergebnis(int id){
		vorWS = new Vector();
		ws = new Vector();
		this.id = id;
	}
	
	public void addVorWS(WarteschlangeErgebnis e){
		vorWS.add(e);
	}
	
	public void addWS(WarteschlangeErgebnis e){
		ws.add(e);
	}
	
	public WarteschlangeErgebnis getVorWS(int i){
		return (WarteschlangeErgebnis) vorWS.get(i);
	}
	
	public WarteschlangeErgebnis getWS(int i){
		return (WarteschlangeErgebnis) ws.get(i);
	}
	
	public int laengeVorWS(){
		return vorWS.size();
	}
	
	public int laengeWS(){
		return ws.size();
	}
	
	public int getId() {
		return id;
	}
	
	public int[] getAnzahlFahrzeuge() {
		return anzahlFahrzeuge;
	}
	public void setAnzahlFahrzeuge(int[] anzahlFahrzeuge) {
		this.anzahlFahrzeuge = anzahlFahrzeuge;
	}
	public double[] getDurchsWartezeit() {
		return durchsWartezeit;
	}
	public void setDurchsWartezeit(double[] durchsWartezeit) {
		this.durchsWartezeit = durchsWartezeit;
	}
	public double[] getDurchsWSlaenge() {
		return durchsWSlaenge;
	}
	public void setDurchsWSlaenge(double[] durchsWSlaenge) {
		this.durchsWSlaenge = durchsWSlaenge;
	}
	public int[] getMaxLaenge() {
		return maxLaenge;
	}
	public void setMaxLaenge(int[] maxLaenge) {
		this.maxLaenge = maxLaenge;
	}
	public double[] getProzAuslastung() {
		return prozAuslastung;
	}
	public void setProzAuslastung(double[] prozAuslastung) {
		this.prozAuslastung = prozAuslastung;
	}
	public double[] getProzStau() {
		return prozStau;
	}
	public void setProzStau(double[] prozStau) {
		this.prozStau = prozStau;
	}
	
}
