package verkehrsplaner;
import java.util.LinkedList;

/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EreignisListe {
	private LinkedList liste = new LinkedList();
	
	public void push(Ereignis e){
		liste.add(suchePositioninListe(e.getZeitpunkt()),e);		
		return;
	}
	
//	double dR(double d){ //nur f�r DEBUG
//		return (Math.ceil(d*100.0))/100.0;
//	}
	
	public Ereignis pop(){
		Ereignis e = (Ereignis)liste.getFirst();
		liste.removeFirst();
		return e;
		
	}
	
	private int suchePositioninListe(double zeitpunkt){
		int i=0;
		for(i=0;i<liste.size();i++){
			if(((Ereignis)liste.get(i)).getZeitpunkt() >= zeitpunkt){
				return i;
			}
		}
		return i;
	}
}
