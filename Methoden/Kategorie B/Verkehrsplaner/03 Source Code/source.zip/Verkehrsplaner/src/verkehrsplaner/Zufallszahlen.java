package verkehrsplaner;
/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Zufallszahlen {
	
	public static double drand(){	//double zwischen 0 und 1
		return Math.random();
	}
	
	public static double gleichVerteilt(double min, double max){
		return ((max-min) * Math.random() + min);
	}
	
	public static int ganzZahlZiehen(int von, int bis){
		return (int)Math.floor(gleichVerteilt(von,bis+1.0));
	}
	
	//Erwartungswert = 1/lambda  Varianz=1/lambda^2
	public static double exponentialVerteilt(double lambda){
		return ((-1.0/lambda)*Math.log(1.0-Math.random()));
	}
	
	public static double exponentialVerteilt(double lambda, double offset){
		return exponentialVerteilt(lambda)+offset;
	}
	
	//f�r k>30 ergibt sich n�hrungsweise die Normalverteilung (aber ohne neg. Werte)
	//f�r k=1 entspricht der Exponentialverteilung
	public static double erlangVerteilt(int k, double lambda){
		double p=1.0;
		for (int i=1;i<=k;i++){
			p *= (1.0-Math.random());
		}
		return ((-1.0/lambda)*Math.log(p));
	}
	
	
	//Vorsicht bei Normalverteilung k�nnen negative Werte rauskommen 
	// n wird hier = 12 gesetzt
	public static double normalVerteilt(double sigma, double mu){
		double s=0.0;
		for (int i=1;i<=12;i++){
			s += Math.random();
		}
		return (sigma*(s-6)+mu);
	}
	
	//Normalverteilung ohne negative Werte
	public static double normalVerteiltABS(double sigma, double mu){
		return Math.abs(normalVerteilt(sigma, mu));
	}
	
	
	//Normalverteilung ohne negative Werte und mit Minimum
	public static double normalVerteiltMitMinimum(double sigma, double mu, double min, double max){
		double ergebnis = normalVerteiltABS(sigma,mu);
		if(ergebnis > min && ergebnis < max){
			return ergebnis;
		}
		else{
			for(int i=0;i<10;i++){
				ergebnis = normalVerteiltABS(sigma,mu);
				
				if(ergebnis > min && ergebnis < max)
					return ergebnis;
			}
			
			return min;
		}
	}
	
	//n = Anzahl der Versuche
	//p = Erfolgswahrscheinlichkeit
	public static int binomialVerteilt(int n, double p){
		int ergebnis=0;
		for(int i=0; i<n; i++){
			if(Math.random() <= p){
				ergebnis++;
			}
		}
		return ergebnis;
	}
	
	public static int poisssonVerteilt(double lambda){
		int zaehler = 0;
		double e = Math.exp(-lambda);
		double product = 1.0 - Math.random();
		while (product >= e){
			zaehler++;
			product *= 1 - Math.random();
		}
		return zaehler;
	}

}
