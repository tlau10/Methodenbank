/*
 * Created on 25.09.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

import java.util.Vector;

import rechtsVorLinks.RechtsVorLinks;
import rechtsVorLinks.RechtsVorLinksEinstellungen;

import ampelGross.AmpelGross;
import ampelGross.AmpelGrossEinstellungen;
import ampelKlein.AmpelKlein;
import ampelKlein.AmpelKleinEinstellungen;
import ampelMittel.AmpelMittel;
import ampelMittel.AmpelMittelEinstellungen;
import ampelTyp2.*;
import vorfahrt.*;
import kreisverkehrTyp2.*;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Factory {

	private Vector liste;
	private Simulationslogik logik;
	private Vector kreuzungsListe;

	public Factory(){
		liste = new Vector();
		logik = new Simulationslogik();
		kreuzungsListe = new Vector();
	}
	
	public void startSimulation(Vector einstellungen, double dauer, AllgemeineEinstellungen a){
		if(initalisiereSimulation(einstellungen, dauer,a))
			logik.starteSimulation();
	}
	
	public Status naechstesEreignis(){
		return logik.naechstesEreignis();
	}
	
	public double getZeit(){
		return logik.getZeit();
	}
	
	public Vector auswertung(){
		Vector ergebnis = new Vector();
		for(int i=0;i<kreuzungsListe.size();i++){
			ergebnis.add(((Kreuzung)kreuzungsListe.get(i)).getErgebnis());
		}
		return ergebnis;
	}
	
	public boolean initalisiereSimulation(Vector einstellungen, double dauer, AllgemeineEinstellungen all){
		logik.initialisiereSimulation(dauer);
		
		if(einstellungen.size() == 0){
			System.err.println("Fehler: Es wurden keine Daten f�r die Simulation �bergeben");
			return false;
		}
		
		//Alle Abschnitte erstellen
		for(int i=0;i<einstellungen.size();i++){
			
			EinstellungsDaten daten = (EinstellungsDaten) einstellungen.get(i);
			Simulationsabschnitt a=null;
			
			if(daten.getType().equals("AmpelTyp2Einstellungen")){
				a = new AmpelTyp2((AmpelTyp2Einstellungen)daten);
				kreuzungsListe.add(a);
			}
			else if(daten.getType().equals("AmpelKleinEinstellungen")){
				a = new AmpelKlein((AmpelKleinEinstellungen)daten);
				kreuzungsListe.add(a);
			}
			else if(daten.getType().equals("AmpelMittelEinstellungen")){
				a = new AmpelMittel((AmpelMittelEinstellungen)daten);
				kreuzungsListe.add(a);
			}
			else if(daten.getType().equals("AmpelGrossEinstellungen")){
				a = new AmpelGross((AmpelGrossEinstellungen)daten);
				kreuzungsListe.add(a);
			}
			else if(daten.getType().equals("NormaleStrasseEinstellungen")){
				a = new NormaleStrasse((NormaleStrasseEinstellungen)daten);
			}
			else if(daten.getType().equals("QuelleEinstellungen")){
				a = new Quelle((QuelleEinstellungen)daten, all);
			}
			else if(daten.getType().equals("SenkeEinstellungen")){
				a = new Senke((SenkeEinstellungen)daten);
			}
			else if(daten.getType().equals("KreisverkehrTyp2Einstellungen")){
				a = new KreisverkehrTyp2((KreisverkehrTyp2Einstellungen)daten);
				kreuzungsListe.add(a);
			}
			else if(daten.getType().equals("RechtsVorLinksEinstellungen")){
				a = new RechtsVorLinks((RechtsVorLinksEinstellungen)daten);
				kreuzungsListe.add(a);
			}
			else if(daten.getType().equals("VorfahrtEinstellungen")){
				a = new Vorfahrt((VorfahrtEinstellungen)daten);
				kreuzungsListe.add(a);
			}
			else{
				System.err.println("Unbekannter Datentyp: "+daten.getType());
				return false;
			}
			
			liste.add(a);
		}
		
		//initialisieren der Simulationsabschnitte
		for(int i=0;i<liste.size();i++){
			Simulationsabschnitt b = (Simulationsabschnitt) liste.get(i);
			
			b.setSimulationslogik(logik);
			
			EinstellungsDaten daten = (EinstellungsDaten) einstellungen.get(i);
			
			//Alles miteinander verbinden
			for(int j=0;j<b.getMaxAnbindungen();j++){
//				System.err.println("ID: "+b.getID()+" i:"+i+" j:"+j+" MAX:"+b.getMaxAnbindungen());
				b.addAnbindung(sucheAbschnittNachId(daten.getAnbindungen()[j]),j);
			}
		}
		
		for(int i=0;i<liste.size();i++){
			Simulationsabschnitt b = (Simulationsabschnitt) liste.get(i);
			if(!b.pruefeInitalisierung()){
				System.err.println("Fehler beim Initialisieren aufgetreten");
				System.err.println("ID"+b.getID()+" Typ"+b.getTyp());
				return false;
			}
		}
		return true;
	}
	
	private Simulationsabschnitt sucheAbschnittNachId(int id){
		for(int i=0;i<liste.size();i++){
			if(((Simulationsabschnitt)liste.get(i)).getID() == id){
				return ((Simulationsabschnitt)liste.get(i));
			}
		}
		
		//System.err.println("Es konnte kein Simualtionsabschnitt mit der ID "+id+" gefunden werden");
		return null;
	}
}
