/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface Simulationsabschnitt {
	void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung);
	void ereignisHandler(Ereignis e);
	void ankunft(Fahrzeug f);
	double getMaxGeschwindigkeit(Simulationsabschnitt aufrufer, Fahrzeug f);
	boolean pruefeInitalisierung();
	String getTyp();
	int getID();
	int getMaxAnbindungen();
	void setSimulationslogik(Simulationslogik logik);
	boolean isBlockiert(Simulationsabschnitt aufrufer);
	void setBlockiert(Simulationsabschnitt aufrufer, double zeit);
	void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit);
	double getLaengeFuerWS(Simulationsabschnitt aufrufer);
	Status getStatus();
}
