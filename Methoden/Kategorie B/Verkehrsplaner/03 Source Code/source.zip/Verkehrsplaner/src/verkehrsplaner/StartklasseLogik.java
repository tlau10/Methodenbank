/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;


/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class StartklasseLogik {

	public static void main(String[] args) {
//		Simulationslogik logik = new Simulationslogik();
//		Senke senke1 = new Senke(1);
//		Senke senke2 = new Senke(2);
//		Senke senke3 = new Senke(3);
//		Quelle quelle = new Quelle(0,10.0,2.0);
//		KreisverkehrTyp2Einstellungen daten = new KreisverkehrTyp2Einstellungen();
//		daten.setId(4);
//		KreisverkehrTyp2 ampel = new KreisverkehrTyp2(daten);
//		
//		
//		int[] i = new int[2];
//		i[0] = 1;
//		i[1] = 1;
//		NormaleStrasse strasse1 = new NormaleStrasse(5, 250, i, 50);
//		NormaleStrasse strasse2 = new NormaleStrasse(6, 250, i, 50);
//		NormaleStrasse strasse3 = new NormaleStrasse(7, 250, i, 50);
//		NormaleStrasse strasse4 = new NormaleStrasse(8, 250, i, 50);
//		
//		senke1.setSimulationslogik(logik);
//		senke2.setSimulationslogik(logik);
//		senke3.setSimulationslogik(logik);
//		quelle.setSimulationslogik(logik);
//		ampel.setSimulationslogik(logik);
//		strasse1.setSimulationslogik(logik);
//		strasse2.setSimulationslogik(logik);
//		strasse3.setSimulationslogik(logik);
//		strasse4.setSimulationslogik(logik);
//		
//		quelle.addAnbindung(strasse1,0);
//		senke1.addAnbindung(strasse2,0);
//		senke2.addAnbindung(strasse3,0);
//		senke3.addAnbindung(strasse4,0);
//		strasse1.addAnbindung(quelle,0);
//		strasse1.addAnbindung(ampel,1);
//		strasse2.addAnbindung(senke1,0);
//		strasse2.addAnbindung(ampel,1);
//		strasse3.addAnbindung(senke2,0);
//		strasse3.addAnbindung(ampel,1);
//		strasse4.addAnbindung(senke3,0);
//		strasse4.addAnbindung(ampel,1);
//		ampel.addAnbindung(strasse1,0);
//		ampel.addAnbindung(strasse2,1);
//		ampel.addAnbindung(strasse3,2);
//		ampel.addAnbindung(strasse4,3);
//		
//		if(!quelle.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Quelle");
//		}
//		if(!senke1.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Senke1");
//		}
//		if(!senke2.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Senke2");
//		}
//		if(!senke3.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Senke3");
//		}
//		if(!strasse1.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Strasse1");
//		}
//		if(!strasse2.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Strasse2");
//		}
//		if(!strasse3.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Strasse3");
//		}
//		if(!strasse4.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Strasse4");
//		}
//		if(!ampel.pruefeInitalisierung()){
//			System.err.println("Fehler beim Initalisieren: Kreisel");
//		}
//		
//		logik.initialisiereSimulation(1000.0);
//		logik.starteSimulation();//*/
	}
}
