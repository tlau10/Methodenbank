/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Quelle implements Simulationsabschnitt {
	private int id;
	//Eventl. einen Weg finden eine passendere Geschw. zu finden. //TODO
	private double maxV=50.0;
	private Simulationsabschnitt anbindung;
	private Simulationslogik logik;
	//private double mu;
	private int k=2;
	private double lambda;
//	private double erwartungswert;
	private QuelleEinstellungen daten;
	private int letztesEvent=0;
	private AllgemeineEinstellungen aE = new AllgemeineEinstellungen();
	
	public Quelle(int id, double lambda, int k, AllgemeineEinstellungen aE){
		this.id = id;
		this.lambda = lambda;
//		this.mu = mu;
		this.k = k;
		if(aE == null)
			System.err.println("Fehler: Falsche �bergabe der Allgemeinen Einstellungen");
		else
			this.aE = aE;
	}
	
	public Quelle(QuelleEinstellungen daten, AllgemeineEinstellungen aE){
		this.daten = daten;
		id = daten.getId();
		if(daten.getErwartungswert() < 0.01){//Wenn mehr als 100 Autos/pro Sekunde
			System.err.println("Ankunftsrate bei Quelle "+id+" zu hoch");
			lambda = 0.05;
		}
		else{
			lambda = daten.getK() / daten.getErwartungswert();
		}
		this.k = daten.getK();
//		mu = daten.getStandardabweichung();
		if(aE == null)
			System.err.println("Fehler: Falsche �bergabe der Allgemeinen Einstellungen");
		else
			this.aE = aE;
	}
	
	public void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung) {
		if (himmelsrichtung == 0){
			this.anbindung = anbindung;
		}
		else{
			System.err.println("Fehlerhafte Zuweisung - Quelle "+id+" Richtung:"+himmelsrichtung);
		}
	}

	public void ereignisHandler(Ereignis e) {
		if(e.getTyp().equals("ankunft")){ //Quelle muss auch die Funktion einer Senke �bernehmen
			ankunft(e.getFahrzeug());
			letztesEvent=1;
		}
		else if(e.getTyp().equals("neuesFahrzeug")){
			neuesFahrzeug(e.getFahrzeug());
			letztesEvent=2;
		}
		else{
			System.err.println("Unbekanntes Ereignis (Quelle: "+id+") " + e.getTyp());
		}
	}
	
	private void neuesFahrzeug(Fahrzeug f){	// <-----------------------------------------------------!!!!
		if(f != null){
			//Fahrzeug an die angebundene Stra�e abgeben
			f.setStartZeitpunkt(logik.getZeit());
			anbindung.getMaxGeschwindigkeit(this,f); //Auto vorank�ndigen
			Ereignis e = new Ereignis(logik.getZeit(), f, "ankunft", anbindung);
			logik.pushEreignis(e);
		}
		//Neues Fahrzeug planen				//TODO Hier muss noch was angepasst werden
		double laenge;
		double beschleunigung;
		double bremsen;
		double horizontalBeschl;
		
		if(Zufallszahlen.drand() < daten.getProzentuallerAnteilLKWs()){	//LKW
			laenge = Zufallszahlen.normalVerteiltMitMinimum(aE.getLkwLaengeErwartungswert(),aE.getLkwLaengeStandardabweichung(),
					aE.getLkwLaengeMin(), aE.getLkwLaengeMax());
			
			beschleunigung = Zufallszahlen.normalVerteiltMitMinimum(
					aE.getLkwBeschleunigungsErwartungswert(),aE.getLkwBeschleunigungsStandardabweichung(),
					aE.getLkwBeschleunigungMin(),aE.getLkwBeschleunigungMax());
			
			bremsen = Zufallszahlen.normalVerteiltMitMinimum(
					aE.getLkwBremsenErwartungswert(),aE.getLkwBremsenStandardabweichung(),
					aE.getLkwBremsenMin(),aE.getLkwBremsenMax());
			
			horizontalBeschl = Zufallszahlen.normalVerteiltMitMinimum(
					aE.getLkwHorizontaleBeschlErwartungswert(),aE.getLkwHorizontaleBeschlStandardabweichung(),
					aE.getLkwHorizontaleBeschlMin(),aE.getLkwHorizontaleBeschlMax());
		}
		else{ //PKW
			laenge = Zufallszahlen.normalVerteiltMitMinimum(aE.getPkwLaengeErwartungswert(),aE.getPkwLaengeStandardabweichung(),
					aE.getPkwLaengeMin(), aE.getPkwLaengeMax());
			
			beschleunigung = Zufallszahlen.normalVerteiltMitMinimum(
					aE.getPkwBeschleunigungsErwartungswert(),aE.getPkwBeschleunigungsStandardabweichung(),
					aE.getPkwBeschleunigungMin(),aE.getPkwBeschleunigungMax());
			
			bremsen = Zufallszahlen.normalVerteiltMitMinimum(
					aE.getPkwBremsenErwartungswert(),aE.getPkwBremsenStandardabweichung(),
					aE.getPkwBremsenMin(),aE.getPkwBremsenMax());
			
			horizontalBeschl = Zufallszahlen.normalVerteiltMitMinimum(
					aE.getPkwHorizontaleBeschlErwartungswert(),aE.getPkwHorizontaleBeschlStandardabweichung(),
					aE.getPkwHorizontaleBeschlMin(),aE.getPkwHorizontaleBeschlMax());
		}
		
		double geschwindigkeit=daten.getAnkunftsGeschwindigkeit();
		Fahrzeug a = new Auto(logik.getFahrzeugId(), logik.getZeit(), 
				laenge, beschleunigung,bremsen,horizontalBeschl, geschwindigkeit, this);
		
		
		//Ankunftstermin f�r das Fahrzeug bestimmen // Erlang-Verteilung
		double ankunftsZeitpunkt = Zufallszahlen.erlangVerteilt(k, lambda) + logik.getZeit();
//		double ankunftsZeitpunkt = Zufallszahlen.normalVerteiltABS(erwartungswert,mu) + logik.getZeit();
		Ereignis e = new Ereignis(ankunftsZeitpunkt, a, "neuesFahrzeug", this);
		logik.pushEreignis(e);
	}
	

	public void ankunft(Fahrzeug f) {
		// Statistische Auswertungen: Fahrzeuge
		f.setStandort(this);
//		System.out.println("Fahrzeug " +f.getID()+" erreicht Quelle "+id+" um "+logik.getZeit()+" Dauer: "+(logik.getZeit()-f.getStartZeitpunkt()));
	}

	public double getMaxGeschwindigkeit(Simulationsabschnitt aufrufer, Fahrzeug f) {
		return maxV;
	}

	public boolean pruefeInitalisierung() {
		if(anbindung != null && logik != null){
			if(((NormaleStrasse)anbindung).getAnzahlSpurenVonKreuzungWeg(daten.getId())>0){
				neuesFahrzeug(null);
				return true;
			}
			else{
				System.err.println("Fehler: Von "+daten.getName()+" kann kein Fahrzeug in das System einfahren");
			}
		}

		return false;

	}
	
	public void setSimulationslogik(Simulationslogik logik){
		this.logik = logik;
	}

	public String getTyp() {
		return "Quelle";
	}

	public int getID() {
		return id;
	}

	public int getMaxAnbindungen() {
		return 1;
	}

	public boolean isBlockiert(Simulationsabschnitt aufrufer) {
		// TODO Auto-generated method stub
		return false;
	}

	public void setBlockiert(Simulationsabschnitt aufrufer, double zeit) {
		// TODO Auto-generated method stub
		
	}

	public void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit) {
		// TODO Auto-generated method stub
		
	}

	public double getLaengeFuerWS(Simulationsabschnitt aufrufer) {
		// TODO Auto-generated method stub
		return 1.0;
	}

	public Status getStatus() {
		Status s = new Status(id);
		s.setAnzahlWS(0);		//TODO sp�ter �ndern
		//s.setBlockiert(false);	//TODO sp�ter �ndern
		if(letztesEvent == 1){
			s.setAnkunft(true);
		}
		else if(letztesEvent == 2){
			s.setNeuesFahrzeug(true);
		}
		return s;
	}
	
	
	
}
