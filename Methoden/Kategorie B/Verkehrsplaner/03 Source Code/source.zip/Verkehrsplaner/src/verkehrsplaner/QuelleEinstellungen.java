/*
 * Created on 25.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class QuelleEinstellungen implements java.io.Serializable, EinstellungsDaten {

	private static final long serialVersionUID = 1L;
	
	private int id=0;
	private String name = "Quelle";
	private int[] anbindungen = {-1};
	private double erwartungswert = 5.0;
//	private double standardabweichung = 1.0;
	private int k=2;
	private String type="QuelleEinstellungen";
	private double ankunftsGeschwindigkeit = 50.0;
	
	private double prozentuallerAnteilLKWs = 0.1;

	//GUI
	private int x=100;
	private int y=100;
	
	public QuelleEinstellungen(){
	}

	public double getAnkunftsGeschwindigkeit() {
		return ankunftsGeschwindigkeit;
	}

	public void setAnkunftsGeschwindigkeit(double ankunftsGeschwindigkeit) {
		this.ankunftsGeschwindigkeit = ankunftsGeschwindigkeit;
	}
	public double getErwartungswert() {
		return erwartungswert;
	}

	public void setErwartungswert(double erwartungswert) {
		this.erwartungswert = erwartungswert;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public double getStandardabweichung() {
//		return standardabweichung;
//	}
//
//	public void setStandardabweichung(double standardabweichung) {
//		this.standardabweichung = standardabweichung;
//	}

	public String getType() {
		return type;
	}
	
	public int[] getAnbindungen() {
		return anbindungen;
	}

	public void setAnbindungen(int[] anbindungen) {
		this.anbindungen = anbindungen;
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public double getProzentuallerAnteilLKWs() {
		return prozentuallerAnteilLKWs;
	}
	public void setProzentuallerAnteilLKWs(double prozentuallerAnteilLKWs) {
		this.prozentuallerAnteilLKWs = prozentuallerAnteilLKWs;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}
	
}
