/*
 * Created on 25.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class NormaleStrasseEinstellungen implements java.io.Serializable, EinstellungsDaten{

	private static final long serialVersionUID = 1L;
	
	private int id=0;
	private String name = "Strasse";
	private double maxV = 50.0;
	private double laenge = 100.0;
	private int[] fahrspuren = {1,1};
	private int[] anbindungen = {-1,-1};
	private String type="NormaleStrasseEinstellungen";
	
//	GUI
	private int kurveX=-1;
	private int kurveY=-1;
	private double fahrzeugeProMinute=20;
	private int strassenArt=0;
	private int[] konnektoren = {-1,-1};

	public NormaleStrasseEinstellungen(){
	}
	
	public int[] getFahrspuren() {
		return fahrspuren;
	}

	public void setFahrspuren(int[] fahrspuren) {
		this.fahrspuren = fahrspuren;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getLaenge() {
		return laenge;
	}

	public void setLaenge(double laenge) {
		this.laenge = laenge;
	}

	public double getMaxV() {
		return maxV;
	}

	public void setMaxV(double maxV) {
		this.maxV = maxV;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public int[] getAnbindungen() {
		return anbindungen;
	}

	public void setAnbindungen(int[] anbindungen) {
		this.anbindungen = anbindungen;
	}
	
	public int getKurveX() {
		return kurveX;
	}
	public void setKurveX(int kurveX) {
		this.kurveX = kurveX;
	}
	public int getKurveY() {
		return kurveY;
	}
	public void setKurveY(int kurveY) {
		this.kurveY = kurveY;
	}
	public double getFahrzeugeProMinute() {
		return fahrzeugeProMinute;
	}
	public void setFahrzeugeProMinute(double fahrzeugeProMinute) {
		this.fahrzeugeProMinute = fahrzeugeProMinute;
	}
	public int getStrassenArt() {
		return strassenArt;
	}
	public void setStrassenArt(int strassenArt) {
		this.strassenArt = strassenArt;
	}
	public int[] getKonnektoren() {
		return konnektoren;
	}
	public void setKonnektoren(int[] konnektoren) {
		this.konnektoren = konnektoren;
	}
}
