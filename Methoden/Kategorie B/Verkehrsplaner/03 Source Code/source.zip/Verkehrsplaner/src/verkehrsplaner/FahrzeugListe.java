/*
 * Created on 18.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

import java.util.LinkedList;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FahrzeugListe {
	private LinkedList liste = new LinkedList();
	
	public void push(Fahrzeug f){		
		liste.addLast(f);
		return;
	}
	
//	public Fahrzeug pop(){
//		Fahrzeug f = (Fahrzeug)liste.getFirst();
//		liste.removeFirst();
//		return f;
//	}
	
//	public Fahrzeug sucheFahrzeugNachID(double id){
//		Fahrzeug f;
//		for(int i=0;i<liste.size();i++){
//			f = (Fahrzeug)liste.get(i);
//			if(f.getID() == id){
//				return f;
//			}
//		}
//		return null;
//	}
	
//	public boolean loescheFahrzeugNachID(double id){
//		Fahrzeug f;
//		for(int i=0;i<liste.size();i++){
//			f = (Fahrzeug)liste.get(i);
//			if(f.getID() == id){
//				liste.remove(i);
//				return true;
//			}
//		}
//		return false;
//	}
	
	public Fahrzeug holeFahrzeugAusListeNachID(double id){
		Fahrzeug f;
		for(int i=0;i<liste.size();i++){
			f = (Fahrzeug)liste.get(i);
			if(f.getID() == id){
				liste.remove(i);
				return f;
			}
		}
		return null;
	}
	
	public Fahrzeug zeigeFahrzeugAusListeNachID(double id){
		Fahrzeug f;
		for(int i=0;i<liste.size();i++){
			f = (Fahrzeug)liste.get(i);
			if(f.getID() == id){
				return f;
			}
		}
		return null;
	}
}
