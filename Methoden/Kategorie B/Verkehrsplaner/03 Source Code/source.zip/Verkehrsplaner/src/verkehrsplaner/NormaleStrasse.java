/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

import java.util.LinkedList;


/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class NormaleStrasse implements Simulationsabschnitt {
	private int id;
	private double maxV;
	private Simulationsabschnitt[] anbindung;
	private Simulationslogik logik;
	private int[] anzahlFahrzeuge;
	private double[] gesamtLaengeFahrzeuge;
	private double[] letztesBedienEnde;
	private double laenge;
	private int[] fahrspuren;
	private boolean[] ueberholenErlauben;
	private Physik physik;
	private LinkedList ankunftsZeitpunktBei0 = new LinkedList();
	private LinkedList ankunftsZeitpunktBei1 = new LinkedList();
	private LinkedList ankunftsFahrzeugBei0 = new LinkedList();
	private LinkedList ankunftsFahrzeugBei1 = new LinkedList();
	
	
	private NormaleStrasseEinstellungen daten;
	
	//Variablen f�r das blockade System
	private boolean[] blockiert;
	
	
	public NormaleStrasse(int id, double laenge, int[] fahrspuren, double maxV){
		physik = new Physik();
		anbindung = new Simulationsabschnitt[2];
		anzahlFahrzeuge = new int[2];
		gesamtLaengeFahrzeuge = new double[2];
		letztesBedienEnde = new double[2];
		ueberholenErlauben = new boolean[2];
		blockiert = new boolean[2];
		this.fahrspuren = new int[2];
		
		for(int i=0;i<2;i++){
			anzahlFahrzeuge[i] = 0;
			gesamtLaengeFahrzeuge[i] = 0.0;
			letztesBedienEnde[i] = 0.0;
			
			if(fahrspuren[i] >1){
				ueberholenErlauben[i] = true;
			}
			else{
				ueberholenErlauben[i] = false;
			}
			blockiert[i] = false;
		}
		
		this.id = id;
		this.laenge = laenge;
		this.fahrspuren[0] = fahrspuren[0];
		this.fahrspuren[1] = fahrspuren[1];
		this.maxV = maxV;
	}
	
	public NormaleStrasse(NormaleStrasseEinstellungen daten){
		this(daten.getId(),daten.getLaenge(),daten.getFahrspuren(),daten.getMaxV());
		this.daten = daten;
	}

	public void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung) {
		if(himmelsrichtung == 0){
			this.anbindung[0] = anbindung;
		}
		else if(himmelsrichtung == 1){
			this.anbindung[1] = anbindung;
		}
		else{
			System.err.println("Fehlerhafte Zuweisung - Stra�e "+id+" Richtung:"+himmelsrichtung);
		}
	}

	public void ereignisHandler(Ereignis e) {
		if(e.getTyp().equals("ankunft")){ //Quelle muss auch die Funktion einer Senke �bernehmen
			ankunft(e.getFahrzeug());
		}
		else if(e.getTyp().equals("bedienEnde0")){
			bedienEnde(0,e.getFahrzeug());
		}
		else if(e.getTyp().equals("bedienEnde1")){
			bedienEnde(1,e.getFahrzeug());
		}
		else{
			System.err.println("Unbekanntes Ereignis (normaleStrasse: "+id+") " + e.getTyp());
		}
	}
	
	private void bedienEnde(int richtung, Fahrzeug f){
		anzahlFahrzeuge[richtung]--;
		gesamtLaengeFahrzeuge[richtung] -= f.getLaengeInMeter();
		Ereignis e;
		
		if(richtung == 0){
			e = new Ereignis(logik.getZeit(), f, "ankunft", anbindung[1]);
			ankunftsZeitpunktBei1.removeFirst();
			ankunftsFahrzeugBei1.removeFirst();
		}
		else{
			e = new Ereignis(logik.getZeit(), f, "ankunft", anbindung[0]);
			ankunftsZeitpunktBei0.removeFirst();
			ankunftsFahrzeugBei0.removeFirst();
		}
		logik.pushEreignis(e);
	}

	public void ankunft(Fahrzeug f) {
		Simulationsabschnitt herkunft = f.getStandort();
		double zielV;
		String ereignisName;
		int herkunftsNummer;
		
		if(herkunft == anbindung[0]){ //F�hrt von 0 nach 1
			ereignisName = "bedienEnde0";
			zielV = anbindung[1].getMaxGeschwindigkeit(this,f);
			herkunftsNummer = 0;
		}
		else if(herkunft == anbindung[1]){
			ereignisName = "bedienEnde1";
			zielV = anbindung[0].getMaxGeschwindigkeit(this,f);
			herkunftsNummer = 1;
		}
		else{
			System.err.println("herkunft: " + f.getStandort());
			System.err.println("anbindung0: " + anbindung[0]);
			System.err.println("anbindung1: " + anbindung[1]);
			System.err.println("Fehlerhafte Herkunft - Stra�e "+id+" Fahrzeug:"+f.getID());
			return;
		}
		anzahlFahrzeuge[herkunftsNummer]++;
		gesamtLaengeFahrzeuge[herkunftsNummer] += f.getLaengeInMeter();
		f.setStandort(this);
		
		//Zeitbedarf ermitteln
		double zeitBedarf = physik.zeitBerechnen(laenge, maxV, zielV, f);
		double ankunftZeit = logik.getZeit()+zeitBedarf;
		
		//�berholen verhindern
		if (ankunftZeit < letztesBedienEnde[herkunftsNummer] && !ueberholenErlauben[herkunftsNummer]){
			ankunftZeit = letztesBedienEnde[herkunftsNummer] + 1.0; //Sicherheitsabstand 1 sekunde
		}											//Fahrschulregel innerorts 1 Sekunde Ausserorts 2-3 Sekunden
		letztesBedienEnde[herkunftsNummer] = ankunftZeit;
		
		if(herkunftsNummer == 0){
			Double tmp = new Double(ankunftZeit);
			ankunftsZeitpunktBei1.addLast(tmp);
			ankunftsFahrzeugBei1.addLast(f);
		}
		else{
			Double tmp = new Double(ankunftZeit);
			ankunftsZeitpunktBei0.addLast(tmp);
			ankunftsFahrzeugBei0.addLast(f);
		}
			
		
		Ereignis e = new Ereignis(ankunftZeit, f, ereignisName, this);
		logik.pushEreignis(e);
	}
	
	public double getLaengeFahrzeuge(Simulationsabschnitt aufrufer, double abstand){
		if(aufrufer == anbindung[0]){
			return anzahlFahrzeuge[1]*abstand +gesamtLaengeFahrzeuge[1];
		}
		else if(aufrufer == anbindung[1]){
			return anzahlFahrzeuge[0]*abstand +gesamtLaengeFahrzeuge[0];
		}
		
		return 0.0;
	}
	
	//Funktion um den n�chsten Ankunftszeitpunkt eines Fahrzeugs ermitteln
	public double getNaechstenAnkunftZeitpunkt(Simulationsabschnitt aufrufer){
		if(aufrufer == anbindung[0] && ankunftsZeitpunktBei0.size() > 0){
			return ((Double)ankunftsZeitpunktBei0.getFirst()).doubleValue();
		}
		else if(aufrufer == anbindung[1] && ankunftsZeitpunktBei1.size() > 0){
			return ((Double)ankunftsZeitpunktBei1.getFirst()).doubleValue();
		}
		
		return -1.0;//Falls keins geplant
	}
	
	//Funktion um die ID des n�chsten ankommenden Fahrzeugs zu ermitteln
	public int getNaechstenAnkunftID(Simulationsabschnitt aufrufer){
		if(aufrufer == anbindung[0] && ankunftsFahrzeugBei0.size() > 0){
			return ((Fahrzeug)ankunftsFahrzeugBei0.getFirst()).getID();
		}
		else if(aufrufer == anbindung[1] && ankunftsFahrzeugBei1.size() > 0){
			return ((Fahrzeug)ankunftsFahrzeugBei1.getFirst()).getID();
		}
		
		return -1;//Falls keins geplant
	}
	
	
	//Funktion um Einbahnstrassen zu ermitteln
	public int getAnzahlSpurenVonKreuzungWeg(int anbindungID){
    	if(anbindungID == daten.getAnbindungen()[0]){
    		return daten.getFahrspuren()[0];
    	}
    	else if(anbindungID == daten.getAnbindungen()[1]){
    		return daten.getFahrspuren()[1];
    	}
    	
    	return 0;
    }
	
	//Funktion um Einbahnstrassen zu ermitteln
	public int getAnzahlSpurenZurKreuzung(int anbindungID){
    	if(anbindungID == daten.getAnbindungen()[0]){
    		return daten.getFahrspuren()[1];
    	}
    	else if(anbindungID == daten.getAnbindungen()[1]){
    		return daten.getFahrspuren()[0];
    	}
    	
    	return 0;
    }

	public double getMaxGeschwindigkeit(Simulationsabschnitt aufrufer, Fahrzeug f) {
		return maxV;
	}

	public boolean pruefeInitalisierung() {
		if(anbindung[0] != null && anbindung[1] != null && logik != null){
			return true;
		}
		return false;
	}

	public String getTyp() {
		return "normaleStrasse";
	}

	public int getID() {
		return id;
	}

	public int getMaxAnbindungen() {
		return 2;
	}


	public void setSimulationslogik(Simulationslogik logik) {
		this.logik = logik;
	}

	//Wird von der Kreuzung in welche Fahrzeuge in die Stra�e einfahren wollen aufgerufen
	public boolean isBlockiert(Simulationsabschnitt aufrufer) {
		if(aufrufer == anbindung[0]){							
			return blockiert[0];
		}
		else if (aufrufer == anbindung[1]){
			return blockiert[1];
		}
		return false;
	}

	//Wird von der Kreuzung in welche die Strasse m�ndet aufgerufen
	public void setBlockiert(Simulationsabschnitt aufrufer, double zeit) {
		if(aufrufer == anbindung[0]){									
			blockiert[1] = true;
		}
		else if (aufrufer == anbindung[1]){
			blockiert[0] = true;
		}
//		System.err.println("Blockade Strasse "+id+" Richtung:"+aufrufer.getID());
	}

	
	//Wird von der Kreuzung in welche die Strasse m�ndet aufgerufen
	public void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit) {
		int i=-1;
		if(aufrufer == anbindung[0]){
			i=1;
		}
		else if (aufrufer == anbindung[1]){
			i=0;
		}
		
		if(i>-1){
			blockiert[i] = false;
			anbindung[i].blockadeAufheben(this,zeit); //Blockade aufheben weiter geben
		}
		else{
			System.err.println("Blockade Aufruf: Unbekannter Aufrufer: "+aufrufer.getID());
		}
	}
	
	

	//L�nge der m�glichen WS in die Richtung des Aufrufers
	public double getLaengeFuerWS(Simulationsabschnitt aufrufer) {
		if(aufrufer == anbindung[0]){
			return Math.abs(laenge*fahrspuren[1]);
		}
		else if (aufrufer == anbindung[1]){
			return Math.abs(laenge*fahrspuren[0]);
		}
		System.err.println("Unbekannter Aufrufer");
		return 1.0;
	}

	public Status getStatus() {
		Status s = new Status(id);
		s.setAnzahlWS(0);
		s.setBlockiert(blockiert);
//		s.setBlockiert(false);
//		for(int i=0;i<2;i++){
//			if(blockiert[i]){
//				s.setBlockiert(true);
//			}
//		}
		return s;
	}

}
