/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;



/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Simulationslogik {
	//Diese Klasse enth�lt die Logik f�r die ereignisorientierte Simulation
	private EreignisListe liste;

	private double zeit;
	private double simulationsDauer=0.0;
	private int fahrzeugZaehler;
	private double letztesEreignis=-1.0;
	private Ereignis lastEreignis = null;
	
	
	public Simulationslogik(){
		liste = new EreignisListe();
		fahrzeugZaehler = 0;
	}
	
	public void pushEreignis(Ereignis e){
		//TODO Hier kontrollieren, was das Fehlerhafte Ereignis pusht (Ereignis)
		// und auflistung der in der Liste befindelichen Ereignisse
		//Eventl. Problem mit Blocakde System ???
		liste.push(e);
	}
	
	public void starteSimulation(){
//		initialisiereSimulation(simulationsDauer);
		
		while(zeit < simulationsDauer){
			Ereignis e=liste.pop();
			zeit = e.getZeitpunkt();
			e.getStandort().ereignisHandler(e);
		}
		
		liste = new EreignisListe();//Alte Ereignisliste l�schen
	}
	
	public void initialisiereSimulation(double simulationsDauer){
//		liste = new EreignisListe(); Quellen werden vorher initialsisiert
		this.simulationsDauer = simulationsDauer;
		zeit = 0.0;
		//Quellen pushen selbst ihre initialEreignisse
	}
	
	public Status naechstesEreignis(){
		Status s=null;
		
		if(zeit<simulationsDauer){
			Ereignis e=liste.pop();
			if(e.getZeitpunkt() < zeit){
				System.err.println("Fehler: Ereignis liegt in der Vergangenheit / LETZTES EREIGNIS");
				System.err.println(lastEreignis.getStandort().getTyp()+":"+lastEreignis.getStandort().getID()+" Typ:"+lastEreignis.getTyp());
			}
			
			zeit = e.getZeitpunkt();
			e.getStandort().ereignisHandler(e);
			s = e.getStandort().getStatus();
			
			if(letztesEreignis > zeit){
				System.err.println("Fehler: Ereignis liegt in der Vergangenheit "+letztesEreignis+">"+zeit);
				System.err.println(e.getStandort().getTyp()+":"+e.getStandort().getID()+" Typ:"+e.getTyp());
			}
			lastEreignis = e;
		}
		
		letztesEreignis=zeit;
		return s;
	}
	
//	public void auswertung(){
//		//Sammeln aller Ergebnisse aller Kreuzungen -> Auswertung
//		liste = new EreignisListe(); //Alte EreignisListe l�schen
//	}
	
	public double getZeit(){
		return zeit;
	}
	
	public int getFahrzeugId(){
		if(fahrzeugZaehler > 2000000000){
			fahrzeugZaehler = 0;
			System.err.println("Achtung: Fahrzeugz�hler musste zurueckgesetzt werden");
		}
		return fahrzeugZaehler++;
	}
}
