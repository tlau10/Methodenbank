package verkehrsplaner;
/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Auto implements Fahrzeug{
	private int id;
	private double startZeitpunkt;
	private Simulationsabschnitt standort;
	private double laenge;
	private double a;
	private double v;
	private double b;
	private double h;
	private double v_old;

	public Auto(int id, double startZeitpunkt, 
			double laenge, double beschleunigung, double bremsen, double hBeschl, 
			double geschwindigkeit, Simulationsabschnitt standort){
		this.id = id;
		this.startZeitpunkt = startZeitpunkt;
		this.laenge = laenge;
		this.a = beschleunigung;
		this.b = bremsen;
		this.h = hBeschl;
		this.v = geschwindigkeit;
		this.v_old = v;
		this.standort = standort;
	}
	
	public int getID() {
		return id;
	}

	public double getStartZeitpunkt() {
		return startZeitpunkt;
	}
	
	public void setStartZeitpunkt(double startZeit){
		this.startZeitpunkt = startZeit;
	}

	public Simulationsabschnitt getStandort() {
		return standort;
	}

	public double getLaengeInMeter() {
		return laenge;
	}

	public double getBeschleunigung() {
		return a;
	}

	public double getGeschwindigkeit() {
		return v;
	}

	public void setStandort(Simulationsabschnitt s) {
		standort = s;
	}

	public void setGeschwindigkeit(double v) {
		v_old = this.v;
		this.v = v;
	}

	public String getTyp(){
		return "Auto";
	}

	public double getBremsbeschleunigung() {
		return b;
	}

	public double getHorizontaleBeschleunigung() {
		return h;
	}

	public double getLetzteGeschwindigkeit() {
		return v_old;
	}

}
