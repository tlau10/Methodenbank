/*
 * Created on 21.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class WarteschlangeErgebnis {
	private int anzahlFahrzeuge=0;
	private int maxAnzahlFahrzeuge=0;
	private int abgefertigteFahrzeuge=0;
	private double durchsWartendeFahrzeuge=0.0;
	private double maxLaengeInMeter=0.0;
	private double durchsVerweilzeitWS=0.0;
	
	private double maxErreicheteLaengeInMeter=0.0;
	private double durchsLaengeInMeter=0.0;
	private double prozentualBlockiert=0.0;
	
	private String beschreibung=null;
	
	public int getAbgefertigteFahrzeuge() {
		return abgefertigteFahrzeuge;
	}
	public void setAbgefertigteFahrzeuge(int abgefertigteFahrzeuge) {
		this.abgefertigteFahrzeuge = abgefertigteFahrzeuge;
	}
	public int getAnzahlFahrzeuge() {
		return anzahlFahrzeuge;
	}
	public void setAnzahlFahrzeuge(int anzahlFahrzeuge) {
		this.anzahlFahrzeuge = anzahlFahrzeuge;
	}
	public double getDurchsWartendeFahrzeuge() {
		return rund(durchsWartendeFahrzeuge);
	}
	public void setDurchsWartendeFahrzeuge(double durchsWartendeFahrzeuge) {
		this.durchsWartendeFahrzeuge = durchsWartendeFahrzeuge;
	}
	public int getMaxAnzahlFahrzeuge() {
		return maxAnzahlFahrzeuge;
	}
	public void setMaxAnzahlFahrzeuge(int maxAnzahlFahrzeuge) {
		this.maxAnzahlFahrzeuge = maxAnzahlFahrzeuge;
	}
	public double getMaxLaengeInMeter() {
		return rund(maxLaengeInMeter);
	}
	public void setMaxLaengeInMeter(double maxLaengeInMeter) {
		this.maxLaengeInMeter = maxLaengeInMeter;
	}
	public double getDurchsVerweilzeitWS() {
		return Math.round(durchsVerweilzeitWS);
	}
	public void setDurchsVerweilzeitWS(double durchsVerweilzeitWS) {
		this.durchsVerweilzeitWS = durchsVerweilzeitWS;
	}
	
	public double getDurchsLaengeInMeter() {
		return rund(durchsLaengeInMeter);
	}
	public void setDurchsLaengeInMeter(double durchsLaengeInMeter) {
		this.durchsLaengeInMeter = durchsLaengeInMeter;
	}
	public double getMaxErreicheteLaengeInMeter() {
		return rund(maxErreicheteLaengeInMeter);
	}
	public void setMaxErreicheteLaengeInMeter(double maxErreicheteLaengeInMeter) {
		this.maxErreicheteLaengeInMeter = maxErreicheteLaengeInMeter;
	}
	public double getProzentualBlockiert() {
		return rund(prozentualBlockiert*100.0);
	}
	public void setProzentualBlockiert(double blockierteZeit, double gesamtzeit) {
		this.prozentualBlockiert = blockierteZeit/gesamtzeit;
	}
	public double getProzentualeStrassenauslastung(){
		return rund((durchsLaengeInMeter/maxLaengeInMeter)*100.0);
	}
	
	
	private double rund(double d){
		return ((Math.round(d*100.0))/100.0);
	}
	
	
	public String getBeschreibung() {
		return beschreibung;
	}
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	
	
}
