package verkehrsplaner;
import java.util.LinkedList;

/*
 * Created on 18.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Warteschlange {
	//FIFO Warteschlange
	
	//private int groesse;
	private int anzahlElemente; //f�r bessere Performance von Hand 
	private LinkedList ws = new LinkedList();
	
	//Variablen f�r statistische Auswertungen
	private int max=0;
	private double gesamtVerweilZeitWS=0.0;
	private int fahrzeugDurchsatz=0;
	private double durchschnittlicheWSlaenge=0.0;
	private double zeitpunktLetzterAenderung=0.0;
	
	private double durchschnittlicheWSlaengeInMeter=0.0;
	private double maxWSlaengeInMeter = 0.0;
	private double blockierteZeit = 0.0;
	
	//Variable f�r das globale Blockade System
	private NormaleStrasse anbindung;
	private Simulationsabschnitt kreuzung;
	private double maxLaenge=4.0;
	private double aktuelleLaenge=0.0;
	private double abstandZwischenFahrzeuge = 1.5; //Sicherheitsabstand beim warten in WS
	
	//Variablen zum Einstellen
	private int maxWS = 1000;		//Max Begrenzung f�r eine WS
	
	//Variable f�r das Verwenden von Vor-Warteschlangen (mehrer Abbiegespuren)
	private Warteschlange vorWS = null;
	
	//Zus�tzliche Variablen
	private String beschreibung;
	
	public Warteschlange(NormaleStrasse anbindung, Simulationsabschnitt kreuzung, 
			double laengeFuerWs){
		this.anbindung = anbindung;
		anzahlElemente = 0;
		maxLaenge=laengeFuerWs;
		this.kreuzung = kreuzung;
	}

	public void push(KreuzungFahrzeugContainer objekt, double zeitpunkt){
		
		if(isBlockiert()){
			blockierteZeit += zeitpunkt - zeitpunktLetzterAenderung;
			if(zeitpunkt < zeitpunktLetzterAenderung){
				System.err.println("Fehlerhafter Aufruf von WS.push"+zeitpunkt+"-"+zeitpunktLetzterAenderung);
				System.err.println(kreuzung.getTyp()+":"+kreuzung.getID());
			}
				
			if(vorWS != null){
				vorWS.push(objekt,zeitpunkt);
				return;
			}
		}
		else if(vorWS != null && vorWS.getLaenge(zeitpunkt) > 0){
			//Auto kann nicht in WS einfahren, falls es eine VorWS gibt
			vorWS.push(objekt,zeitpunkt);
			return;
		}
		
		updateDurchschnittlicheWSlaenge(zeitpunkt);
		addFahrzeug(objekt,zeitpunkt,zeitpunkt);
	}
	
	//AddFahrzeug wird nur innerhalb der WS aufgerufen um die Fahrzeuge aus der VorWS einzuf�gen
	//SimulationsZeit ist die (aktuelle) Zeit f�r das Aufheben der Blockade
	private void addFahrzeug(KreuzungFahrzeugContainer objekt, double zeitpunkt, double simulationsZeit){
		if(ws.size() > maxWS){
			return;				//Max 1000 Fahrzeuge in der WS erlauben
		}
		
		//Blockieren falls WS zu lang wird
		aktuelleLaenge += abstandZwischenFahrzeuge + objekt.getLaengeInMeter();
		if(getAktuelleLaenge() > maxLaenge && anbindung != null){
			anbindung.setBlockiert(kreuzung,simulationsZeit);//TODO Problem - Keine Zeit�bergabe
		}
		
		//Objekt hinzuf�gen
		ws.addLast(objekt);
		objekt.fahrzeugErreichtWS(zeitpunkt);
//		updateDurchschnittlicheWSlaenge(zeitpunkt);
		anzahlElemente++;
		if(anzahlElemente > max){
			max = anzahlElemente;
		}
		
		//Max Laenge merken
		if(getAktuelleLaenge() > maxWSlaengeInMeter){
			maxWSlaengeInMeter = getAktuelleLaenge();
		}
		return;
	}
	
	public KreuzungFahrzeugContainer pop(double zeitpunkt){
		
		if(isBlockiert()){
			blockierteZeit += zeitpunkt - zeitpunktLetzterAenderung;
			if(zeitpunkt < zeitpunktLetzterAenderung)
				System.err.println("Fehlerhafter Aufruf von WS.pop");
		}
		
		if (getLaenge(zeitpunkt) < 1){
			System.err.println("Fehler: WS hat keine Elemente mehr!");
			return null;
		}
		updateDurchschnittlicheWSlaenge(zeitpunkt);
		anzahlElemente--;
		KreuzungFahrzeugContainer a = (KreuzungFahrzeugContainer)ws.getFirst();
		ws.removeFirst();
		fahrzeugDurchsatz++;
		gesamtVerweilZeitWS += a.fahrzeugVerlaesstWS(zeitpunkt);
		
		//Falls System blockiert ist und die Blockade aufgehoben wird
		if(getAktuelleLaenge()>maxLaenge && getAktuelleLaenge()-(a.getLaengeInMeter()+abstandZwischenFahrzeuge)<=maxLaenge 
				&& anbindung != null){
			anbindung.blockadeAufheben(kreuzung,zeitpunkt); //TODO Problem - Keine Zeit�bergabe
		}
		aktuelleLaenge -= (abstandZwischenFahrzeuge + a.getLaengeInMeter()); //Reihenfolge beachten
		
		return a;
	}

	
	public KreuzungFahrzeugContainer nextFahrzeug(){
		if(ws.size() > 0)
			return (KreuzungFahrzeugContainer)ws.getFirst();
		else
			return null;
	}
	
	private void updateDurchschnittlicheWSlaenge(double zeitpunkt){
		updateDurchschnittlicheWSlaengeInMeter(zeitpunkt);
		
		durchschnittlicheWSlaenge = (1/zeitpunkt) * 
						(durchschnittlicheWSlaenge*zeitpunktLetzterAenderung +
								anzahlElemente*(zeitpunkt-zeitpunktLetzterAenderung));
		
		zeitpunktLetzterAenderung=zeitpunkt;
	}
	
	private void updateDurchschnittlicheWSlaengeInMeter(double zeitpunkt){
		durchschnittlicheWSlaengeInMeter = (1/zeitpunkt) *
						(durchschnittlicheWSlaengeInMeter*zeitpunktLetzterAenderung + 
								getAktuelleLaenge()*(zeitpunkt-zeitpunktLetzterAenderung));
	}
	
	public int getLaenge(double zeitpunkt){
		if(!isBlockiert() && vorWS != null){ //Kontrolle ob etwas in der VorWS steht
			if(vorWS.getLaenge(zeitpunkt) > 0 && vorWS.nextFahrzeug().getWS() == this){
				//System.err.println("Eventl. Auto aus der vorWS holen");
				double tmp = vorWS.nextFahrzeug().ankunftWsZeitpunkt(); //TODO Gefahr neg. Ereignisse zu erzeugen
				addFahrzeug(vorWS.pop(zeitpunkt),tmp,zeitpunkt);			//Fahrzeug aus der vorWS holen
			}															//TODO Stimmt das (Simulationstechnisch)???
		}
		return anzahlElemente;
	}
	
	private double getAktuelleLaenge(){
		
		return aktuelleLaenge;//TODO Falls noch Zeit Fehler beheben
		
//		if(anbindung == null){ //Irgendwo ein Fehler drin
//			return aktuelleLaenge;
//		}
//		else{
//			return aktuelleLaenge+anbindung.getLaengeFahrzeuge(kreuzung, abstandZwischenFahrzeuge);
//		}
	}
	
	public int getMaxElemente(){
		return max;
	}
	
	public double getDurchschnittlicheVerweilzeitWS(){
		return Math.round((gesamtVerweilZeitWS/((double) fahrzeugDurchsatz))*1000.0)/1000.0;
	}
	
	public double getDurchschnittlicheWSlaenge(){
		return Math.round(durchschnittlicheWSlaenge*1000.0)/1000.0;
	}

	public boolean isBlockiert(){
		if(getAktuelleLaenge() > maxLaenge){
			return true;
		}
		return false;
	}
	
	public Warteschlange getVorWS() {
		return vorWS;
	}
	
	public void setVorWS(Warteschlange vorWS) {
		this.vorWS = vorWS;
	}
	
	public WarteschlangeErgebnis getErgebnis(){
		WarteschlangeErgebnis ergebnis = new WarteschlangeErgebnis();
		
		ergebnis.setAbgefertigteFahrzeuge(fahrzeugDurchsatz);
		ergebnis.setAnzahlFahrzeuge(anzahlElemente);
		ergebnis.setDurchsWartendeFahrzeuge(getDurchschnittlicheWSlaenge());
		ergebnis.setMaxAnzahlFahrzeuge(getMaxElemente());
		ergebnis.setMaxLaengeInMeter(maxLaenge);
		ergebnis.setDurchsVerweilzeitWS(getDurchschnittlicheVerweilzeitWS());
		
		ergebnis.setDurchsLaengeInMeter(durchschnittlicheWSlaengeInMeter);
		ergebnis.setMaxErreicheteLaengeInMeter(maxWSlaengeInMeter);
		ergebnis.setProzentualBlockiert(blockierteZeit,zeitpunktLetzterAenderung);
		
		ergebnis.setBeschreibung(beschreibung);
		
		return ergebnis;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	
	
}
