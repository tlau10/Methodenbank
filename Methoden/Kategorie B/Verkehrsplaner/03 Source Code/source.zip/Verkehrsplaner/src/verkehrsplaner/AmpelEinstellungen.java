/*
 * Created on 28.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface AmpelEinstellungen extends java.io.Serializable, EinstellungsDaten{
	
	public void setAnbindungen(int[] anbindungen);
	public double getBreite();
	public void setBreite(double breite);
	public void setName(String name);
	public void setId(int id);
	public void setType(String type);
	public double[][] getAbbiegenWahl();
	public void setAbbiegenWahl(double[][] abbiegenWahl);
	public double[] getAmpelSchaltZeiten();
	public void setAmpelSchaltZeiten(double[] ampelSchaltZeiten);
	public int getX();
	public void setX(int x);
	public int getY();
	public void setY(int y);
	public double getOffset();
	public void setOffset(double offset);
	public double getGelbPhasenDauer();
	public void setGelbPhasenDauer(double gelbPhasenDauer);
	public int getModus();
	public void setModus(int modus);
	public double getLaengeFussgaengerPhase();
	public void setLaengeFussgaengerPhase(double laengeFussgaengerPhase);
}
