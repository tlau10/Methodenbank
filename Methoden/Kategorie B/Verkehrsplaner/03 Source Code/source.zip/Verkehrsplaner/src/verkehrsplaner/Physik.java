package verkehrsplaner;
/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class Physik {

	private double effektiveBeschleunigungsStrecke = 0.5;
	private double bMax = 9.81;//Vorher 6.0
	private double endGeschw = 0.0;
	
	public Physik(){
	}
	
	private double zeitZumKonstantFahren(double v, double s){
		return s/v;
	}
	
	private double zeitZumBeschleunigen(double v, double v0, double a){
		double t = (v-v0)/a;
		return Math.abs(t);
	}
	
	private double streckeZumBeschleunigenUeberEinenZeitraum(double v0, double t, double a){
		double s = v0*t + 0.5*a*t*t;
		return Math.abs(s);
	}
	
	private double geschwNachBeschleunigungUeberZeitraum(double v0, double t, double a){
		double v = v0 + a*t;
		return Math.abs(v);
	}
	
	private double geschwNachBeschleunigungUeberStrecke(double v0, double s, double a){
		double wurzel = (2*a*s)+(v0*v0);
		if (wurzel < 0.0){
			System.err.println("Achtung: Abbremsen mehr als bis zum Stillstand!");
			return 1.0;
		}
		return Math.sqrt(wurzel);
	}
	
	private double streckeZumBeschleunigen(double v, double v0, double a){
		double s = ((v*v)-(v0*v0))/(2*a);
		return Math.abs(s);
	}
	
	//2as = v*v-v0*v0
	private double beschleunigenUeberStrecke(double v, double v0, double s){
		double a = ((v*v)-(v0*v0))/(2*s);
		return a;
	}
	
	private static double inMeterProSekundeUmrechnen(double kmh){
		return (kmh/3.6);
	}
	
	private static double inKilometerProStundeUmrechnen(double ms){
		return (ms*3.6);
	}
	
	public double getEndgeschwindigkeit(){
		return endGeschw;
	}
	
//	maxV und maxNaechstes in km/h	strecke in m
	public double zeitBerechnen(double strecke, double maxV, double maxNaechstes, Fahrzeug f){
		maxV = inMeterProSekundeUmrechnen(maxV);
		double v0 = inMeterProSekundeUmrechnen(f.getGeschwindigkeit());	//anfangsgeschw.
		double v1 = inMeterProSekundeUmrechnen(maxNaechstes);	//max geschw. im n�chsten segment
		
		double ergebnis = berechnen(maxV, strecke, v0, v1, f.getBeschleunigung(), f.getBremsbeschleunigung());
		f.setGeschwindigkeit(inKilometerProStundeUmrechnen(endGeschw));
		return ergebnis;
	}
	
//	maxV in km/h	strecke in m	v0,v1 in km/h	a,b in m/s^2
	private double zeitBerechnen(double maxV, double strecke, double v0, double v1, double a, double b, Fahrzeug f){
		maxV = inMeterProSekundeUmrechnen(maxV);
		v0 = inMeterProSekundeUmrechnen(v0);	//anfangsgeschw.
		v1 = inMeterProSekundeUmrechnen(v1);	//max geschw. im n�chsten segment
		
		double ergebnis = berechnen(maxV, strecke, v0, v1, a, b);
		f.setGeschwindigkeit(inKilometerProStundeUmrechnen(endGeschw));
		return ergebnis;
	}
	
	
	private double berechnen(double maxV, double strecke, double v0, double v1, double a, double b){
		double s = effektiveBeschleunigungsStrecke*strecke;
		endGeschw = 0.0;
		double maxStreckeBedarf;
		
		if(maxV<v1){	//Falls das nachfolgende Segment h�here Geschw. erlaubt
			v1=maxV;
		}
		
		if(v0 > maxV && (v0-maxV)<0.05){
			v0=maxV;		 //Fehlermeldungen durch Rundungsfehler vermeiden
		}
		
		if(v0> maxV){
			System.out.println("Achtung: Auto f�hrt zu schnell ein. Erlaubt:"+maxV+" Auto:"+v0);
			maxStreckeBedarf = Math.abs(streckeZumBeschleunigen(maxV,v0,-b));	//Bremsen von v0 auf maxV
			maxStreckeBedarf += Math.abs(streckeZumBeschleunigen(v1,maxV,-b));		//Bremsen von maxV auf v1
		}
		else{
			maxStreckeBedarf = Math.abs(streckeZumBeschleunigen(maxV,v0,a));	//Beschleunigen
			maxStreckeBedarf += Math.abs(streckeZumBeschleunigen(v1,maxV,-b));		//Bremsen
		}
		
		
		if(maxStreckeBedarf <= s){
			//Hurra es passt alles
			double normaleStrecke = strecke-maxStreckeBedarf;
			double t;
			
			if(v0>maxV){
				t = zeitZumBeschleunigen(maxV,v0,-b);	//Bremsen auf maxV
				t += zeitZumBeschleunigen(v1,maxV,-b);		//Bremsen auf v1
			}
			else{
				t = zeitZumBeschleunigen(maxV,v0,a);	//Beschleunigen
				t += zeitZumBeschleunigen(v1,maxV,-b);		//Bremsen
			}
			t += zeitZumKonstantFahren(maxV,normaleStrecke);
			endGeschw = v1;
			return t;
		}
		else{
			//Die Strecke s reicht nicht um auf max zu beschleunigen
			double vAusgleichStrecke;
			
			if(v0 > v1){
				vAusgleichStrecke = streckeZumBeschleunigen(v1,v0,-b); //Bremsen
			}
			else{
				vAusgleichStrecke = streckeZumBeschleunigen(v1,v0,a); //Beschleunigen
			}
			
			// Falls die Gesamtstrecke zum Beschleunigen reicht, wird dies auch ausgenutzt
			// 3 F�lle:
			// - Reicht nicht ganz zum Beschleunigen auf v1
			// - Reicht zum Beschleunigen auf v1 aber ben�tigt >= 50% der Strecke
			// - Reicht zum Beschleunigen auf mehr als v1
			//   Allerdings nicht zum Beschleunigen auf maxV
			
			if(vAusgleichStrecke > strecke){
				if(v0>v1){
					//System.out.println("Achtung: Strecke reicht nicht zum normal Bremsen");
					double vergl = streckeZumBeschleunigen(v1,v0,-bMax);
					if(vergl > strecke){
						endGeschw = geschwNachBeschleunigungUeberStrecke(v0,strecke,-bMax);
						System.out.println("Bremsen reicht nicht");
						return zeitZumBeschleunigen(endGeschw,v0,-bMax);
					}
					else{
						endGeschw = v1;
						double aStrecke = beschleunigenUeberStrecke(v1,v0,strecke);
						if(aStrecke > 0.0){
							System.err.println("Fehler: Bremsprobleme");
						}
						return zeitZumBeschleunigen(v1,v0,aStrecke);
					}
				}
				else{
					endGeschw = geschwNachBeschleunigungUeberStrecke(v0,strecke,a);
					return zeitZumBeschleunigen(endGeschw,v0,a);
				}
			}
			else if(vAusgleichStrecke > s && vAusgleichStrecke < strecke){
				double sRest = strecke - vAusgleichStrecke;
				double t;
				
				if (v0 > maxV){	//Falls Auto zu schnell einf�hrt
					t = zeitZumBeschleunigen(v1,v0,-b);
					t += zeitZumKonstantFahren(maxV,sRest); 
					endGeschw = v1;
				}
				else if (v0 > v1){
					t = zeitZumBeschleunigen(v1,v0,-b);
					t += zeitZumKonstantFahren(v0,sRest);
					endGeschw = v1;
				}
				else{
					t = zeitZumBeschleunigen(v1,v0,a);
					t += zeitZumKonstantFahren(v1,sRest);
					endGeschw = v1;
				}
				return t;
			}
			else{
				//3.Fall					
				double sRest = s - vAusgleichStrecke;
				double t;//Zeit zur anpassnung an v1
				
				//Wieviel kann jetzt noch beschleunigt werden ???
				//Da Beschleunigung linear verl�uft gilt: sRest/2 beschleunigen und sRest/2 abbremsen
				//Die max Geschwindigkeit wird f�r die normale Fahrt ben�tigt
				double s2 = (a*sRest)/(b+a);
				double s1 = sRest - s2;
				double vRestMax;
				
				endGeschw = v1;
				
				if(v0>v1){
					t = zeitZumBeschleunigen(v1,v0,-b);//Zeit f�r vAusgleichstrecke
					vRestMax = geschwNachBeschleunigungUeberStrecke(v0,s1,a);
					t += zeitZumBeschleunigen(vRestMax,v0,a);	// Beschleunigen
					t += zeitZumBeschleunigen(v0,vRestMax,-b);	// Bremsen
				}
				else{	//TODO �berpr�fen // vorher: gleiches wie oben -- konnte nicht sein
					t = zeitZumBeschleunigen(v1,v0,a);//Zeit f�r vAusgleichstrecke
					vRestMax = geschwNachBeschleunigungUeberStrecke(v1,s1,a); // Berechnen von der max V
					t += zeitZumBeschleunigen(vRestMax,v1,a);	// Beschleunigen
					t += zeitZumBeschleunigen(v1,vRestMax,-b);	// Bremsen
				}
				
				if(vRestMax > maxV){
					vRestMax = maxV;
				}
				
				t += zeitZumKonstantFahren(vRestMax,(strecke-s));
				
				return t;
			}
		}
	}
	
	//	Radius in m 	maxBeschleunigung in m/s^2
	public static double getMaxGeschwindigkeitInDerKurve(double radius, double maxBeschleunigung){
		// a = v^2/r
		// -> v = wurzel(a*r);
		double v = Math.sqrt(maxBeschleunigung*radius);
		
		return inKilometerProStundeUmrechnen(v);
	}
	
	public static double getGeschwindigkeitBeimAnfahrenInDerGruppe(KreuzungFahrzeugContainer nachfolger, KreuzungFahrzeugContainer vorg�nger){
		//V_nachfolger = (A_nachfolger / A_vorg�nger) * V_vorgaenger
		double a = nachfolger.getBeschleunigung() / vorg�nger.getBeschleunigung();
		double v  = inMeterProSekundeUmrechnen(nachfolger.getMaxV());
		double v_v = inMeterProSekundeUmrechnen(vorg�nger.getGeschwindigkeit()); //V_vorgaenger
		double v_n = a * v_v; 						//V_nachfolger
				
		//Fahrzeug darf nicht schneller anfahren als sein Vorg�nger
		if(a>1.0 && v_v < v){ 
			v = v_v;	//Fahrzeug hat die selbe Geschw. wie das vorgaengerFahrzeug
		}
		else if(v_n < v){
			v = v_n;	//Fahrzeug bekommt die berechnete Geschw.
		}
				
		//TODO Habe ich hier und oben eine Umrechnung (km/h in m/s und umgekehrt)vergessen???
		//System.out.println("Geschwindigkeit: "+v+" vorganeger:"+v_v+" Berechnet:"+v_n);
		return inKilometerProStundeUmrechnen(v);
		
	}
	
	public static double getGeschwindigkeitsverlustDurchBlockade(KreuzungFahrzeugContainer f, double zeit, double s){
		//Geschwindigkeitsverlust durch die Blockade erfassen-!!!!
		double t =zeit-f.getZeitLetztesBedienEnde();
		
		double maxV = f.getMaxV();
	
		//Alte Geschwindigkeit
		double v0 = inMeterProSekundeUmrechnen(f.getLetzteGeschwindigkeit());
		
		double a = ((2*s)-(2*v0*t))/(t*t);
		
		if(a > f.getBeschleunigung())
			a = f.getBeschleunigung();
		
		double v1 = inKilometerProStundeUmrechnen(v0+(a*t));

//		if(v1 > f.getGeschwindigkeit()){
//			//Es ist kein Fehler falls das berechnete v1 > als die vorher festgelegte Geschwindikeit
//			//dies kann vorkommen, weil die berechnen Funktion mit max Beschleunigung beschleunigt
//			//und danach mit konstanter Geschwindigkeit f�hrt -> daher schneller als wenn man mit
//			//einer konstanten Beschleunigung die ganze Zeit beschleunigen w�rde
//			
////			System.out.println("--------------------------------------------------------"); //TODO TESTS
////			System.out.println("ID: "+f.getID());
////			System.out.println("t: "+t+" s: "+s+" MaxV: "+maxV); //TODO TESTS
////			System.out.println("v0: "+f.getLetzteGeschwindigkeit()+" v1: "+v1+" a: "+a); //TODO TESTS
////			System.out.println("Alte Methode v: "+v+" Geplant:"+f.getGeschwindigkeit());//TODO TESTS
//		}
		
		
		if(v1<0.0){ //Falls die korekte Methode mist baut
			//Annahme: Dieses Segment wurde mit konstanter Geschw. durchfahren
			
			double v = s / t; //v=s/t   v in meter pro sekunde
			v = inKilometerProStundeUmrechnen(v);	//Umrechnen in km/h
			
			return v;
		}
		else{
			if(v1 < maxV)
				return v1;
			else
				return maxV;
		}
	}
}