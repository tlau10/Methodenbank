/*
 * Created on 08.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Status {
	private int id;
	private int anzahlWS;
	private int[] wsLange;
	private int[] wsId;
	private boolean[] blockiert = {false,false};
	private String infoText="";
	private boolean ankunft=false;
	private boolean neuesFahrzeug=false;
	
	public Status(int id){
		this.id = id;
	}
	
	public int getAnzahlWS() {
		return anzahlWS;
	}
	public void setAnzahlWS(int anzahlWS) {
		this.anzahlWS = anzahlWS;
	}
	public boolean[] isBlockiert() {
		return blockiert;
	}
	public void setBlockiert(boolean[] blockiert) {
		this.blockiert = blockiert;
	}
	public int[] getWsLaenge() {
		return wsLange;
	}
	public void setWsLaenge(int[] wsLange) {
		this.wsLange = wsLange;
	}
	public int[] getWsId() {
		return wsId;
	}
	public void setWsId(int[] wsId) {
		this.wsId = wsId;
	}
	public int getId() {
		return id;
	}
	public String getInfoText() {
		return infoText;
	}
	public void setInfoText(String infoText) {
		this.infoText = infoText;
	}
	
	public boolean isAnkunft() {
		return ankunft;
	}
	public void setAnkunft(boolean ankunft) {
		this.ankunft = ankunft;
	}
	public boolean isNeuesFahrzeug() {
		return neuesFahrzeug;
	}
	public void setNeuesFahrzeug(boolean neuesFahrzeug) {
		this.neuesFahrzeug = neuesFahrzeug;
	}
}
