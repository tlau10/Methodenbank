package verkehrsplaner;
//import java.util.Hashtable;

/*
 * Created on 17.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Ereignis {
	private double zeitpunkt;
	private Fahrzeug objekt;
	private String typ;
	private Simulationsabschnitt standort;
	
	public Ereignis(double zeitpunkt, Fahrzeug fahrzeug, String typ, Simulationsabschnitt standort){
		this.zeitpunkt = zeitpunkt;
		this.objekt = fahrzeug;
		this.typ = typ;
		this.standort = standort;
	}
	
	/**
	 * @return Returns the startZeitpunkt.
	 */
	public double getZeitpunkt() {
		return zeitpunkt;
	}

	/**
	 * @return Returns the Fahrzeug.
	 */
	public Fahrzeug getFahrzeug() {
		return objekt;
	}

	public String getTyp() {
		return typ;
	}

	/**
	 * @return Returns the standort.
	 */
	public Simulationsabschnitt getStandort() {
		return standort;
	}
}
