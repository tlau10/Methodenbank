/*
 * Created on 01.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package verkehrsplaner;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AllgemeineEinstellungen implements java.io.Serializable, Einstellungen {

	private static final long serialVersionUID = -4139128128888447112L;
	
	//Datenspezifisch
	private int anzahlAmpelTyp2=0;
	private int anzahlAmpelKlein=0;
	private int anzahlAmpelMittel=0;
	private int anzahlAmpelGross=0;
	
	private int anzahlVorfahrt=0;
	private int anzahlRechtsVorLinks=0;
	private int anzahlKreisverkehrTyp2=0;
	private int anzahlQuellen=0;
	private int anzahlSenken=0;
	private int anzahlStrassen=0;
	private int idCounter=1;
	private int oldWidth=1000;
	private int oldHeight=700;
	private String type="allgemeineEinstellungen";
	
	//SimulationsEinstellungen
	private double pkwLaengeErwartungswert = 3.8;
	private double pkwLaengeStandardabweichung = 0.5;
	private double pkwLaengeMin = 2.0;
	private double pkwLaengeMax = 10.0;
	private double pkwBeschleunigungsErwartungswert = 0.8;
	private double pkwBeschleunigungsStandardabweichung = 0.15;
	private double pkwBeschleunigungMin = 0.4;
	private double pkwBeschleunigungMax = 5.0;
	private double pkwBremsenErwartungswert = 2.1;
	private double pkwBremsenStandardabweichung = 0.3;
	private double pkwBremsenMin = 1.5;
	private double pkwBremsenMax = 8.0;
	private double pkwHorizontaleBeschlErwartungswert = 1.6;
	private double pkwHorizontaleBeschlStandardabweichung = 0.3;
	private double pkwHorizontaleBeschlMin = 0.9;
	private double pkwHorizontaleBeschlMax = 3.5;
	
	private double lkwLaengeErwartungswert = 9.0;
	private double lkwLaengeStandardabweichung = 3.0;
	private double lkwLaengeMin = 8.0;
	private double lkwLaengeMax = 18.0;
	private double lkwBeschleunigungsErwartungswert = 0.5;
	private double lkwBeschleunigungsStandardabweichung = 0.1;
	private double lkwBeschleunigungMin = 0.3;
	private double lkwBeschleunigungMax = 1.0;
	private double lkwBremsenErwartungswert = 1.3;
	private double lkwBremsenStandardabweichung = 0.2;
	private double lkwBremsenMin = 0.8;
	private double lkwBremsenMax = 2.2;
	private double lkwHorizontaleBeschlErwartungswert = 1.0;
	private double lkwHorizontaleBeschlStandardabweichung = 0.2;
	private double lkwHorizontaleBeschlMin = 0.6;
	private double lkwHorizontaleBeschlMax = 2.0;
	
	//Sonstige Einstellungen
	private double simulationsDauer = 500.0;
	private String pfadHintergrund = null;
	

	public int getAnzahlAmpelTyp2() {
		return anzahlAmpelTyp2;
	}
	public void setAnzahlAmpelTyp2(int anzahlAmpelTyp2) {
		this.anzahlAmpelTyp2 = anzahlAmpelTyp2;
	}
	public int getAnzahlKreisverkehrTyp2() {
		return anzahlKreisverkehrTyp2;
	}
	public void setAnzahlKreisverkehrTyp2(int anzahlKreisverkehrTyp2) {
		this.anzahlKreisverkehrTyp2 = anzahlKreisverkehrTyp2;
	}
	public int getAnzahlQuellen() {
		return anzahlQuellen;
	}
	public void setAnzahlQuellen(int anzahlQuellen) {
		this.anzahlQuellen = anzahlQuellen;
	}
	public int getAnzahlSenken() {
		return anzahlSenken;
	}
	public void setAnzahlSenken(int anzahlSenken) {
		this.anzahlSenken = anzahlSenken;
	}
	public int getAnzahlStrassen() {
		return anzahlStrassen;
	}
	public void setAnzahlStrassen(int anzahlStrassen) {
		this.anzahlStrassen = anzahlStrassen;
	}
	public int getIdCounter() {
		return idCounter;
	}
	public void setIdCounter(int idCounter) {
		this.idCounter = idCounter;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getOldHeight() {
		return oldHeight;
	}
	public void setOldHeight(int oldHeight) {
		this.oldHeight = oldHeight;
	}
	public int getOldWidth() {
		return oldWidth;
	}
	public void setOldWidth(int oldWidth) {
		this.oldWidth = oldWidth;
	}
	
	public double getLkwBeschleunigungsErwartungswert() {
		return lkwBeschleunigungsErwartungswert;
	}
	public void setLkwBeschleunigungsErwartungswert(
			double lkwBeschleunigungsErwartungswert) {
		this.lkwBeschleunigungsErwartungswert = lkwBeschleunigungsErwartungswert;
	}
	public double getLkwBeschleunigungsStandardabweichung() {
		return lkwBeschleunigungsStandardabweichung;
	}
	public void setLkwBeschleunigungsStandardabweichung(
			double lkwBeschleunigungsStandardabweichung) {
		this.lkwBeschleunigungsStandardabweichung = lkwBeschleunigungsStandardabweichung;
	}
	public double getLkwBremsenErwartungswert() {
		return lkwBremsenErwartungswert;
	}
	public void setLkwBremsenErwartungswert(double lkwBremsenErwartungswert) {
		this.lkwBremsenErwartungswert = lkwBremsenErwartungswert;
	}
	public double getLkwBremsenStandardabweichung() {
		return lkwBremsenStandardabweichung;
	}
	public void setLkwBremsenStandardabweichung(
			double lkwBremsenStandardabweichung) {
		this.lkwBremsenStandardabweichung = lkwBremsenStandardabweichung;
	}
	public double getLkwHorizontaleBeschlErwartungswert() {
		return lkwHorizontaleBeschlErwartungswert;
	}
	public void setLkwHorizontaleBeschlErwartungswert(
			double lkwHorizontaleBeschlErwartungswert) {
		this.lkwHorizontaleBeschlErwartungswert = lkwHorizontaleBeschlErwartungswert;
	}
	public double getLkwHorizontaleBeschlStandardabweichung() {
		return lkwHorizontaleBeschlStandardabweichung;
	}
	public void setLkwHorizontaleBeschlStandardabweichung(
			double lkwHorizontaleBeschlStandardabweichung) {
		this.lkwHorizontaleBeschlStandardabweichung = lkwHorizontaleBeschlStandardabweichung;
	}
	public double getLkwLaengeErwartungswert() {
		return lkwLaengeErwartungswert;
	}
	public void setLkwLaengeErwartungswert(double lkwLaengeErwartungswert) {
		this.lkwLaengeErwartungswert = lkwLaengeErwartungswert;
	}
	public double getLkwLaengeStandardabweichung() {
		return lkwLaengeStandardabweichung;
	}
	public void setLkwLaengeStandardabweichung(
			double lkwLaengeStandardabweichung) {
		this.lkwLaengeStandardabweichung = lkwLaengeStandardabweichung;
	}
	public double getPkwBeschleunigungsErwartungswert() {
		return pkwBeschleunigungsErwartungswert;
	}
	public void setPkwBeschleunigungsErwartungswert(
			double pkwBeschleunigungsErwartungswert) {
		this.pkwBeschleunigungsErwartungswert = pkwBeschleunigungsErwartungswert;
	}
	public double getPkwBeschleunigungsStandardabweichung() {
		return pkwBeschleunigungsStandardabweichung;
	}
	public void setPkwBeschleunigungsStandardabweichung(
			double pkwBeschleunigungsStandardabweichung) {
		this.pkwBeschleunigungsStandardabweichung = pkwBeschleunigungsStandardabweichung;
	}
	public double getPkwBremsenErwartungswert() {
		return pkwBremsenErwartungswert;
	}
	public void setPkwBremsenErwartungswert(double pkwBremsenErwartungswert) {
		this.pkwBremsenErwartungswert = pkwBremsenErwartungswert;
	}
	public double getPkwBremsenStandardabweichung() {
		return pkwBremsenStandardabweichung;
	}
	public void setPkwBremsenStandardabweichung(
			double pkwBremsenStandardabweichung) {
		this.pkwBremsenStandardabweichung = pkwBremsenStandardabweichung;
	}
	public double getPkwHorizontaleBeschlErwartungswert() {
		return pkwHorizontaleBeschlErwartungswert;
	}
	public void setPkwHorizontaleBeschlErwartungswert(
			double pkwHorizontaleBeschlErwartungswert) {
		this.pkwHorizontaleBeschlErwartungswert = pkwHorizontaleBeschlErwartungswert;
	}
	public double getPkwHorizontaleBeschlStandardabweichung() {
		return pkwHorizontaleBeschlStandardabweichung;
	}
	public void setPkwHorizontaleBeschlStandardabweichung(
			double pkwHorizontaleBeschlStandardabweichung) {
		this.pkwHorizontaleBeschlStandardabweichung = pkwHorizontaleBeschlStandardabweichung;
	}
	public double getPkwLaengeErwartungswert() {
		return pkwLaengeErwartungswert;
	}
	public void setPkwLaengeErwartungswert(double pkwLaengeErwartungswert) {
		this.pkwLaengeErwartungswert = pkwLaengeErwartungswert;
	}
	public double getPkwLaengeStandardabweichung() {
		return pkwLaengeStandardabweichung;
	}
	public void setPkwLaengeStandardabweichung(
			double pkwLaengeStandardabweichung) {
		this.pkwLaengeStandardabweichung = pkwLaengeStandardabweichung;
	}
	
	public double getLkwBeschleunigungMin() {
		return lkwBeschleunigungMin;
	}
	public void setLkwBeschleunigungMin(double lkwBeschleunigungMin) {
		this.lkwBeschleunigungMin = lkwBeschleunigungMin;
	}
	public double getLkwBremsenMin() {
		return lkwBremsenMin;
	}
	public void setLkwBremsenMin(double lkwBremsenMin) {
		this.lkwBremsenMin = lkwBremsenMin;
	}
	public double getLkwHorizontaleBeschlMin() {
		return lkwHorizontaleBeschlMin;
	}
	public void setLkwHorizontaleBeschlMin(double lkwHorizontaleBeschlMin) {
		this.lkwHorizontaleBeschlMin = lkwHorizontaleBeschlMin;
	}
	public double getPkwBeschleunigungMin() {
		return pkwBeschleunigungMin;
	}
	public void setPkwBeschleunigungMin(double pkwBeschleunigungMin) {
		this.pkwBeschleunigungMin = pkwBeschleunigungMin;
	}
	public double getPkwBremsenMin() {
		return pkwBremsenMin;
	}
	public void setPkwBremsenMin(double pkwBremsenMin) {
		this.pkwBremsenMin = pkwBremsenMin;
	}
	public double getPkwHorizontaleBeschlMin() {
		return pkwHorizontaleBeschlMin;
	}
	public void setPkwHorizontaleBeschlMin(double pkwHorizontaleBeschlMin) {
		this.pkwHorizontaleBeschlMin = pkwHorizontaleBeschlMin;
	}
	public int getAnzahlAmpelGross() {
		return anzahlAmpelGross;
	}
	public void setAnzahlAmpelGross(int anzahlAmpelGross) {
		this.anzahlAmpelGross = anzahlAmpelGross;
	}
	public int getAnzahlAmpelKlein() {
		return anzahlAmpelKlein;
	}
	public void setAnzahlAmpelKlein(int anzahlAmpelKlein) {
		this.anzahlAmpelKlein = anzahlAmpelKlein;
	}
	public int getAnzahlAmpelMittel() {
		return anzahlAmpelMittel;
	}
	public void setAnzahlAmpelMittel(int anzahlAmpelMittel) {
		this.anzahlAmpelMittel = anzahlAmpelMittel;
	}
	public int getAnzahlRechtsVorLinks() {
		return anzahlRechtsVorLinks;
	}
	public void setAnzahlRechtsVorLinks(int anzahlRechtsVorLinks) {
		this.anzahlRechtsVorLinks = anzahlRechtsVorLinks;
	}
	public int getAnzahlVorfahrt() {
		return anzahlVorfahrt;
	}
	public void setAnzahlVorfahrt(int anzahlVorfahrt) {
		this.anzahlVorfahrt = anzahlVorfahrt;
	}
	public double getSimulationsDauer() {
		return simulationsDauer;
	}
	public void setSimulationsDauer(double simulationsDauer) {
		this.simulationsDauer = simulationsDauer;
	}
	public String getPfadHintergrund() {
		return pfadHintergrund;
	}
	public void setPfadHintergrund(String pfadHintergrund) {
		this.pfadHintergrund = pfadHintergrund;
	}
	public double getPkwBeschleunigungMax() {
		return pkwBeschleunigungMax;
	}
	public void setPkwBeschleunigungMax(double pkwBeschleunigungMax) {
		this.pkwBeschleunigungMax = pkwBeschleunigungMax;
	}
	public double getPkwBremsenMax() {
		return pkwBremsenMax;
	}
	public void setPkwBremsenMax(double pkwBremsenMax) {
		this.pkwBremsenMax = pkwBremsenMax;
	}
	public double getPkwHorizontaleBeschlMax() {
		return pkwHorizontaleBeschlMax;
	}
	public void setPkwHorizontaleBeschlMax(double pkwHorizontaleBeschlMax) {
		this.pkwHorizontaleBeschlMax = pkwHorizontaleBeschlMax;
	}
	public double getLkwBeschleunigungMax() {
		return lkwBeschleunigungMax;
	}
	public void setLkwBeschleunigungMax(double lkwBeschleunigungMax) {
		this.lkwBeschleunigungMax = lkwBeschleunigungMax;
	}
	public double getLkwBremsenMax() {
		return lkwBremsenMax;
	}
	public void setLkwBremsenMax(double lkwBremsenMax) {
		this.lkwBremsenMax = lkwBremsenMax;
	}
	public double getLkwHorizontaleBeschlMax() {
		return lkwHorizontaleBeschlMax;
	}
	public void setLkwHorizontaleBeschlMax(double lkwHorizontaleBeschlMax) {
		this.lkwHorizontaleBeschlMax = lkwHorizontaleBeschlMax;
	}
	public double getPkwLaengeMin() {
		return pkwLaengeMin;
	}
	public void setPkwLaengeMin(double pkwLaengeMin) {
		this.pkwLaengeMin = pkwLaengeMin;
	}
	public double getPkwLaengeMax() {
		return pkwLaengeMax;
	}
	public void setPkwLaengeMax(double pkwLaengeMax) {
		this.pkwLaengeMax = pkwLaengeMax;
	}
	public double getLkwLaengeMin() {
		return lkwLaengeMin;
	}
	public void setLkwLaengeMin(double lkwLaengeMin) {
		this.lkwLaengeMin = lkwLaengeMin;
	}
	public double getLkwLaengeMax() {
		return lkwLaengeMax;
	}
	public void setLkwLaengeMax(double lkwLaengeMax) {
		this.lkwLaengeMax = lkwLaengeMax;
	}
	
}
