/*
 * Created on 29.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package test;

/**
 * @author surfen
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TestStart {

	public static void main(String[] args) {
		double first = 27.3;
		Double tmp = new Double(first);
		double meins = tmp.doubleValue();
		
		System.out.println(first);
		System.out.println(meins);
	}
}
