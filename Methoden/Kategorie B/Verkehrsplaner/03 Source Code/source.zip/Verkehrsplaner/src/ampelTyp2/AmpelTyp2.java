/*
 * Created on 30.09.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ampelTyp2;

import java.util.LinkedList;

import verkehrsplaner.Ereignis;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Fahrzeug;
import verkehrsplaner.FahrzeugListe;
import verkehrsplaner.Kreuzung;
import verkehrsplaner.NormaleStrasse;
import verkehrsplaner.Physik;
import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Simulationslogik;
import verkehrsplaner.Status;
import verkehrsplaner.Warteschlange;
import verkehrsplaner.Zufallszahlen;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AmpelTyp2  implements Kreuzung {
	
	/*	4 Ampelphasen: + 4 Gelbphasen
	0 - Nord / Sued Gr�n f�r Geradeaus und Rechtsabbieger
	1 - Nord / Sued Gr�n f�r Linksabbieger
	2 - Ost/ West Gr�n f�r Geradeaus und Rechtsabbieger
	3 - Ost/ West Gr�n f�r Linksabbieger*/
	/*
	Es gibt 8 WS:			
			[0][0]-Nord geradeaus
			[1][0]-Nord Links
			[2][0]-Ost geradeaus
			[3][0]-Ost Links
			[0][1]-Sued geradeaus
			[1][1]-Sued Links
			[2][1]-West geradeaus
			[3][1]-West Links*/
	
	private AmpelTyp2Einstellungen daten;
	private Simulationslogik logik;
	private Physik physik;
	private FahrzeugListe angekuendigteFahrzeuge;
	private Simulationsabschnitt[] anbindung;
	private double zeit;
	
	private double segmentlaenge;
	private int ampelPhase;
	private String ampelStatus;
	private double[] ampelSchaltZeiten; //Schaltzeiten fuer jede Richtung
	private double[] ampelGelbphaseDauer = {2.0, 2.0, 2.0, 2.0};
	
	private double[][] abbiegenWahl; //Wahrkeit fuer Abbiegen je nach Einfahrt
	private Warteschlange[][] ws = new Warteschlange[4][2];
	private Warteschlange[][] wsNachRichtung = new Warteschlange[4][2];
	private Warteschlange[] vorWS = new Warteschlange[4];
	private AmpelTyp2Segment[][] einfahrt = new AmpelTyp2Segment[4][2];
	
	private AmpelTyp2Segment[][] segment = new AmpelTyp2Segment[3][3];
	
	
	public AmpelTyp2(AmpelTyp2Einstellungen daten){
		this.daten = daten;
		
		for(int i=0;i<4;i++)
			ampelGelbphaseDauer[i]=daten.getGelbPhasenDauer();
		
		ampelGelbphaseDauer[3] += daten.getLaengeFussgaengerPhase();

		ampelSchaltZeiten=daten.getAmpelSchaltZeiten();
		
		angekuendigteFahrzeuge = new FahrzeugListe();
		anbindung = new Simulationsabschnitt[4];
		physik = new Physik();
		segmentlaenge=daten.getBreite()/3.0;
	}
	

	public Ergebnis getErgebnis() {
		Ergebnis e = new Ergebnis(daten.getId());
		
		for(int i=0;i<4;i++){
			e.addVorWS(vorWS[i].getErgebnis());
			
			for(int j=0;j<2;j++)
				e.addWS(wsNachRichtung[i][j].getErgebnis());
		}
		
		
		int[] anzahlFahrzeuge = {0,0,0,0};
		double[] durchsWSlaenge = {0.0,0.0,0.0,0.0};
		double[] durchsWartezeit = {0.0,0.0,0.0,0.0};
		double[] prozAuslastung = {0.0,0.0,0.0,0.0};
		double[] prozStau = {0.0,0.0,0.0,0.0};
		int[] maxLaenge = {0,0,0,0};
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				
//			 	aktuelle WS l�nge
				anzahlFahrzeuge[i] = e.getVorWS(i).getAnzahlFahrzeuge();
				anzahlFahrzeuge[i] += e.getWS(i*2).getAnzahlFahrzeuge();
				anzahlFahrzeuge[i] += e.getWS(i*2+1).getAnzahlFahrzeuge();

//				 durchs. WS l�nge
				durchsWSlaenge[i] = e.getVorWS(i).getDurchsWartendeFahrzeuge();
				durchsWSlaenge[i] += e.getWS(i*2).getDurchsWartendeFahrzeuge();
				durchsWSlaenge[i] += e.getWS(i*2+1).getDurchsWartendeFahrzeuge();
				durchsWSlaenge[i] = rund(durchsWSlaenge[i]);

//				 durchs. Wartezeit
				durchsWartezeit[i] = e.getWS(i*2).getDurchsVerweilzeitWS()*e.getWS(i*2).getAbgefertigteFahrzeuge();
				durchsWartezeit[i] += e.getWS(i*2+1).getDurchsVerweilzeitWS()*e.getWS(i*2+1).getAbgefertigteFahrzeuge();
				durchsWartezeit[i] /= (e.getWS(i*2).getAbgefertigteFahrzeuge()+e.getWS(i*2+1).getAbgefertigteFahrzeuge());
				durchsWartezeit[i] += e.getVorWS(i).getDurchsVerweilzeitWS();
				durchsWartezeit[i] = rund(durchsWartezeit[i]);

//				 proz. Stra�enauslastung
				prozAuslastung[i] = e.getVorWS(i).getProzentualeStrassenauslastung()*e.getVorWS(i).getMaxLaengeInMeter();
				prozAuslastung[i] += e.getWS(i*2).getProzentualeStrassenauslastung()*e.getWS(i*2).getMaxLaengeInMeter();
				prozAuslastung[i] += e.getWS(i*2+1).getProzentualeStrassenauslastung()*e.getWS(i*2+1).getMaxLaengeInMeter();
				prozAuslastung[i] /= (e.getVorWS(i).getMaxLaengeInMeter()+e.getWS(i*2).getMaxLaengeInMeter()
							+e.getWS(i*2+1).getMaxLaengeInMeter());
				prozAuslastung[i] = rund(prozAuslastung[i]);
					
//				 proz. Stau
				prozStau[i] = e.getVorWS(i).getProzentualBlockiert();

					
//				Max WS L�nge
				maxLaenge[i] = e.getVorWS(i).getMaxAnzahlFahrzeuge();
				maxLaenge[i] += e.getWS(i*2).getMaxAnzahlFahrzeuge();
				maxLaenge[i] += e.getWS(i*2+1).getMaxAnzahlFahrzeuge();
			}
		}
		
		e.setAnzahlFahrzeuge(anzahlFahrzeuge);
		e.setDurchsWSlaenge(durchsWSlaenge);
		e.setDurchsWartezeit(durchsWartezeit);
		e.setProzAuslastung(prozAuslastung);
		e.setProzStau(prozStau);
		e.setMaxLaenge(maxLaenge);
		
		return e;
	}
	
	private double rund(double d){
		return ((Math.round(d*100.0))/100.0);
	}

	public void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung) {
		if(himmelsrichtung >= 0 && himmelsrichtung < 4){
			this.anbindung[himmelsrichtung] = anbindung;
		}
		else{
			System.err.println("Fehlerhafte Zuweisung - Stra�e "+daten.getId()+" Richtung:"+himmelsrichtung);
		}
	}

	public void ereignisHandler(Ereignis e) {
		zeit=e.getZeitpunkt();
		
		//System.out.println(e.getFahrzeug().getID()+"V: "+e.getFahrzeug().getGeschwindigkeit());
		
		if(e.getTyp().equals("ankunft")){
			ankunft(e.getFahrzeug());
		}
		else if (e.getTyp().equals("bedienEnde")){
			bedienEnde(((AmpelTyp2Container) e.getFahrzeug()));
		}
		else if(e.getTyp().equals("ampelWirdRot")){
			ampelStatus="rot";
			double tmp = ampelGelbphaseDauer[ampelPhase];
			
			Ereignis f = new Ereignis(zeit+tmp,null, "ampelWirdGruen",this);		//Gruenphase
			logik.pushEreignis(f);
		}
		else if(e.getTyp().equals("ampelWirdGruen")){
			ampelWirdGruen();
		}
		else{
			System.err.println("Unbekanntes Ereignis" + e.getTyp());
		}
		
	}
	
	private void ampelWirdGruen(){
		ampelStatus="gruen";
		ampelPhase++;
		if(ampelPhase >= 4){
			ampelPhase = 0;
		}
		Ereignis f = new Ereignis(zeit+ampelSchaltZeiten[ampelPhase],null, "ampelWirdRot",this);		//Gruenphase
		logik.pushEreignis(f);
		
		if(!kreuzungIstLeer()){
			ampelStatus="blockiert";
			return;
		}
		else{
			//fahrzeuge aus der WS holen
			autosAusWsEinfahrenLassen();
		}
	}
	
	
	private void bedienEnde(AmpelTyp2Container f){
		
		AmpelTyp2Segment head = f.getHead();
		AmpelTyp2Segment tail = f.getTail();
		
		//Verl�sst das Auto die Kreuzung?
		if(head == f.getAusfahrtSegment()){
			if (head==tail){//Das Auto-Heck verl�sst die Kreuzung
				Ereignis e = new Ereignis(logik.getZeit(), f, "ankunft", head.getAusfahrt());
				logik.pushEreignis(e);
				segmentWirdFrei(head); //eventl. Blockade beheben und aus WS einfahren lassen
			}
			else{
				neuesBedienEndeEreignis(f);
			}
		}
		else{
			//Auto f�hrt weiter
			if(f.getNextHead().getStatus().equals("frei")){ //Auto f�hrt normal weiter
				neuesBedienEndeEreignis(f);
			}
			else{
				head.setStatus("blockiert");
				f.getNextHead().setBlockiertesFahrzeug(f);
			}
		}
	}
	
	private void segmentWirdFrei(AmpelTyp2Segment s){
		s.setAktFahrzeug(null);
		s.setStatus("frei");
		
		if(ampelStatus.equals("blockiert")){
			if(kreuzungIstLeer()){
				ampelStatus = "gruen";
				//Autos einfahren lassen TODO
				blockadeAufheben(this,zeit);
			}
		}
		
		//Blockade aufheben
		if(s.getBlockiertesFahrzeug() != null){
			AmpelTyp2Container f = s.getBlockiertesFahrzeug();
			s.setBlockiertesFahrzeug(null);
			f.getHead().setStatus("belegt");
			
			//Geschwindigkeitsverlust durch die Blockade erfassen-!!!!
			f.setGeschwindigkeit(Physik.getGeschwindigkeitsverlustDurchBlockade(f, zeit, segmentlaenge));

			bedienEnde(f);
		}
		else if(s.getWs() != null && einfahrtFrei(s.getWs(),false,null)){	//Eventl. Auto aus WS einfahren lassen!!! 

			AmpelTyp2Container f = (AmpelTyp2Container) s.getWs().pop(zeit);
					
			//Eventl. anfahren in der Gruppe erm�glichen (Geschw. vorteil)
			AmpelTyp2Container letztesF = s.getLetztesFahrzeug();
					
			//Falls das letzte Fahrzeug auch in diesem Segment gestartet ist -> Anfahren in der Gruppe
			if(letztesF != null && letztesF.getEinfahrtSegment() == s){

				f.setGeschwindigkeit(Physik.getGeschwindigkeitBeimAnfahrenInDerGruppe(f, letztesF));
			}	
			//Neues BeidenEndeEreignis f�r das Fahrzeug planen
			neuesBedienEndeEreignis(f);
		}
	}


	public void ankunft(Fahrzeug f) {
		//FahrzeugContainer suchen
		AmpelTyp2Container a = (AmpelTyp2Container)angekuendigteFahrzeuge.holeFahrzeugAusListeNachID(f.getID());
		a.fahrzeugErreichtWS(zeit);
		a.setStandort(this);
		
		//Fahrzeug bereits beim n�chsten Segment anmelden
		double maxNaechstes=a.getAusfahrtSegment().getAusfahrt().getMaxGeschwindigkeit(this,f);
		a.setMaxVfuerNaechstesSegment(maxNaechstes);
		
		//Einfahrendes Segment ermitteln
		AmpelTyp2Segment einfahrt = a.getNextHead();
		
		//Kontrollieren ob das Segment frei und ob eine WS exisitiert 
		//Genauso wie ob die Ampel = gruen ist und ob die Ausfahrt frei
		if(einfahrtFrei(einfahrt.getWs(),true,a)){
			neuesBedienEndeEreignis(a);
		}
		else{
			//Fahrzeug muss in die Warteschlange
			a.setGeschwindigkeit(0.0);//Auto verliert die Geschwindigkeit in der WS
			einfahrt.getWs().push(a,zeit);
		}
	}
	
	private void neuesBedienEndeEreignis(AmpelTyp2Container aktuellesAuto){
		
		aktuellesAuto.setZeitLetztesBedienEnde(zeit);
		
		double zeitpunkt=0.0;
		double maxV = aktuellesAuto.getMaxV();
		double maxNaechstes;
		
		AmpelTyp2Segment frei = aktuellesAuto.getTail(); //Letztes Segment zwischenspeichern
		
		aktuellesAuto.schritt();	//Head und Tail um 1 Segment weiter bewegen
		AmpelTyp2Segment head = aktuellesAuto.getHead();
		AmpelTyp2Segment tail = aktuellesAuto.getTail();
		AmpelTyp2Segment ausfahrt = aktuellesAuto.getAusfahrtSegment();
		
		head.setStatus("belegt");
		
		if(head == ausfahrt){	//Fahrzeug f�hrt aus der Kreuzung aus
			maxNaechstes=aktuellesAuto.getMaxVfuerNaechstesSegment(); //Rausbeschleunigen
		}
		else{	//Fahrzeug f�hrt in der Kreuzung
			maxNaechstes=maxV;
		}
		head.setAktFahrzeug(aktuellesAuto);
		
		if(tail != null && tail != aktuellesAuto.getEinfahrtSegment()){
				// Freigeben des Vorgaengersegments
			segmentWirdFrei(frei);  //eventl. Blockade beheben und aus WS einfahren lassen
		}

		//Geschwindikeiten und Endzeitpunkte berechnen
		zeitpunkt +=physik.zeitBerechnen(segmentlaenge, maxV, maxNaechstes, aktuellesAuto.getFahrzeug());
		//System.out.println("Zeit:"+zeitpunkt);
		zeitpunkt += zeit;
		
		//Ereignis(double zeitpunkt, Fahrzeug fahrzeug, String typ, Simulationsabschnitt standort){
		Ereignis e = new Ereignis(zeitpunkt,aktuellesAuto,"bedienEnde",this);
		logik.pushEreignis(e);
	}

	public double getMaxGeschwindigkeit(Simulationsabschnitt herkunft, Fahrzeug f) {
		//Einfahrt ermitteln
		int einfahrt;
		double maxV;
		if(herkunft == anbindung[0]){
			einfahrt = 0;
		}
		else if(herkunft == anbindung[1]){
			einfahrt = 1;
		}
		else if(herkunft == anbindung[2]){
			einfahrt = 2;
		}
		else if(herkunft == anbindung[3]){
			einfahrt = 3;
		}
		else{
			System.err.println("herkunft: " + f.getStandort());
			System.err.println("anbindung0: " + anbindung[0]);
			System.err.println("anbindung1: " + anbindung[1]);
			System.err.println("Fehlerhafte Herkunft - "+getTyp()+" "+daten.getId()+" Fahrzeug:"+f.getID());
			return 0.0;
		}

		//Abbiegen und Ausfahrt ermitteln
		double sum=0.0;
		for(int i=0;i<3;i++){
			sum += abbiegenWahl[einfahrt][i];
		}
		double tmp=0.0;
		int abbiegen=0;
		double zufallsZahl=Zufallszahlen.drand();
		for(int i=0;i<3;i++){			//Abbiegen ermitteln
			tmp += abbiegenWahl[einfahrt][i]/sum;
			if (zufallsZahl < tmp){
				abbiegen = i;
				break;
			}
		}
		
		int ausfahrt = einfahrt;

		if (abbiegen == 0){	//Rechts abbiegen
			ausfahrt += 3;	
			maxV = Physik.getMaxGeschwindigkeitInDerKurve(0.5*segmentlaenge,f.getHorizontaleBeschleunigung());
		}
		else if (abbiegen == 1){ //Geradeaus fahren
			ausfahrt += 2;
			maxV = 45.0;	//TODO Besserer Wert finden
		}
		else{ 			//Links abbiegen
			ausfahrt += 1;
			maxV = Physik.getMaxGeschwindigkeitInDerKurve(segmentlaenge*1.5,f.getHorizontaleBeschleunigung());
		}

		if (ausfahrt >= 4){
			ausfahrt -= 4;
		}
		
		
		//definition der Route
		
		LinkedList route= new LinkedList();
		if(einfahrt == 0 && abbiegen == 0){
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 0 && abbiegen == 1){
			route.addLast(segment[0][0]);
			route.addLast(segment[1][0]);
			route.addLast(segment[2][0]);
		}
		else if(einfahrt == 0 && abbiegen == 2){
			route.addLast(segment[0][1]);
			route.addLast(segment[0][2]);
			route.addLast(segment[1][2]);
			route.addLast(segment[2][2]);
		}
		else if(einfahrt == 1 && abbiegen == 0){
			route.addLast(segment[0][2]);
		}
		else if(einfahrt == 1 && abbiegen == 1){
			route.addLast(segment[0][2]);
			route.addLast(segment[0][1]);
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 1 && abbiegen == 2){
			route.addLast(segment[1][2]);
			route.addLast(segment[2][2]);
			route.addLast(segment[2][1]);
			route.addLast(segment[2][0]);
		}
		else if(einfahrt == 2 && abbiegen == 0){
			route.addLast(segment[2][2]);
		}
		else if(einfahrt == 2 && abbiegen == 1){
			route.addLast(segment[2][2]);
			route.addLast(segment[1][2]);
			route.addLast(segment[0][2]);
		}
		else if(einfahrt == 2 && abbiegen == 2){
			route.addLast(segment[2][1]);
			route.addLast(segment[2][0]);
			route.addLast(segment[1][0]);
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 3 && abbiegen == 0){
			route.addLast(segment[2][0]);
		}
		else if(einfahrt == 3 && abbiegen == 1){
			route.addLast(segment[2][0]);
			route.addLast(segment[2][1]);
			route.addLast(segment[2][2]);
		}
		else if(einfahrt == 3 && abbiegen == 2){
			route.addLast(segment[1][0]);
			route.addLast(segment[0][0]);
			route.addLast(segment[0][1]);
			route.addLast(segment[0][2]);
		}
		
		//FahrzeugContainer erstellen und in die Ank�ndigungsliste stellen
		AmpelTyp2Container c = 
			new AmpelTyp2Container(f,einfahrt,abbiegen,ausfahrt,route,segmentlaenge);
		c.setVorherigenStandort(herkunft);
		angekuendigteFahrzeuge.push(c);
		c.setMaxV(maxV);
//		System.out.println("MaxV "+Physik.getMaxGeschwindigkeitInDerKurve(daten.getRadius(),f.getHorizontaleBeschleunigung()));
		return maxV;
	}

	public boolean pruefeInitalisierung() {
		if(logik == null){
			return false;
		}

		abbiegenWahl = daten.getAbbiegenWahl();
		
		//�berpr�fen der Strassenanzahl von Einfahrten und Ausfahrten
		int anzahlStrassen=4;
		for(int i=0;i<4;i++){					
			if(anbindung[i] == null){
				
				if(anzahlStrassen < 3){	//Falls es schon nur 2 Strassen hat
					System.err.println("Fehler: " +daten.getName()+" hat zuwenig Strassen / "+anzahlStrassen+"/"+i);
					return false;	//TODO Kontrollieren
				}
				anzahlStrassen--;


				 //Abbiegen in die nicht existierende Strasse verhindern
				for(int j=0;j<3;j++){
					int strasse=i + (j+1);
					
					if(strasse > 3){
						strasse -=4;
					}
					
					abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
				}
			}
			else{
				//F�r jede Strasse, welche in die Kreuzung m�ndet muss min. 1 andere wieder weg f�hren
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenZurKreuzung(daten.getId()) > 0){
					
					boolean ausfahrtVorhanden=false;
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						if(anbindung[strasse] != null){
							if(((NormaleStrasse)anbindung[strasse]).getAnzahlSpurenVonKreuzungWeg(daten.getId()) > 0){
								ausfahrtVorhanden=true;
								break;
							}
						}
					}
					
					if(!ausfahrtVorhanden){
						System.err.println("Fehler: " +daten.getName()+" hat zuwenig Ausfahrt");
						return false;	//TODO Kontrollieren
					}
				}
				
				//Falls es eine Einbahnstrasse ist
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenVonKreuzungWeg(daten.getId())<1){
					 //Falsches Abbiegen in die Einbahnstrasse verhindern
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
					}
				}
			}
		}
		daten.setAbbiegenWahl(abbiegenWahl);
		
		//Initialisierungszeug-------------------------->
		ampelPhase=0;
		ampelStatus="gruen";
		double offset = daten.getOffset();
		
		//Eine Richtung an die keine Strasse h�ngt oder keine Einfahrt braucht keine Gr�nphase
		for(int i=0;i<4;i++){
			if(anbindung[i] == null || ((NormaleStrasse)anbindung[i]).getAnzahlSpurenZurKreuzung(daten.getId()) <= 0){
				ampelSchaltZeiten[i] = 0.0;//TODO Merken
			}
		}
		
		//Verhindern einer Gelbphase falls die L�nge einer ampelPhase = 0
		double gesamtlaenge = 0.0;
		for(int i=0;i<4;i++){
			if(ampelSchaltZeiten[i] <= 0.01){
				ampelGelbphaseDauer[i] -= daten.getGelbPhasenDauer();
			}
			
			gesamtlaenge += ampelSchaltZeiten[i];
		}
		
		if(gesamtlaenge <= 0.0){
			System.err.println("Fehler: " +daten.getName()+" hat keine Gr�nphase");
			return false;
		}
		
		//Einstellen der richtigen Ampelphase nach dem Offset
		Ereignis e;
		if(offset > 0.0){
			int i=0;
			while(offset>0.0){
				if(i==0){
					offset -= ampelSchaltZeiten[ampelPhase];
					ampelStatus = "gruen";
					i=1;
				}
				else{
					offset -= ampelGelbphaseDauer[ampelPhase];
					ampelStatus = "rot";
					i=0;
				}
				
				if(i==0 && offset>0.0){
					ampelPhase++;
					if(ampelPhase >= 4){
						ampelPhase -= 4;
					}
				}
			}
			if(i == 0){
				e = new Ereignis(zeit+Math.abs(offset),null, "ampelWirdGruen",this);
				//System.out.println("ID"+daten.getId()+" Phase"+ampelPhase+" Gruen bei "+offset);
			}
			else{
				e = new Ereignis(zeit+Math.abs(offset),null, "ampelWirdRot",this);
				//System.out.println("ID"+daten.getId()+" Phase"+ampelPhase+" Rot bei "+offset);
			}
		}
		else if(offset < 0.0){
			int i=1;
			ampelPhase = 3;
			double tmp =0.0;
			while(offset<0.0){
				tmp=0.0;
				
				if(i==0){
					tmp = ampelSchaltZeiten[ampelPhase];
					ampelStatus = "gruen";
					i=1;
				}
				else{
					tmp = ampelGelbphaseDauer[ampelPhase];
					ampelStatus = "rot";
					i=0;
				}
				
				
				offset += tmp;
				
				if(i==1 && offset<0.0){
					ampelPhase--;
					if(ampelPhase < 0){
						ampelPhase += 4;
					}
				}
			}
			if(i == 0){
				e = new Ereignis(zeit+tmp-Math.abs(offset),null, "ampelWirdGruen",this);
				//e = new Ereignis(zeit+ampelGelbphaseDauer-Math.abs(offset),null, "ampelWirdGruen",this);
				//System.out.println("ID"+daten.getId()+" Phase"+ampelPhase+" Gruen bei "+(ampelGelbphaseDauer-offset));
			}
			else{
				e = new Ereignis(zeit+tmp-Math.abs(offset),null, "ampelWirdRot",this);
				//e = new Ereignis(zeit+ampelSchaltZeiten[ampelPhase]-Math.abs(offset),null, "ampelWirdRot",this);
				//System.out.println("ID"+daten.getId()+" Phase"+ampelPhase+" Rot bei "+(ampelSchaltZeiten[ampelPhase]-offset));
			}
		}
		else{
			e = new Ereignis(zeit+ampelSchaltZeiten[ampelPhase],null, "ampelWirdRot",this);
		}
		logik.pushEreignis(e);
		
		//L�nge der Linksabbiegrespur, initialisieren
		double[] laenge = daten.getLaengeAbbiegeSpur();	//Laengenanpassung f�r Linksabbieger
		for(int i=0;i<4;i++){
			if(anbindung[i] != null && anbindung[i].getLaengeFuerWS(this) < laenge[i]){
				laenge[i] = anbindung[i].getLaengeFuerWS(this);
			}
		}
		
		//Vor WS initialisieren
		for(int i=0;i<4;i++){
			double vorWSlaenge = 2.0;
			if(anbindung[i] != null && anbindung[i].getLaengeFuerWS(this) > laenge[i]){
				vorWSlaenge = anbindung[i].getLaengeFuerWS(this) - laenge[i];
			}
			vorWS[i] = new Warteschlange((NormaleStrasse)anbindung[i],this,vorWSlaenge);
		}
		
		//WS initialisieren
		for(int i=0;i<4;i++){
			for(int j=0;j<2;j++){
				wsNachRichtung[i][j] = new Warteschlange(null,this,laenge[i]);
				wsNachRichtung[i][j].setVorWS(vorWS[i]);
			}
		}
		
		ws[0][0] = wsNachRichtung[0][0];
		ws[1][0] = wsNachRichtung[0][1];
		ws[2][0] = wsNachRichtung[1][0];
		ws[3][0] = wsNachRichtung[1][1];
		ws[0][1] = wsNachRichtung[2][0];
		ws[1][1] = wsNachRichtung[2][1];
		ws[2][1] = wsNachRichtung[3][0];
		ws[3][1] = wsNachRichtung[3][1];
		
		vorWS[0].setBeschreibung("Vorgelagert-Nord");
		vorWS[1].setBeschreibung("Vorgelagert-Ost ");
		vorWS[2].setBeschreibung("Vorgelagert-S�d ");
		vorWS[3].setBeschreibung("Vorgelagert-West");
		
		wsNachRichtung[0][0].setBeschreibung("Nord: Rechts/Gerade");
		wsNachRichtung[0][1].setBeschreibung("Nord: Links");
		wsNachRichtung[1][0].setBeschreibung("Ost: Rechts/Gerade");
		wsNachRichtung[1][1].setBeschreibung("Ost: Links");
		wsNachRichtung[2][0].setBeschreibung("S�d: Rechts/Gerade");
		wsNachRichtung[2][1].setBeschreibung("S�d: Links");
		wsNachRichtung[3][0].setBeschreibung("West: Rechts/Gerade");
		wsNachRichtung[3][1].setBeschreibung("West: Links");
		
		//Segmente initialisieren
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				segment[i][j] = new AmpelTyp2Segment(i*10+j);
			}
		}
			//Einfahrten zuteilen
		einfahrt[0][0] = segment[0][0];
		einfahrt[1][0] = segment[0][1];
		einfahrt[2][0] = segment[0][2];
		einfahrt[3][0] = segment[1][2];
		einfahrt[0][1] = segment[2][2];
		einfahrt[1][1] = segment[2][1];
		einfahrt[2][1] = segment[2][0];
		einfahrt[3][1] = segment[1][0];
		
		for(int i=0;i<4;i++){	//WS den Einfahrten bekannt machen
			for(int j=0;j<2;j++){
				einfahrt[i][j].setWs(ws[i][j]);
			}
		}

		segment[0][0].setAusfahrt(anbindung[3]);
		segment[0][2].setAusfahrt(anbindung[0]);
		segment[2][2].setAusfahrt(anbindung[1]);
		segment[2][0].setAusfahrt(anbindung[2]);
		
		return true;
	}

	public String getTyp() {
		return "AmpelTyp2";
	}

	public int getID() {
		return daten.getId();
	}

	public int getMaxAnbindungen() {
		return 4;
	}

	public void setSimulationslogik(Simulationslogik logik) {
		this.logik = logik;
	}

	public boolean isBlockiert(Simulationsabschnitt aufrufer) {
		return false; //Kreuzung ist (momentan) nicht blockierbar
	}

	public void setBlockiert(Simulationsabschnitt aufrufer, double zeit) {
//		Kreuzung ist (momentan) nicht blockierbar
	}

	public void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit) {
		this.zeit = zeit; //aktuelle Zeit setzen
		autosAusWsEinfahrenLassen();
	}
	
	private void autosAusWsEinfahrenLassen(){
		for(int j=0;j<2;j++){
			if(einfahrtFrei(ws[ampelPhase][j],false,null)){
				neuesBedienEndeEreignis((AmpelTyp2Container)ws[ampelPhase][j].pop(zeit));
			}
		}
	}

	
	private boolean einfahrtFrei(Warteschlange ws, boolean ankunft, AmpelTyp2Container auto){
		int i=-1;

		if(ankunft && ws.getLaenge(zeit) == 0){
			if(ws.getVorWS() != null && ws.getVorWS().getLaenge(zeit) > 0){
				return false;	//Auto darf nicht durchfahren, falls VorWS nicht leer
			}
			if(auto == null){
				System.err.println("Fehlerhafter Auruf von einfahrtFrei");
				return false;
			}
		}
		else if(!ankunft && ws.getLaenge(zeit) > 0){
			auto = (AmpelTyp2Container) ws.nextFahrzeug();
		}
		else{
			return false;
		}
		
		if(ws == this.ws[ampelPhase][0]){
			i = 0;
		}
		else if(ws == this.ws[ampelPhase][1]){
			i = 1;
		}
		else{
			return false;
		}
		
		
		if(ampelStatus.equals("gruen") && einfahrt[ampelPhase][i].getStatus().equals("frei")
				&& !anbindung[auto.getAusfahrt()].isBlockiert(this)){
			return true;
			//�berpr�fen ob ganze Kreuzung leer TODO
		}
		
		return false;
	}
	
	private boolean kreuzungIstLeer(){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(!segment[i][j].getStatus().equals("frei")){
					return false;
				}
			}
		}
		return true;
	}


	public double getLaengeFuerWS(Simulationsabschnitt aufrufer) {
		return 3.0; //Kreuzung bietet kaum Platz f�r eine WS
	}
	
	public Status getStatus() {
		Status s = new Status(daten.getId());
		s.setAnzahlWS(4);
		int[] wsId = new int[4]; 
		int[] wsLaenge = new int[4]; 
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				wsId[i] = anbindung[i].getID();
			}
			else{
				wsId[i] = -1;
			}
		}
		
		wsLaenge[0] = ws[0][0].getLaenge(zeit) + ws[1][0].getLaenge(zeit) + vorWS[0].getLaenge(zeit);
		wsLaenge[1] = ws[2][0].getLaenge(zeit) + ws[3][0].getLaenge(zeit) + vorWS[1].getLaenge(zeit);
		wsLaenge[2] = ws[0][1].getLaenge(zeit) + ws[1][1].getLaenge(zeit) + vorWS[2].getLaenge(zeit);
		wsLaenge[3] = ws[2][1].getLaenge(zeit) + ws[3][1].getLaenge(zeit) + vorWS[3].getLaenge(zeit);
		
		String info="";
		info += "Ampelphase: " + Integer.toString(ampelPhase)+"\n";
		info += "Status: " + ampelStatus + "\n";
		int anzahlBelegterSegmente=0;
		
		info += "Segment�bersicht\n";
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(segment[i][j].getStatus() != "frei"){
					anzahlBelegterSegmente++;
					////info += "Segment "+Integer.toString(i)+Integer.toString(j)+" Belegt durch ";
					//info += Integer.toString(segment[i][j].getAktFahrzeug().getID())+"\t";
				}
				else{
					//info +="\t";
				}
				info += getSegmentStatus(i, j);
			}
			info += "\n";
		}
		
		
		info += "Belegte Segmente: " + Integer.toString(anzahlBelegterSegmente);
		
		s.setInfoText(info);
		s.setWsId(wsId);
		s.setWsLaenge(wsLaenge);
		return s;
	}
	
	private String getSegmentStatus(int i, int j){
		if(segment[i][j].getAktFahrzeug() != null){
			return Integer.toString(segment[i][j].getAktFahrzeug().getID())+"\t";
		}
		else{
			return "__\t";
		}
	}
	
}
