/*
 * Created on 29.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ampelTyp2;

import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Warteschlange;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AmpelTyp2Segment {
	
	private int nummer;
	private AmpelTyp2Container aktFahrzeug;
	private AmpelTyp2Container letztesFahrzeug;
	private String status;
	private Warteschlange ws;
	private Simulationsabschnitt ausfahrt;
	private AmpelTyp2Container blockiertesFahrzeug;

	public AmpelTyp2Segment(int nummer) {
		this.nummer = nummer;
		aktFahrzeug = null;
		status = "frei";
		ws=null;
		ausfahrt=null;
		blockiertesFahrzeug=null;
	}

	/**
	 * @return Returns the blockiertesFahrzeug.
	 */
	public AmpelTyp2Container getBlockiertesFahrzeug() {
		return blockiertesFahrzeug;
	}
	/**
	 * @param blockiertesFahrzeug The blockiertesFahrzeug to set.
	 */
	public void setBlockiertesFahrzeug(
			AmpelTyp2Container blockiertesFahrzeug) {
		this.blockiertesFahrzeug = blockiertesFahrzeug;
	}
	/**
	 * @return Returns the ausfahrt.
	 */
	public Simulationsabschnitt getAusfahrt() {
		return ausfahrt;
	}
	/**
	 * @param ausfahrt The ausfahrt to set.
	 */
	public void setAusfahrt(Simulationsabschnitt ausfahrt) {
		this.ausfahrt = ausfahrt;
	}
	/**
	 * @return Returns the ws.
	 */
	public Warteschlange getWs() {
		return ws;
	}
	/**
	 * @param ws The ws to set.
	 */
	public void setWs(Warteschlange ws) {
		this.ws = ws;
	}
	/**
	 * @return Returns the aktuelleFahrzeug.
	 */
	public AmpelTyp2Container getAktFahrzeug() {
		return aktFahrzeug;
	}
	/**
	 * @param aktFahrzeug The aktuelleFahrzeug to set.
	 */
	public void setAktFahrzeug(AmpelTyp2Container aktFahrzeug) {
		this.letztesFahrzeug = this.aktFahrzeug;
		this.aktFahrzeug = aktFahrzeug;
	}
	/**
	 * @return Returns the letztesFahrzeug.
	 */
	public AmpelTyp2Container getLetztesFahrzeug() {
		return letztesFahrzeug;
	}
	/**
	 * @return Returns the nummer of the Segment.
	 */
	public int getNummer() {
		return nummer;
	}
	
	
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
