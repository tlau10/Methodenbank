/*
 * Created on 29.09.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ampelTyp2;

import verkehrsplaner.AmpelEinstellungenMitAbbiegespur;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AmpelTyp2Einstellungen implements AmpelEinstellungenMitAbbiegespur{
	private static final long serialVersionUID = 1L;

	//Algemeines
	private int id=0;
	private String type="AmpelTyp2Einstellungen";
	private String name="Ampel";

	private int[] anbindungen = {-1, -1, -1, -1};
	
	private double[][] abbiegenWahl = {{0.33, 0.33, 0.33}, { 0.33, 0.33, 0.33},	
									{0.33, 0.33, 0.33}, {0.33, 0.33, 0.33}}; //Wahrkeit fuer Abbiegen je nach Einfahrt
	
	//Ampel
	private double offset=0.0;
	private double breite=9.0;
	private double[] ampelSchaltZeiten = {20.0, 10.0, 20.0, 10.0}; //Schaltzeiten fuer jede Richtung
	private double[] laengeAbbiegeSpur = {20.0, 20.0, 20.0, 20.0}; //L�nge der Linksabbiegerspur fuer jede Richtung
	private double gelbPhasenDauer = 2.0;
	private double laengeFussgaengerPhase = 0.0;
	
	//GUI
	private int x=100;
	private int y=100;
	private int modus=0;
	
	public AmpelTyp2Einstellungen(){
	}
	
	public int[] getAnbindungen() {
		return anbindungen;
	}

	public void setAnbindungen(int[] anbindungen) {
		this.anbindungen = anbindungen;
	}
	public double getBreite() {
		return breite;
	}

	public void setBreite(double breite) {
		this.breite = breite;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public double[][] getAbbiegenWahl() {
		return abbiegenWahl;
	}
	public void setAbbiegenWahl(double[][] abbiegenWahl) {
		this.abbiegenWahl = abbiegenWahl;
	}
	public double[] getAmpelSchaltZeiten() {
		return ampelSchaltZeiten;
	}
	public void setAmpelSchaltZeiten(double[] ampelSchaltZeiten) {
		this.ampelSchaltZeiten = ampelSchaltZeiten;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public double[] getLaengeAbbiegeSpur() {
		return laengeAbbiegeSpur;
	}
	public void setLaengeAbbiegeSpur(double[] laengeAbbiegeSpur) {
		this.laengeAbbiegeSpur = laengeAbbiegeSpur;
	}
	
	public double getOffset() {
		return offset;
	}
	public void setOffset(double offset) {
		this.offset = offset;
	}
	
	public double getGelbPhasenDauer() {
		return gelbPhasenDauer;
	}
	public void setGelbPhasenDauer(double gelbPhasenDauer) {
		this.gelbPhasenDauer = gelbPhasenDauer;
	}
	
	public int getModus() {//Automatik Modi
		return modus;
	}
	public void setModus(int modus) {
		this.modus = modus;
	}
	
	public double getLaengeFussgaengerPhase() {
		return laengeFussgaengerPhase;
	}
	public void setLaengeFussgaengerPhase(double laengeFussgaengerPhase) {
		this.laengeFussgaengerPhase = laengeFussgaengerPhase;
	}
}
