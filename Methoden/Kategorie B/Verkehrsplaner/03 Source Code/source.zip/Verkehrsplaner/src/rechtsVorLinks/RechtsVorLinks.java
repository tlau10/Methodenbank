/*
 * Created on 29.10.2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package rechtsVorLinks;

import java.util.LinkedList;

import verkehrsplaner.Ereignis;
import verkehrsplaner.Ergebnis;
import verkehrsplaner.Fahrzeug;
import verkehrsplaner.FahrzeugListe;
import verkehrsplaner.Kreuzung;
import verkehrsplaner.NormaleStrasse;
import verkehrsplaner.Physik;
import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Simulationslogik;
import verkehrsplaner.Status;
import verkehrsplaner.Warteschlange;
import verkehrsplaner.Zufallszahlen;

/**
 * @author Christian Gruhler
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RechtsVorLinks implements Kreuzung {

	private RechtsVorLinksEinstellungen daten;
	private Simulationslogik logik;
	private Physik physik;
	private FahrzeugListe angekuendigteFahrzeuge;
	private Simulationsabschnitt[] anbindung;
	private double zeit;
	
	private double segmentlaenge;
	
	private double zeitBisAnkunft = 2.0; //Zeit welche beachtet werden muss ob sich ein Fahrzeug n�hrt
	
	private double[][] abbiegenWahl; //Wahrkeit fuer Abbiegen je nach Einfahrt
	
	private Warteschlange[] ws = new Warteschlange[4];
	private RechtsVorLinksSegment[] einfahrt = new RechtsVorLinksSegment[4];
	
	private RechtsVorLinksSegment[][] segment = new RechtsVorLinksSegment[2][2];
	
	
	public RechtsVorLinks(RechtsVorLinksEinstellungen daten){
		this.daten = daten;
		
		angekuendigteFahrzeuge = new FahrzeugListe();
		anbindung = new Simulationsabschnitt[4];
		physik = new Physik();
		segmentlaenge=daten.getBreite()/2.0;
	}
	

	public Ergebnis getErgebnis() {
		Ergebnis e = new Ergebnis(daten.getId());
		
		for(int i=0;i<4;i++){
			e.addWS(ws[i].getErgebnis());
		}
		

		int[] anzahlFahrzeuge = {0,0,0,0};
		double[] durchsWSlaenge = {0.0,0.0,0.0,0.0};
		double[] durchsWartezeit = {0.0,0.0,0.0,0.0};
		double[] prozAuslastung = {0.0,0.0,0.0,0.0};
		double[] prozStau = {0.0,0.0,0.0,0.0};
		int[] maxLaenge = {0,0,0,0};
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				
//			 	aktuelle WS l�nge
				anzahlFahrzeuge[i] = e.getWS(i).getAnzahlFahrzeuge();

//				 durchs. WS l�nge
				durchsWSlaenge[i] = e.getWS(i).getDurchsWartendeFahrzeuge();

//				 durchs. Wartezeit
				durchsWartezeit[i] = e.getWS(i).getDurchsVerweilzeitWS();

//				 proz. Stra�enauslastung
				prozAuslastung[i] = e.getWS(i).getProzentualeStrassenauslastung();
					
//				 proz. Stau
				prozStau[i] = e.getWS(i).getProzentualBlockiert();

//				Max WS L�nge
				maxLaenge[i] = e.getWS(i).getMaxAnzahlFahrzeuge();
			}
		}
		
		e.setAnzahlFahrzeuge(anzahlFahrzeuge);
		e.setDurchsWSlaenge(durchsWSlaenge);
		e.setDurchsWartezeit(durchsWartezeit);
		e.setProzAuslastung(prozAuslastung);
		e.setProzStau(prozStau);
		e.setMaxLaenge(maxLaenge);
		
		return e;
	}

	public void addAnbindung(Simulationsabschnitt anbindung, int himmelsrichtung) {
		if(himmelsrichtung >= 0 && himmelsrichtung < 4){
			this.anbindung[himmelsrichtung] = anbindung;
		}
		else{
			System.err.println("Fehlerhafte Zuweisung - Stra�e "+daten.getId()+" Richtung:"+himmelsrichtung);
		}
	}

	public void ereignisHandler(Ereignis e) {
		zeit=e.getZeitpunkt();
		
		//System.out.println(e.getFahrzeug().getID()+"V: "+e.getFahrzeug().getGeschwindigkeit());
		
		if(e.getTyp().equals("ankunft")){
			ankunft(e.getFahrzeug());
		}
		else if (e.getTyp().equals("bedienEnde")){
			bedienEnde(((RechtsVorLinksContainer) e.getFahrzeug()));
		}
		else{
			System.err.println("Unbekanntes Ereignis" + e.getTyp());
		}
	}
	
	private void bedienEnde(RechtsVorLinksContainer f){
		
		RechtsVorLinksSegment head = f.getHead();
		RechtsVorLinksSegment tail = f.getTail();
		
		//Verl�sst das Auto die Kreuzung?
		if(head == f.getAusfahrtSegment()){
			if (head==tail){//Das Auto-Heck verl�sst die Kreuzung
				Ereignis e = new Ereignis(logik.getZeit(), f, "ankunft", head.getAusfahrt());
				logik.pushEreignis(e);
				segmentWirdFrei(head); //eventl. Blockade beheben und aus WS einfahren lassen
				
				//TODO eventl. andere Autos einfahren lassen
				autosAusWsEinfahrenLassen();
			}
			else{
				neuesBedienEndeEreignis(f);
			}
		}
		else{
			//Auto f�hrt weiter
			if(f.getNextHead().getStatus().equals("frei")){ //Auto f�hrt normal weiter
				neuesBedienEndeEreignis(f);
			}
			else{
				head.setStatus("blockiert");
				f.getNextHead().setBlockiertesFahrzeug(f);
			}
		}
	}
	
	private void segmentWirdFrei(RechtsVorLinksSegment s){
		s.setAktFahrzeug(null);
		s.setStatus("frei");
	}


	public void ankunft(Fahrzeug f) {
		//FahrzeugContainer suchen
		RechtsVorLinksContainer a = (RechtsVorLinksContainer)angekuendigteFahrzeuge.holeFahrzeugAusListeNachID(f.getID());
		a.fahrzeugErreichtWS(zeit);
		a.setStandort(this);
		
		//Fahrzeug bereits beim n�chsten Segment anmelden
		double maxNaechstes=a.getAusfahrtSegment().getAusfahrt().getMaxGeschwindigkeit(this,f);
		a.setMaxVfuerNaechstesSegment(maxNaechstes);
		
		//Einfahrendes Segment ermitteln
		RechtsVorLinksSegment einfahrt = a.getNextHead();
		
		//Kontrollieren ob das Segment frei und ob eine WS exisitiert 
		//Genauso wie ob die Ampel = gruen ist
		if(einfahrtFrei(a.getEinfahrt(),true,a)){
			neuesBedienEndeEreignis(a);
		}
		else{
			//Fahrzeug muss in die Warteschlange
			a.setGeschwindigkeit(0.0);//Auto verliert die Geschwindigkeit in der WS
			einfahrt.getWs().push(a,zeit);
			autosAusWsEinfahrenLassen();
		}
	}
	
	private void neuesBedienEndeEreignis(RechtsVorLinksContainer aktuellesAuto){
		
		aktuellesAuto.setZeitLetztesBedienEnde(zeit);
		
		double zeitpunkt=0.0;
		double maxV = aktuellesAuto.getMaxV();
		double maxNaechstes;
		
		RechtsVorLinksSegment frei = aktuellesAuto.getTail(); //Letztes Segment zwischenspeichern
		
		aktuellesAuto.schritt();	//Head und Tail um 1 Segment weiter bewegen
		RechtsVorLinksSegment head = aktuellesAuto.getHead();
		RechtsVorLinksSegment tail = aktuellesAuto.getTail();
		RechtsVorLinksSegment ausfahrt = aktuellesAuto.getAusfahrtSegment();
		
		head.setStatus("belegt");
		
		if(head == ausfahrt){	//Fahrzeug f�hrt aus der Kreuzung aus
			maxNaechstes=aktuellesAuto.getMaxVfuerNaechstesSegment(); //Rausbeschleunigen
		}
		else{	//Fahrzeug f�hrt in der Kreuzung
			maxNaechstes=maxV;
		}
		head.setAktFahrzeug(aktuellesAuto);
		
		if(tail != null && tail != aktuellesAuto.getEinfahrtSegment()){
				// Freigeben des Vorgaengersegments
			segmentWirdFrei(frei);  //eventl. Blockade beheben und aus WS einfahren lassen
		}

		//Geschwindikeiten und Endzeitpunkte berechnen
		zeitpunkt +=physik.zeitBerechnen(segmentlaenge, maxV, maxNaechstes, aktuellesAuto.getFahrzeug());
		//System.out.println("Zeit:"+zeitpunkt);
		zeitpunkt += zeit;
		
		//Ereignis(double zeitpunkt, Fahrzeug fahrzeug, String typ, Simulationsabschnitt standort){
		Ereignis e = new Ereignis(zeitpunkt,aktuellesAuto,"bedienEnde",this);
		logik.pushEreignis(e);
	}

	public double getMaxGeschwindigkeit(Simulationsabschnitt herkunft, Fahrzeug f) {
		//Einfahrt ermitteln
		int einfahrt;
		double maxV=15.0; //TODO Besseren Wert finden
		double tmpMaxV=15.0;
		
		if(herkunft == anbindung[0]){
			einfahrt = 0;
		}
		else if(herkunft == anbindung[1]){
			einfahrt = 1;
		}
		else if(herkunft == anbindung[2]){
			einfahrt = 2;
		}
		else if(herkunft == anbindung[3]){
			einfahrt = 3;
		}
		else{
			System.err.println("herkunft: " + f.getStandort());
			System.err.println("anbindung0: " + anbindung[0]);
			System.err.println("anbindung1: " + anbindung[1]);
			System.err.println("Fehlerhafte Herkunft - "+getTyp()+" "+daten.getId()+" Fahrzeug:"+f.getID());
			return 0.0;
		}

		//Abbiegen und Ausfahrt ermitteln
		double sum=0.0;
		for(int i=0;i<3;i++){
			sum += abbiegenWahl[einfahrt][i];
		}
		double tmp=0.0;
		int abbiegen=0;
		double zufallsZahl=Zufallszahlen.drand();
		for(int i=0;i<3;i++){			//Abbiegen ermitteln
			tmp += abbiegenWahl[einfahrt][i]/sum;
			if (zufallsZahl < tmp){
				abbiegen = i;
				break;
			}
		}
		
		int ausfahrt = einfahrt;

		if (abbiegen == 0){	//Rechts abbiegen
			ausfahrt += 3;	
			tmpMaxV = Physik.getMaxGeschwindigkeitInDerKurve(segmentlaenge*0.5,f.getHorizontaleBeschleunigung());
		}
		else if (abbiegen == 1){ //Geradeaus fahren
			ausfahrt += 2;
		}
		else{ 			//Links abbiegen
			ausfahrt += 1;
			tmpMaxV = Physik.getMaxGeschwindigkeitInDerKurve(segmentlaenge*1.5,f.getHorizontaleBeschleunigung());
		}

		if(tmpMaxV < maxV){
			maxV = tmpMaxV;
		}
		
		if (ausfahrt >= 4){
			ausfahrt -= 4;
		}
		
		
		//definition der Route
		
		LinkedList route= new LinkedList();
		if(einfahrt == 0 && abbiegen == 0){
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 0 && abbiegen == 1){
			route.addLast(segment[0][0]);
			route.addLast(segment[1][0]);
		}
		else if(einfahrt == 0 && abbiegen == 2){
			route.addLast(segment[0][0]);
			route.addLast(segment[1][0]);
			route.addLast(segment[1][1]);
		}
		else if(einfahrt == 1 && abbiegen == 0){
			route.addLast(segment[0][1]);
		}
		else if(einfahrt == 1 && abbiegen == 1){
			route.addLast(segment[0][1]);
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 1 && abbiegen == 2){
			route.addLast(segment[0][1]);
			route.addLast(segment[0][0]);
			route.addLast(segment[1][0]);
		}
		else if(einfahrt == 2 && abbiegen == 0){
			route.addLast(segment[1][1]);
		}
		else if(einfahrt == 2 && abbiegen == 1){
			route.addLast(segment[1][1]);
			route.addLast(segment[0][1]);
		}
		else if(einfahrt == 2 && abbiegen == 2){
			route.addLast(segment[1][1]);
			route.addLast(segment[0][1]);
			route.addLast(segment[0][0]);
		}
		else if(einfahrt == 3 && abbiegen == 0){
			route.addLast(segment[1][0]);
		}
		else if(einfahrt == 3 && abbiegen == 1){
			route.addLast(segment[1][0]);
			route.addLast(segment[1][1]);
		}
		else if(einfahrt == 3 && abbiegen == 2){
			route.addLast(segment[1][0]);
			route.addLast(segment[1][1]);
			route.addLast(segment[0][1]);
		}
		
		//FahrzeugContainer erstellen und in die Ank�ndigungsliste stellen
		RechtsVorLinksContainer c = 
			new RechtsVorLinksContainer(f,einfahrt,abbiegen,ausfahrt,route,segmentlaenge);
		c.setVorherigenStandort(herkunft);
		angekuendigteFahrzeuge.push(c);
		c.setMaxV(maxV);
//		System.out.println("MaxV "+Physik.getMaxGeschwindigkeitInDerKurve(daten.getRadius(),f.getHorizontaleBeschleunigung()));
		return maxV;
	}

	public boolean pruefeInitalisierung() {
		if(logik == null){
			return false;
		}

		abbiegenWahl = daten.getAbbiegenWahl();
		
		//�berpr�fen der Strassenanzahl von Einfahrten und Ausfahrten
		int anzahlStrassen=4;
		for(int i=0;i<4;i++){
			if(anbindung[i] == null){
				
				if(anzahlStrassen < 3){	//Falls es schon nur 2 Strassen hat
					System.err.println("Fehler: " +daten.getName()+" hat zuwenig Strassen / "+anzahlStrassen+"/"+i);
					return false;	//TODO Kontrollieren
				}
				anzahlStrassen--;


				 //Abbiegen in die nicht existierende Strasse verhindern
				for(int j=0;j<3;j++){
					int strasse=i + (j+1);
					
					if(strasse > 3){
						strasse -=4;
					}
					
					abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
				}
			}
			else{
				//F�r jede Strasse, welche in die Kreuzung m�ndet muss min. 1 andere wieder weg f�hren
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenZurKreuzung(daten.getId()) > 0){
					
					boolean ausfahrtVorhanden=false;
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						if(anbindung[strasse] != null){
							if(((NormaleStrasse)anbindung[strasse]).getAnzahlSpurenVonKreuzungWeg(daten.getId()) > 0){
								ausfahrtVorhanden=true;
								break;
							}
						}
					}
					
					if(!ausfahrtVorhanden){
						System.err.println("Fehler: " +daten.getName()+" hat zuwenig Ausfahrt");
						return false;	//TODO Kontrollieren
					}
				}
				
				//Falls es eine Einbahnstrasse ist
				if(((NormaleStrasse)anbindung[i]).getAnzahlSpurenVonKreuzungWeg(daten.getId())<1){
					 //Falsches Abbiegen in die Einbahnstrasse verhindern
					for(int j=0;j<3;j++){
						int strasse=i + (j+1);
						
						if(strasse > 3){
							strasse -=4;
						}
						
						abbiegenWahl[strasse][j] = 0.0; //Entfernen der Rechts/Gerade/Links abbieger
					}
				}
			}
		}
		daten.setAbbiegenWahl(abbiegenWahl);
		
		//Initialisierungszeug-------------------------->
		
		//WS initialisieren
		for(int i=0;i<4;i++){
			if(anbindung[i] != null)
				ws[i] = new Warteschlange((NormaleStrasse)anbindung[i],this,anbindung[i].getLaengeFuerWS(this));
			else
				ws[i] = new Warteschlange(null,this,2.0);
		}

		ws[0].setBeschreibung("Nord");
		ws[1].setBeschreibung("Ost");
		ws[2].setBeschreibung("S�d");
		ws[3].setBeschreibung("West");
		

		//Segmente initialisieren
		for(int i=0;i<2;i++){
			for(int j=0;j<2;j++){
				segment[i][j] = new RechtsVorLinksSegment(i*10+j);
			}
		}
			//Einfahrten zuteilen
		einfahrt[0] = segment[0][0];
		einfahrt[1] = segment[0][1];
		einfahrt[2] = segment[1][1];
		einfahrt[3] = segment[1][0];

		
		for(int i=0;i<4;i++){	//WS den Einfahrten bekannt machen
			einfahrt[i].setWs(ws[i]);
		}

		segment[0][1].setAusfahrt(anbindung[0]);
		segment[1][1].setAusfahrt(anbindung[1]);
		segment[1][0].setAusfahrt(anbindung[2]);
		segment[0][0].setAusfahrt(anbindung[3]);
		
		return true;
	}

	public String getTyp() {
		return "RechtsVorLinks";
	}

	public int getID() {
		return daten.getId();
	}

	public int getMaxAnbindungen() {
		return 4;
	}

	public void setSimulationslogik(Simulationslogik logik) {
		this.logik = logik;
	}

	public boolean isBlockiert(Simulationsabschnitt aufrufer) {
		return false; //Kreuzung ist (momentan) nicht blockierbar
	}

	public void setBlockiert(Simulationsabschnitt aufrufer, double zeit) {
//		Kreuzung ist (momentan) nicht blockierbar
	}

	public void blockadeAufheben(Simulationsabschnitt aufrufer, double zeit) {
		this.zeit = zeit;	//aktuelle Zeit
		autosAusWsEinfahrenLassen();
	}
	
	//Autos per Zufall einfahren lassen
	private void autosAusWsEinfahrenLassen(){
		int zaehlerWS=0;
		
		int tmp = Zufallszahlen.ganzZahlZiehen(0,3);
		
		for(int i=0;i<4;i++){ //Auto welchen die Einfahrt m�glich ist -> einfahren lassen
			if(einfahrtFrei(tmp,false,null)){
				neuesBedienEndeEreignis((RechtsVorLinksContainer)ws[tmp].pop(zeit));
				break;
			}
			else if(ws[tmp].getLaenge(zeit)>0){
				zaehlerWS++;
			}
			
			tmp--;
			if(tmp < 0)
				tmp += 4;
		}
		
//		Falls von allen Seiten Fahrzeuge kommen -- Blockadesituation TODO
		if(zaehlerWS == 4 && kreuzungIstLeer()){
			//Zuf�llig ein Fahrzeug einfahren lassen
			neuesBedienEndeEreignis((RechtsVorLinksContainer)ws[tmp].pop(zeit));
		}
	}

	
	private boolean einfahrtFrei(int wsNr, boolean ankunft, RechtsVorLinksContainer auto){

		if(ankunft && ws[wsNr].getLaenge(zeit) == 0){
			if(auto == null){
				System.err.println("Fehlerhafter Auruf von einfahrtFrei");
				return false;
			}
		}
		else if(!ankunft && ws[wsNr].getLaenge(zeit) > 0){
			auto = (RechtsVorLinksContainer) ws[wsNr].nextFahrzeug();
		}
		else{
			return false;
		}
		
		if(vonRechtsKommtNichts(wsNr) && kreuzungIstLeer()
				&& !anbindung[auto.getAusfahrt()].isBlockiert(this)){
			return true;
		}
		
		return false;
	}
	
	private boolean vonRechtsKommtNichts(int wsNr){
		wsNr--;
		if(wsNr < 0)
			wsNr += 4;
		
		if(anbindung[wsNr] == null)
			return true;
		else if(ws[wsNr].getLaenge(zeit) == 0){
			double tmp = ((NormaleStrasse)anbindung[wsNr]).getNaechstenAnkunftZeitpunkt(this);
			tmp -= zeit;
			
			if(tmp < 0.0 || tmp > zeitBisAnkunft){//TODO Bessere Wert f�r Zeit-Abstand finden
				return true;
			}
		}

		return false;
	}
	
	private boolean kreuzungIstLeer(){
		for(int i=0;i<2;i++){
			for(int j=0;j<2;j++){
				if(!segment[i][j].getStatus().equals("frei")){
					return false;
				}
			}
		}
		return true;
	}


	public double getLaengeFuerWS(Simulationsabschnitt aufrufer) {
		return 3.0; //Kreuzung bietet kaum Platz f�r eine WS
	}
	
	public Status getStatus() {
		Status s = new Status(daten.getId());
		s.setAnzahlWS(4);
		int[] wsId = new int[4]; 
		int[] wsLaenge = new int[4]; 
		
		for(int i=0;i<4;i++){
			if(anbindung[i] != null){
				wsId[i] = anbindung[i].getID();
			}
			else{
				wsId[i] = -1;
			}
		}
		
		wsLaenge[0] = ws[0].getLaenge(zeit);
		wsLaenge[1] = ws[1].getLaenge(zeit);
		wsLaenge[2] = ws[2].getLaenge(zeit);
		wsLaenge[3] = ws[3].getLaenge(zeit);
		
		String info="";
		int anzahlBelegterSegmente=0;
		
		info += "Segment�bersicht\n";
		for(int i=0;i<2;i++){
			for(int j=0;j<2;j++){
				if(segment[i][j].getStatus() != "frei"){
					anzahlBelegterSegmente++;
					////info += "Segment "+Integer.toString(i)+Integer.toString(j)+" Belegt durch ";
					//info += Integer.toString(segment[i][j].getAktFahrzeug().getID())+"\t";
				}
				else{
					//info +="\t";
				}
				info += getSegmentStatus(i, j);
			}
			info += "\n";
		}
		
		
		info += "Belegte Segmente: " + Integer.toString(anzahlBelegterSegmente);
		
		s.setInfoText(info);
		s.setWsId(wsId);
		s.setWsLaenge(wsLaenge);
		return s;
	}
	
	private String getSegmentStatus(int i, int j){
		if(segment[i][j].getAktFahrzeug() != null){
			return Integer.toString(segment[i][j].getAktFahrzeug().getID())+"\t";
		}
		else{
			return "__\t";
		}
	}
	
}
