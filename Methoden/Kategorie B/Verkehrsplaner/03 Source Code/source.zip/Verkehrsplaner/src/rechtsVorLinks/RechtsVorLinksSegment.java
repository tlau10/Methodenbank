/*
 * Created on 29.10.2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package rechtsVorLinks;

import verkehrsplaner.Simulationsabschnitt;
import verkehrsplaner.Warteschlange;

/**
 * @author Christian Gruhler
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RechtsVorLinksSegment {
	private int nummer;
	private RechtsVorLinksContainer aktFahrzeug;
	private RechtsVorLinksContainer letztesFahrzeug;
	private String status;
	private Warteschlange ws;
	private Simulationsabschnitt ausfahrt;
	private RechtsVorLinksContainer blockiertesFahrzeug;

	public RechtsVorLinksSegment(int nummer) {
		this.nummer = nummer;
		aktFahrzeug = null;
		status = "frei";
		ws=null;
		ausfahrt=null;
		blockiertesFahrzeug=null;
	}

	/**
	 * @return Returns the blockiertesFahrzeug.
	 */
	public RechtsVorLinksContainer getBlockiertesFahrzeug() {
		return blockiertesFahrzeug;
	}
	/**
	 * @param blockiertesFahrzeug The blockiertesFahrzeug to set.
	 */
	public void setBlockiertesFahrzeug(RechtsVorLinksContainer blockiertesFahrzeug) {
		this.blockiertesFahrzeug = blockiertesFahrzeug;
	}
	/**
	 * @return Returns the ausfahrt.
	 */
	public Simulationsabschnitt getAusfahrt() {
		return ausfahrt;
	}
	/**
	 * @param ausfahrt The ausfahrt to set.
	 */
	public void setAusfahrt(Simulationsabschnitt ausfahrt) {
		this.ausfahrt = ausfahrt;
	}
	/**
	 * @return Returns the ws.
	 */
	public Warteschlange getWs() {
		return ws;
	}
	/**
	 * @param ws The ws to set.
	 */
	public void setWs(Warteschlange ws) {
		this.ws = ws;
	}
	/**
	 * @return Returns the aktuelleFahrzeug.
	 */
	public RechtsVorLinksContainer getAktFahrzeug() {
		return aktFahrzeug;
	}
	/**
	 * @param aktFahrzeug The aktuelleFahrzeug to set.
	 */
	public void setAktFahrzeug(RechtsVorLinksContainer aktFahrzeug) {
		this.letztesFahrzeug = this.aktFahrzeug;
		this.aktFahrzeug = aktFahrzeug;
	}
	/**
	 * @return Returns the letztesFahrzeug.
	 */
	public RechtsVorLinksContainer getLetztesFahrzeug() {
		return letztesFahrzeug;
	}
	/**
	 * @return Returns the nummer of the Segment.
	 */
	public int getNummer() {
		return nummer;
	}
	
	
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
